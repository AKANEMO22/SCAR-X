"""Read-only ALIF inference views, for diagnostics rather than serving changes."""
import numpy as np


def inference_features(model,sequences,seed,temperature=.4,samples=8):
    x=np.asarray(sequences,np.float32);c=model.config
    if x.ndim!=3 or not 1<=len(x)<=2048 or not 1<=x.shape[1]<=128 or x.shape[2]!=c.inputs or not np.isfinite(x).all():raise ValueError('Invalid bounded inference batch')
    if temperature not in (0.,.1,.4) or type(samples) is not int or not 1<=samples<=8:raise ValueError('Invalid inference view')
    effective=1 if temperature==0 else samples;output=np.zeros((len(x),c.hidden),np.float32)
    for sample in range(effective):
        rng=np.random.default_rng(seed+sample);v=np.zeros_like(output);a=v.copy();z=v.copy();f=v.copy()
        for tick in range(x.shape[1]):
            v=c.leak*v+x[:,tick]@model.w_in.T+np.sum(model.w_rec[None,:,:]*z[:,model.indices],axis=2)
            limit=c.threshold+c.adaptation_strength*a
            if temperature==0:z=(v>=limit).astype(np.float32)
            else:
                p=1/(1+np.exp(-np.clip((v-limit)/temperature,-20,20)));z=(rng.random(z.shape)<p).astype(np.float32)
            v-=z*limit;a=c.adaptation_decay*a+z;f=c.feature_decay*f+(1-c.feature_decay)*z
        output+=f/effective
    return output
