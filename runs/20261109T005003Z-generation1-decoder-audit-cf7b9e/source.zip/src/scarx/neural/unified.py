"""One fixed-size ALIF recurrent core for words and digits. No pretrained weights.

The two output slices are readouts of the SAME hidden neurons/recurrence. Hidden
learning remains a heuristic scalar-modulated local eligibility rule, not proof
of useful representation learning. Runtime never resets its neuron state.
"""
import hashlib
import io
import json
import zipfile
import numpy as np
from .core import Config, SpikingCore
from .language import tokenize, render


class UnifiedCore:
    context_size = 128
    settle_ticks = 12

    def __init__(self, vocabulary, seed=17):
        self.vocabulary = list(vocabulary)
        if self.vocabulary[:2] != ['<eos>', '<bos>'] or not 3 <= len(vocabulary) <= 256 or len(set(vocabulary)) != len(vocabulary):
            raise ValueError('Invalid vocabulary')
        self.ids = {word: i for i, word in enumerate(vocabulary)}
        self.image_start = len(vocabulary) + self.context_size
        self.core = SpikingCore(Config(inputs=self.image_start+64+6, hidden=48,
            outputs=len(vocabulary)+10, fan_in=8, plastic_rows=12, seed=seed,
            leak=.65, threshold=.5, feature_decay=.25, adaptation_strength=.02,
            readout_lr=.025, hidden_lr=.0001, anchor_strength=0, weight_clip=20.))
        self.core.w_in -= .15
        self.core.stable_in[:] = self.core.w_in
        self.ticks = 0
        self.on_tick = None

    def context(self, prompt):
        if not isinstance(prompt, str) or not 1 <= len(prompt.strip()) <= 2048:
            raise ValueError('Câu hỏi cần 1–2048 ký tự.')
        words = tokenize(prompt)
        normalized = ' '.join(words)
        features = words + [normalized[i:i+3] for i in range(max(0, len(normalized)-2))]
        result = np.zeros(self.context_size, np.float32)
        for part in features:
            code = int.from_bytes(hashlib.blake2b(part.encode(), digest_size=8).digest(), 'little')
            result[code % self.context_size] += 1 if (code >> 8) & 1 else -1
        return result / max(1., float(np.linalg.norm(result)))

    def tick(self, x=None, track=False, kind='idle', source=None):
        if x is None:
            x = np.zeros(self.core.config.inputs, np.float32)
        self.core.step(x, track=track)
        self.ticks += 1
        if self.on_tick is not None:
            self.on_tick(kind, source)

    def boundary(self):
        # Neural dynamics continue; no reset or independent per-modality core.
        for _ in range(self.settle_ticks):
            self.tick(kind='settle')

    def word_step(self, previous, context, position, track=False, source=None):
        x = np.zeros(self.core.config.inputs, np.float32)
        x[previous] = .8
        x[len(self.vocabulary):self.image_start] = context * 1.6
        x[-6:] = [1., 0., .2, position/24, .2*np.sin(position), .2*np.cos(position)]
        for _ in range(3):
            self.tick(x, track, 'language', source)
        return self.probabilities('language', position)

    def probabilities(self, modality, position=0):
        c = self.core
        logits = c.w_out @ c.features + c.bias
        mask = np.zeros(c.config.outputs, bool)
        if modality == 'language':
            mask[:len(self.vocabulary)] = True
            mask[1] = False
            if position == 0:
                mask[0] = False
                for i, token in enumerate(self.vocabulary[2:], 2):
                    if not any(ch.isalnum() for ch in token):
                        mask[i] = False
        else:
            mask[len(self.vocabulary):] = True
        p = np.zeros(c.config.outputs, np.float32)
        values = np.exp(logits[mask] - np.max(logits[mask]))
        p[mask] = values / values.sum()
        return p

    def learn(self, target, modality, position=0):
        c = self.core
        p = self.probabilities(modality, position)
        if not 0 <= target < len(p) or p[target] <= 0:
            raise ValueError('Target outside active readout')
        loss = -float(np.log(max(float(p[target]), 1e-12)))
        error = -p.copy(); error[target] += 1
        c.w_out += np.clip(c.config.readout_lr * error[:, None] * c.features[None, :], -c.config.update_clip, c.config.update_clip)
        c.bias += np.clip(c.config.readout_lr * error, -c.config.update_clip, c.config.update_clip)
        reward = float(p[target]); advantage = float(np.clip(reward-c.reward_mean, -1, 1))
        c.reward_mean = .95*c.reward_mean + .05*reward
        for name, trace in (('in', c.elig_in), ('rec', c.elig_rec)):
            weights = getattr(c, 'w_'+name)
            weights[c.rows] += np.clip(c.config.hidden_lr*advantage*trace, -c.config.update_clip, c.config.update_clip)
            np.clip(weights, -c.config.weight_clip, c.config.weight_clip, out=weights)
        np.clip(c.w_out, -c.config.weight_clip, c.config.weight_clip, out=c.w_out)
        np.clip(c.bias, -c.config.weight_clip, c.config.weight_clip, out=c.bias)
        c.updates += 1
        return loss

    def train_pair(self, prompt, answer):
        tokens = tokenize(answer)
        if not 1 <= len(tokens) <= 24 or any(t not in self.ids for t in tokens):
            raise ValueError('Câu trả lời cần 1–24 token trong vocabulary hiện tại.')
        self.boundary()
        # Clear only learning traces at the start of a labeled segment. Neuron
        # voltage/adaptation/spikes/features keep evolving without a reset.
        self.core.elig_in.fill(0); self.core.elig_rec.fill(0)
        self.core.pre.fill(0); self.core.post.fill(0)
        start = (self.core.updates*self.core.config.plastic_rows) % 48
        self.core.rows[:] = (np.arange(12)+start) % 48
        previous = 1; loss = 0.
        context = self.context(prompt)
        for position, token in enumerate([self.ids[t] for t in tokens]+[0]):
            self.word_step(previous, context, position, True, prompt)
            loss += self.learn(token, 'language', position)
            previous = token
        return loss / (len(tokens)+1)

    def generate(self, prompt, max_words=24, stop_at_sentence=False):
        context = self.context(prompt)
        if type(max_words) is not int or not 1 <= max_words <= 32:
            raise ValueError('Giới hạn sinh 1–32 token.')
        self.boundary(); previous = 1; words = []; scores = []; stopped = False; reason = 'length'
        for position in range(max_words):
            p = self.word_step(previous, context, position, source=prompt)
            token = int(np.argmax(p)); scores.append(float(p[token]))
            if token == 0:
                stopped = True; reason = 'eos'; break
            words.append(self.vocabulary[token]); previous = token
            if stop_at_sentence and self.vocabulary[token] in ('.','!','?'):
                stopped = True; reason = 'sentence_boundary'; break
        return {'text': render(words), 'tokens': words, 'stopped': stopped, 'stop_reason': reason,
                'mean_probability': float(np.mean(scores)), 'source': 'shared ALIF neural word readout; no answer lookup'}

    def image(self, pixels, train_label=None):
        pixels = np.asarray(pixels, np.float32)
        if pixels.size != 64 or not np.isfinite(pixels).all() or pixels.min() < 0 or pixels.max() > 16:
            raise ValueError('Ảnh neural cần 64 giá trị trong [0,16].')
        self.boundary()
        x = np.zeros(self.core.config.inputs, np.float32)
        x[self.image_start:self.image_start+64] = pixels.reshape(-1)/16-.3
        x[-6:] = [0., 1., .2, 0., 0., 0.]
        if train_label is not None:
            if type(train_label) is not int or not 0 <= train_label <= 9: raise ValueError('Nhãn chữ số0–9.')
            self.core.elig_in.fill(0); self.core.elig_rec.fill(0)
            self.core.pre.fill(0); self.core.post.fill(0)
            self.core.rows[:] = (np.arange(12)+self.core.updates*12) % 48
        for _ in range(4):
            self.tick(x, train_label is not None, 'vision', '8x8 digit')
        p = self.probabilities('vision')[len(self.vocabulary):]
        result = {'digit': int(np.argmax(p)), 'probabilities': p.tolist(),
                  'scope': 'handwritten_digits_only; not screenshot/OCR/visualQA'}
        if train_label is not None:
            result['loss'] = self.learn(len(self.vocabulary)+train_label, 'vision')
        return result

    def dumps(self):
        payload = self.core.dumps()
        meta = {'format': 'scarx-generation1-core', 'vocabulary': self.vocabulary,
                'ticks': self.ticks, 'sha256': hashlib.sha256(payload).hexdigest()}
        output = io.BytesIO()
        with zipfile.ZipFile(output, 'w') as archive:
            archive.writestr(zipfile.ZipInfo('core.npz'), payload)
            archive.writestr(zipfile.ZipInfo('metadata.json'), json.dumps(meta, ensure_ascii=False))
        return output.getvalue()

    @classmethod
    def loads(cls, payload):
        if len(payload) > 2_000_000: raise ValueError('Oversized generation checkpoint')
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            if len(archive.namelist()) != 2 or set(archive.namelist()) != {'core.npz', 'metadata.json'} or sum(x.file_size for x in archive.infolist()) > 2_000_000:
                raise ValueError('Invalid generation checkpoint')
            meta = json.loads(archive.read('metadata.json')); data = archive.read('core.npz')
        if meta.get('format') != 'scarx-generation1-core' or hashlib.sha256(data).hexdigest() != meta['sha256']:
            raise ValueError('Checkpoint checksum/format')
        with zipfile.ZipFile(io.BytesIO(data)) as inner:
            if sum(i.file_size for i in inner.infolist()) > 2_000_000 or len(inner.namelist()) != len(set(inner.namelist())):
                raise ValueError('Oversized or duplicate neural arrays')
        model = cls(meta['vocabulary']); core = SpikingCore.loads(data)
        if core.config.inputs != model.core.config.inputs or core.config.outputs != model.core.config.outputs or (core.config.hidden, core.config.fan_in, core.config.plastic_rows) != (48,8,12):
            raise ValueError('Incompatible generation topology')
        model.core = core; model.ticks = int(meta['ticks'])
        if model.ticks < 0: raise ValueError('Invalid tick counter')
        return model
