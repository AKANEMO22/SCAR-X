"""Read real inference/learning transactions. No training or job-launch on GET."""
import json,time,hashlib
from datetime import datetime
from pathlib import Path
from ..runtime.work_trace import read
from ..runtime.experiment_status import RUN_ID


def answers_case(root, identifier):
    """Pinned public corpus/reference; labels never enter neural input."""
    if not isinstance(identifier,str) or len(identifier)>80:raise ValueError('Invalid case ID')
    root=Path(root).resolve()
    reference=json.loads((root/'artifacts/qwen-dialogue-reference-latest.json').read_text(encoding='utf-8'))
    data=(root/reference['data']).resolve()
    if not data.is_relative_to(root/'data/candidates'):raise ValueError('Invalid corpus path')
    records=[json.loads(line) for line in (data/'experiences.jsonl').read_text(encoding='utf-8').splitlines()]
    case=next((r for r in records if r['id']==identifier and r['split']=='development'),None)
    if case is None:raise ValueError('Unknown public development case')
    qwen=next((r for r in reference['outputs'] if r['id']==identifier),None)
    if qwen is None or qwen['messages']!=case['messages'] or qwen['one_reference_target']!=case['target']:
        raise ValueError('Reference and dataset disagree')
    manifest=(root/reference['run']/'manifest.json').resolve()
    if not manifest.is_relative_to(root/'runs'):raise ValueError('Invalid reference run')
    measured=json.loads(manifest.read_text(encoding='utf-8'))['created_utc']
    return case,{'generated':qwen['generated'],'finish_reason':qwen['finish_reason'],'measured_at_utc':measured,
        'run':reference['run'],'scope':'archived measured Qwen3-4B; full prefix; not live or an oracle'}


def observe_answer(app,root,data):
    dataset=data.get('dataset')
    if dataset=='g1_state':
        return observe_reviewed_state_prompt(app,root,data)
    if dataset is not None:raise ValueError('Unknown observation dataset')
    case,reference=answers_case(root,data.get('case_id'))
    prompt=next(m['text'] for m in reversed(case['messages']) if m['role']=='user')
    return app.chat(prompt,record_experience=False,observation={'case_id':case['id'],
        'messages':case['messages'],'target':case['target'],'qwen':reference,
        'input_scope':'SCAR-X receives latest user text only; Qwen received full prefix. Not an equal-context quality benchmark.'})


def observe_reviewed_state_prompt(app,root,data):
    root=Path(root).resolve();identifier=data.get('case_id')
    if not isinstance(identifier,str) or len(identifier)>80:raise ValueError('Invalid public case ID')
    info=json.loads((root/'artifacts/g1-state-prompts-reviewed.json').read_text(encoding='utf-8'))
    path=(root/info['data']).resolve()
    if not path.is_relative_to(root/'data/candidates') or not path.is_file() or path.stat().st_size>1000000:raise ValueError('Invalid public dataset')
    raw=path.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=info['sha256']:raise ValueError('Reviewed dataset checksum mismatch')
    case=next((r for r in json.loads(raw)['items'] if r['id']==identifier),None)
    if case is None:raise ValueError('Unknown reviewed public case')
    return app.chat(case['prompt'],record_experience=False,observation={'target':case['target'],
        'case_id':'g1-state/'+identifier,'source_sha256':info['sha256'],
        'input_scope':'Actual live SCAR-X, public prompt only, continuous neural state. Archived Qwen used this single prompt with its own fresh context. Targets not fed into neural input/learning.'})


def feed(app,root):
    with app.lock:
        rows=app.db.execute("SELECT id,created,action,details FROM events WHERE action IN ('answer-trace','teach','online-learn','online-reject') ORDER BY id DESC LIMIT 180").fetchall()
        controller={'accepted':app.dialogue.accepted_updates,'rejected':app.dialogue.rejected_updates,
            'queued':sum(l['status']=='queued' for l in app.dialogue.lessons),'updates':app.model.core.updates}
        live=[]
        for identifier,created,action,details in rows:
            item=json.loads(details);stamp=datetime.fromisoformat(created).timestamp()
            live.append({**item,'event_id':f'live-{identifier}','time':stamp,'kind':'answer' if action=='answer-trace' else 'learning',
                'action':action,'scope':'Lõi đang dùng','run_id':None})
    records=live+read(Path(root).resolve())
    records.sort(key=lambda r:r['time'],reverse=True)
    references=archived_single_prompt_references(root)
    for row in records:
        if row.get('kind')=='answer' and not row.get('qwen') and isinstance(row.get('prompt'),str) and row['prompt'] in references:
            row['qwen']=references[row['prompt']]
    return {'activities':[r for r in records if r['kind']=='activity'][:24],
        'answers':[r for r in records if r['kind']=='answer'][:60],
        'learning':[r for r in records if r['kind']=='learning'][:100],
        'controller':controller,'updated':time.time()}


def archived_single_prompt_references(root):
    path=Path(root)/'artifacts/qwen-g1-state-reference-latest.json'
    if not path.is_file() or path.stat().st_size>2000000:return {}
    try:
        value=json.loads(path.read_text(encoding='utf-8'));run=value.get('run')
        if not isinstance(run,str) or not run.startswith('runs/') or not RUN_ID.fullmatch(run[5:]):return {}
        rows=value.get('outputs');out={}
        if not isinstance(rows,list):return {}
        for row in rows[:128]:
            if not isinstance(row,dict):continue
            prompt=row.get('prompt');generated=row.get('generated')
            if not isinstance(prompt,str) or len(prompt)>2048 or not isinstance(generated,str) or len(generated)>8192:continue
            out[prompt]={'generated':generated,'finish_reason':row.get('finish_reason'),'run':run,'measured_at_utc':row.get('measured_at_utc'),
                'scope':'Actual archived Qwen3-4B on this exact single public user prompt; no tools/history. Different training/RAM budget; not a truth oracle or serving proxy.'}
        return out
    except (OSError,ValueError,TypeError):return {}
