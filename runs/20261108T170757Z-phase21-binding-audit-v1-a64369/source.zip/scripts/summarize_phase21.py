"""Build a linked report from immutable results, never edit measured runs."""
from pathlib import Path
import json
import numpy as np

root=Path(__file__).resolve().parents[1]
def load(pattern):
    candidates=sorted(p for p in (root/'runs').glob(pattern) if (p/'result.json').exists())
    if not candidates: raise SystemExit('Missing completed '+pattern)
    p=candidates[-1]
    return p,json.loads((p/'result.json').read_text())

mainp,main=load('*-phase21-v1-*')
lifep,life=load('*-phase21-lifelong-v1-*')
bindp,binding=load('*-phase21-binding-audit-v1-*')
controlp,control=load('*-phase21-bptt-control-v1-*')
replicatep,replicate=load('*-phase21-reproduction-*')
audit=json.loads((mainp/'phase2_audit.json').read_text())
def pct(x): return f'{100*x:.2f}'
def ci(v): return f"{pct(v['mean'])} [{pct(v['lower95'])}; {pct(v['upper95'])}]"
def link(path): return '../../runs/'+path.name+'/report.md'

lines=['# 08 — Phase2.1: Lifelong Adaptive Intelligence','',
       '**Kết luận: PIVOT tiếp ở quy mô nhỏ; NO-GO cho mở rộng quy tắc/cấu hình hiện tại. Chưa có lợi thế continual learning đáng tin cậy so với các đối chứng đã chạy.**','',
       'Mục tiêu1M context đã bị loại bỏ. Giữ48neurons, local learning, RAM2GB, mean forgetting≤3pp và worst≤5pp. Không thay threshold sau kết quả.','',
       '## Hồ sơ và thiết kế','',
       f'- [Representation/replay factorial]({link(mainp)}): 3 development seeds, 8 confirmation seeds; lựa chọn cấu hình trước test.',
       f'- [Stream không task boundary]({link(lifep)}): 7 methods×8 seeds,1280 trải nghiệm có noise, periodic consolidation.',
       f'- [Strict binding audit]({link(bindp)}): 8 seed mới, không chọn lại rule.',
       f'- [BPTT control riêng]({link(controlp)}): 24trial; không thuộc nhánh SCAR-X.',
       f'- [Kiểm tra tái lập]({link(replicatep)}): source snapshot, statistics và recorded-update schedule.',
       '- Tổng303 trial mới, ngoài audit lịch sử. CI bootstrap theo seed; task contrasts có Holm correction.','',
       '## 1. Vì sao Phase2 quên?','',
       'Toàn bộ15trial và checkpoint được kiểm lại. Full: acquisition ban đầu trung bình45.36%, final34.17%. Max-to-final forgetting22.29pp; diagonal-to-final11.20pp. Phần chênh11.09pp bao gồm các đỉnh xuất hiện sau lần học đầu và biến động; không quy hết cho nhiễu thống kê.','',
       '| Seed | Task0 sau học | Cuối stream | Khôi phục head cũ | Khôi phục hidden cũ | Nhóm replay bị thiếu/80 |',
       '|---|---:|---:|---:|---:|---:|']
for r in audit['counterfactuals']:
    if r['mode']=='full': lines.append(f"| {r['seed']} | {pct(r['task0_after_learning'])}% | {pct(r['task0_final'])}% | {pct(r['task0_old_head_final_hidden'])}% | {pct(r['task0_old_hidden_final_head'])}% | {r['missing_groups']} |")
lines+=['','Head overwrite là nguyên nhân nổi bật ở task0 được audit. Replay thiếu coverage; anchor EMA không chứa importance về mức hữu ích. Các context dùng permutation khác trên cùng head, tạo interference. Đây là counterfactual trên task0, không phải phân rã nhân quả cho mọi kỹ năng.','',
        '## 2. Hidden có học representation mới?','',
        '| Bài | Probe gain so với initial, pp [CI95%] | Accuracy trực tiếp | Holm p | Gate |','|---|---:|---:|---:|---|']
for task,c in main['analysis']['representation'].items(): lines.append(f"| {task} | {ci(c['probe_gain'])} | {pct(c['accuracy']['mean'])}% | {c['holm_signflip_p']:.4f} | {c['pass']} |")
lines+=['','Score eligibility có tín hiệu nhỏ ở order, chưa vượt threshold5pp và correction. Weight thay đổi thật không đủ chứng minh representation hữu ích. Negative-control modulation không bị vượt ổn định.','',
        '**Lỗi thiết kế được phát hiện:** binding ban đầu có shortcut bag-of-values đạt75% lý thuyết. Giữ kết quả nguyên bản nhưng không tính đó là khả năng binding. Challenge mới buộc hai value đối nhau, giữ cùng số sự kiện/key/value. Đây là audit bổ sung sau khi nhìn kết quả, dùng seed mới và rule cố định.','',
        f"Strict binding: probe={ci(binding['summary']['probe'])}%; gain={ci(binding['summary']['probe_gain'])}pp; accuracy={ci(binding['summary']['accuracy'])}%; bag-only={ci(binding['summary']['bag_accuracy'])}%; exact p={binding['summary']['signflip_p']:.4f}; pass={binding['summary']['pass']}.",
        '', 'Temporal permutation cố định có thể giữ hoặc biến đổi tín hiệu order, nên một lesion tăng điểm không chứng minh model hiểu quan hệ thời gian. Reset-state và OOD chỉ là chẩn đoán phụ.','',
        '## 3. Replay và consolidation với budget đối chiếu','',
        f"Development chọn hidden={main['selection']['hidden_rule']}, replay={main['selection']['replay']}, consolidation={main['selection']['consolidation']}; time budget={main['selection']['matched_stage_seconds']:.6f}s/stage đã khóa trước confirmation.",
        '', '| Budget | Condition | Acquisition | Final | Mean forgetting | Train seconds | Updates |', '|---|---|---:|---:|---:|---:|---:|']
for budget,c in main['analysis']['retention'].items():
    for name,row in c['conditions'].items(): lines.append(f"| {budget} | {name} | {pct(row['acquisition']['mean'])}% | {pct(row['final_accuracy']['mean'])}% | {pct(row['forgetting']['mean'])}pp | {row['train_seconds']['mean']:.3f} | {row['updates']['mean']:.1f} |")
lines+=['','Equal updates: bỏ EMA giảm forgetting khoảng0.22pp, quá nhỏ so với yêu cầu5pp. Equal time: lợi thế không còn ổn định. Acquisition quanh30% (chance25%) chưa thể gọi retention thành công. Balanced replay+meta có forgetting thấp trong development nhưng acquisition yếu; không chọn cấu hình chỉ vì quên ít.','',
        '## 4. Stream không boundary, noisy feedback và plasticity','',
        '| Cơ chế | Final accuracy | Mean forgetting | Worst forgetting | New-rule gain | Fresh-network gain |', '|---|---:|---:|---:|---:|---:|']
for mode,c in life['summaries'].items():
    lines.append(f"| {mode} | {pct(c['final_accuracy']['mean'])}% | {pct(c['forgetting']['mean'])}pp | {pct(c['worst_forgetting']['mean'])}pp | {pct(c['new_rule_gain']['mean'])}pp | {pct(c['fresh_new_rule_gain']['mean'])}pp |")
lines+=['','| Primary contrast | Final accuracy gain, pp [CI95%] | Forgetting reduction, pp [CI95%] | Holm p |','|---|---:|---:|---:|']
for name,c in life['comparisons'].items(): lines.append(f"| {name} | {ci(c['accuracy_gain'])} | {ci(c['forgetting_reduction'])} | {c['holm_p']:.4f} |")
lines+=['','Không condition nào đạt toàn bộ ngưỡng tuyệt đối. Metaplasticity/decay làm giảm dao động và forgetting ở một số trường hợp, nhưng accuracy gầnchance50%: dấu hiệu hạn chế học, không phải giữ được kỹ năng. Importance dựa độ lớn tín hiệu có thể bảo vệ cả update nhiễu; chưa đo được importance nhân quả.','',
        'Selective learning được thêm metadata chất lượng không hoàn hảo; so với random-rejection để tránh nhầm ít update với học tốt. Kết quả chỉ áp dụng cho giả lập chất lượng nguồn này, không chứng minh hệ tự phân biệt chân lý. SI-readout là adaptation có khả năng học khác, không phải whole-network SI.','',
        'Probe cuối dùng đảo nhãn binding64 mẫu; đó là adaptation sang quy tắc xung đột, không thể đòi đồng thời giữ nhãn cũ cho cùng input. Chênh lệch fresh-vs-aged còn phụ thuộc starting accuracy. Không đủ để chứng minh loss-of-plasticity dài hạn chỉ từ một probe.','',
        '## 5. So với recurrent/backprop control','', '| Bài | BPTT accuracy trung bình |', '|---|---:|']
for task in ('xor','order','binding'):
    values=[r['accuracy'] for r in control['trials'] if r['task']==task]
    lines.append(f'| {task} | {pct(float(np.mean(values)))}% |')
lines+=['','BPTT control dùng deterministic ALIF, localbranch dùng stochastic ALIF; cùng shape và512samples, actual compute khác. Không suy diễn trực tiếp thành lợi thế hardware. Bài binding control cũng chịu shortcut đã nêu.','',
        'Đã so với replay reservoir/balanced, readout-only recurrent, EMA, local metaplasticity và output-local SI. Chưa tái lập MESU, BNN metaplasticity hay Continual Backprop đầy đủ trong cùng budget; không có cơ sở tuyên bố thắng các phương pháp hiện đại nói chung.','',
        '## 6. RAM, persistence và phán quyết','', '| Run | Peak RSS MB | Peak commit MB |', '|---|---:|---:|']
for name,data in [('phase21',main['analysis']),('lifelong',life),('binding audit',binding),('BPTT control',control)]:
    r=data['resources']; lines.append(f"| {name} | {r['peak_rss_bytes']/1e6:.2f} | {r['peak_commit_or_vms_bytes']/1e6:.2f} |")
lines+=['','Neural weights/traces/importance, reward/RNG và replay continuation đã kiểm. RAM quan sát trong trần2GB; đây là monitoring, chưa phải hard-limit của OS. Không có iGPU hoặc energy claim.','',
        '**Có thể học tiếp không cần BPTT ở phạm vi hữu hạn; chưa chứng minh SCAR-X duy trì kỹ năng phức tạp lâu dài.** Capacity cố định không giữ vô hạn ánh xạ độc lập. Credit assignment scalar và chất lượng representation hiện là nút thắt; memory/replay không tự giải quyết chúng. Xem [phản biện giới hạn](07_LIFELONG_LIMITS.md).','',
        '**Quyết định:** PIVOT hẹp về importance gắn với usefulness, ổn định readout và credit assignment/representation. NO-GO cho tăng model hoặc quảng bá lợi thế Lifelong của rule hiện tại. Không đổi threshold, không huấn luyện ngôn ngữ, không mở rộng tham số.']
(root/'docs/research/08_PHASE21_RESULTS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
summary={'phase21':str(mainp.relative_to(root)),'lifelong':str(lifep.relative_to(root)),'strict_binding':str(bindp.relative_to(root)),
         'control':str(controlp.relative_to(root)),'reproduction':str(replicatep.relative_to(root)),'decision':'PIVOT_NO_SCALE',
         'report':'docs/research/08_PHASE21_RESULTS.md','new_trial_count':len(main['development_representation'])+len(main['development_retention'])+len(main['confirmation_representation'])+len(main['confirmation_retention'])+len(life['trials'])+len(binding['trials'])+len(control['trials'])}
(root/'artifacts/phase21-summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
print(json.dumps(summary,indent=2))
