"""Small vocabulary autoregressive ALIF language pilot; no response lookup.

Prompt hashes are input features, not semantic labels. Next word/punctuation
is sampled from neural probabilities. Corpus answers exist only in training.
"""
from dataclasses import asdict
import hashlib
import json
from pathlib import Path
import re
import unicodedata
import numpy as np
from .core import Config,SpikingCore


def tokenize(text):
    return re.findall(r'\w+(?:-\w+)*|[^\w\s]',unicodedata.normalize('NFKC',text).lower(),re.UNICODE)


def render(tokens):
    text=' '.join(tokens)
    text=re.sub(r'\s+([,.!?;:])',r'\1',text)
    return text[:1].upper()+text[1:]


class WordLanguageCore:
    def __init__(self,vocabulary,seed=17):
        self.vocabulary=list(vocabulary)
        if self.vocabulary[:2]!=['<eos>','<bos>'] or len(set(vocabulary))!=len(vocabulary) or not 3<=len(vocabulary)<=256:
            raise ValueError('Invalid pilot vocabulary')
        self.ids={word:i for i,word in enumerate(vocabulary)}
        self.context_size=128
        c=Config(inputs=len(vocabulary)+self.context_size+3,hidden=48,outputs=len(vocabulary),fan_in=8,plastic_rows=12,seed=seed,
                 leak=.65,threshold=.5,feature_decay=.25,adaptation_strength=.02,readout_lr=.2,hidden_lr=.0003,anchor_strength=0)
        self.core=SpikingCore(c)
        self.core.w_in-=.15; self.core.stable_in[:]=self.core.w_in

    @classmethod
    def vocabulary_from(cls,pairs):
        return ['<eos>','<bos>']+sorted({word for _,answer in pairs for word in tokenize(answer)})

    def context(self,prompt):
        normalized=unicodedata.normalize('NFKC',prompt).lower().strip()
        if len(normalized)>2048: raise ValueError('Pilot prompt limit 2048 characters')
        result=np.zeros(self.context_size,np.float32)
        features=tokenize(normalized)+[normalized[i:i+3] for i in range(max(0,len(normalized)-2))]
        for part in features:
            h=int.from_bytes(hashlib.blake2b(part.encode(),digest_size=8).digest(),'little')
            result[h%self.context_size]+=1 if (h>>8)&1 else -1
        result/=max(1,float(np.linalg.norm(result)))
        return result

    def step(self,previous,context,position,track=False):
        x=np.zeros(self.core.config.inputs,np.float32)
        x[previous]=1
        x[len(self.vocabulary):len(self.vocabulary)+self.context_size]=context*.8
        x[-3:]=[.2,position/32,.2*np.sin(position)]
        for _ in range(3): p=self.core.step(x,track=track)
        return p

    def train_pair(self,prompt,answer):
        context=self.context(prompt); target=[self.ids[t] for t in tokenize(answer)]+[0]
        self.core.reset_state(); previous=1; loss=0.; correct=0
        for position,token in enumerate(target):
            p=self.step(previous,context,position,track=True)
            correct+=int(np.argmax(p)==token)
            loss+=self.core.learn(token,mode='full')
            previous=token
        return loss,correct,len(target)

    def teacher_score(self,prompt,answer):
        context=self.context(prompt); self.core.reset_state(); previous=1; loss=0.; correct=0
        target=[self.ids[t] for t in tokenize(answer)]+[0]
        for position,token in enumerate(target):
            p=self.step(previous,context,position)
            loss-=float(np.log(max(float(p[token]),1e-12))); correct+=int(np.argmax(p)==token); previous=token
        return loss,correct,len(target)

    def generate(self,prompt,max_words=32):
        context=self.context(prompt); self.core.reset_state(); previous=1; words=[]; probabilities=[]; stopped=False
        for position in range(max_words):
            p=self.step(previous,context,position).copy(); p[1]=0; p/=p.sum()
            token=int(np.argmax(p)); probabilities.append(float(p[token]))
            if token==0: stopped=True; break
            words.append(self.vocabulary[token]); previous=token
        return {'text':render(words),'tokens':words,'stopped':stopped,'mean_probability':float(np.mean(probabilities)) if probabilities else 0.,
                'source':'autoregressive learned ALIF readout; no answer retrieval','scope':'small-vocabulary conversational pilot'}

    def save(self,directory):
        directory=Path(directory); directory.mkdir(parents=True,exist_ok=True)
        self.core.save(directory/'core.npz')
        metadata={'format':'scarx-word-language-v1','vocabulary':self.vocabulary,'sha256':hashlib.sha256((directory/'core.npz').read_bytes()).hexdigest()}
        (directory/'language.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')

    @classmethod
    def load(cls,directory):
        directory=Path(directory); metadata=json.loads((directory/'language.json').read_text(encoding='utf-8'))
        if metadata['format']!='scarx-word-language-v1' or hashlib.sha256((directory/'core.npz').read_bytes()).hexdigest()!=metadata['sha256']:
            raise ValueError('Invalid language checkpoint')
        core=SpikingCore.load(directory/'core.npz')
        model=cls(metadata['vocabulary'],core.config.seed)
        if core.config.inputs!=model.core.config.inputs or core.config.outputs!=len(model.vocabulary) or core.config.hidden!=48:
            raise ValueError('Incompatible language checkpoint')
        model.core=core
        return model
