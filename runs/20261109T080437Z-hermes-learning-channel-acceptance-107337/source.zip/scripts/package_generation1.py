"""One current product release. Include only public artifacts; no local data."""
from pathlib import Path
import hashlib
import json
import zipfile
root=Path(__file__).resolve().parents[1];target=root/'artifacts/SCAR-X-Generation-1.zip'
allowed={'.py','.md','.json','.jsonl','.yaml','.toml','.txt','.css','.html','.js','.ts','.tsx','.cpp','.h','.ps1','.patch'}
files=[]
for base in ('src','docs','scripts','tests','configs','experiments','data','native','integrations','runs'):
    files.extend(p for p in (root/base).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix in allowed)
files.extend(root/name for name in ('README.md','pyproject.toml','run_app.py','Start-SCARX.ps1','Stop-SCARX.ps1','AGENTS.md','project.json','capabilities.json','.gitignore','.ignore'))
release=json.loads((root/'artifacts/generation1-release.json').read_text(encoding='utf-8'))
path=(root/release['checkpoint']).resolve();assert path.is_relative_to((root/'artifacts').resolve())
files.extend([path,root/'artifacts/generation1-release.json',root/'artifacts/generation1-engineering.json',root/'artifacts/generation1-live-check.json',root/'artifacts/generation1-ui.jpg',root/'artifacts/phase21-summary.json',root/'artifacts/pilots/vision-examples.json'])
files.extend(root/'artifacts'/name for name in ('hermes-stateful-check.json','hermes-stateful-stream-check.json','hermes-stateful-source-proof.json','hermes-stateful-desktop-check.json','hermes-stateful-ui.jpg'))
files.extend(root/'artifacts'/name for name in ('adaptive-generation-engineering.json','continuous-dialogue-acceptance.json',
 'antigravity-dataset-latest.json','antigravity-dataset-validation.json','antigravity-supplement-latest.json',
 'antigravity-supplement-validation.json','hermes-online-question.jpg','hermes-online-resolved.jpg','hermes-online-desktop-check.json'))
files.append(root/'artifacts/continuous-dialogue-delivery.json')
files.extend(root/'artifacts'/name for name in ('knowledge-retention-latest.json',
 'knowledge-retention-audit-latest.json','qwen4b-reference-download.json','qwen4b-comparison-latest.json'))
delivery=json.loads((root/'artifacts/continuous-dialogue-delivery.json').read_text(encoding='utf-8'))
files.append(root/delivery['run']/'source.zip')
# Only the two attributed public photos, never arbitrary local image files.
supplement=json.loads((root/'artifacts/antigravity-supplement-latest.json').read_text(encoding='utf-8'))
photo_dir=(root/supplement['candidate_directory']).resolve()
assert photo_dir.is_relative_to((root/'data/candidates').resolve())
files.extend(photo_dir/name for name in ('china.jpg','flower.jpg'))
# Historical public pilot fixtures support legacy regression tests offline;
# never loaded by Generation1, never listed as active product models.
historical=json.loads((root/'artifacts/pilot-release.json').read_text(encoding='utf-8'))
files.append(root/'artifacts/pilot-release.json')
for entry in historical.values():
    p=(root/entry['checkpoint']).resolve();assert p.is_relative_to((root/'artifacts').resolve())
    files.extend(p.rglob('*') if p.is_dir() else [p])
# Preserve source as executed for the new training run and its audit.
files.append(root/release['run']/'source.zip')
files=sorted({p.resolve() for p in files if p.is_file()})
for p in files:
    relative=p.relative_to(root.resolve())
    assert 'local' not in relative.parts and '.env' not in p.name and 'backups' not in relative.parts
manifest={p.relative_to(root.resolve()).as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(target,'w',compression=zipfile.ZIP_DEFLATED) as archive:
    for p in files:archive.writestr('scar-x/'+p.relative_to(root.resolve()).as_posix(),p.read_bytes())
    archive.writestr('scar-x/PACKAGE_MANIFEST.json',json.dumps({'product':'SCAR-X Generation1','active_model':'scarx-generation1','runtime_core_count':1,'initial_checkpoint':release['checkpoint'],'historical_pilot_artifacts':'offline regression fixtures, not active runtime models','sha256':manifest,'excludes':['local/','Hermes personal config/backups','keys','.env','external models','old release ZIPs']},indent=2))
with zipfile.ZipFile(target) as archive:
    assert all(hashlib.sha256(archive.read('scar-x/'+name)).hexdigest()==digest for name,digest in manifest.items())
digest=hashlib.sha256(target.read_bytes()).hexdigest()
(root/'artifacts/SCAR-X-Generation-1.sha256').write_text(digest+'  '+target.name+'\n',encoding='ascii')
print(json.dumps({'package':str(target),'bytes':target.stat().st_size,'files':len(files),'sha256':digest}))
