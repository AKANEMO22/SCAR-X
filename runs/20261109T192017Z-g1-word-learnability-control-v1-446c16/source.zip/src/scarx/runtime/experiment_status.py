"""Bounded local experiment observability; never launch/restart a job here."""
import atexit,json,os,re,time,tempfile,threading,math
from pathlib import Path
import psutil

_owned={};_lock=threading.RLock()
RUN_ID=re.compile(r'^[A-Za-z0-9][A-Za-z0-9._-]{0,160}$')
CATALOG=(
 ('Audit27checkpoint / quality vẫnSTOP','g1-word-score-inputs-audit.json'),
 ('Wordconditioning / can thiệp readonly','g1-word-conditioning-latest.json'),
 ('ALIF word-score / vòng input cuối','g1-word-score-inputs-latest.json'),
 ('Trace tự động / kiểm tra phần mềm và serving','passive-work-trace-latest.json'),
 ('G1 input identity / không đạt','g1-input-identity-latest.json'),
 ('G1 paired-score chuyển sang từ / không đạt','g1-word-score-transfer-latest.json'),
 ('P2 voltage/adaptation / không đạt','p2-neuron-state-observability-latest.json'),
 ('G1 decoder search / đã dừng','g1-bounded-beam-latest.json'),
 ('G1 representation/decoder / chẩn đoán','g1-representation-decoder-latest.json'),
 ('G1 controller / dừng lặp guard','g1-guard-stop-latest.json'),
 ('G1 explicitproject teaching / live','g1-project-supervision-latest.json'),
 ('G1 curated curriculum / không đạt','g1-curated-curriculum-latest.json'),
 ('G1 curriculum / semanticreview','g1-curriculum-reviewed.json'),
 ('G1 curriculum Antigravity / chờ review','antigravity-g1-curriculum-latest.json'),
 ('G1 dấu câu / guard acceptance','g1-surface-acceptance-latest.json'),
 ('G1 ôn kỹ năng cơ bản / chưa deploy','g1-basic-rehearsal-latest.json'),
 ('Qwen4B / 48câu công khai mới','qwen-g1-state-reference-latest.json'),
 ('G1 trạng thái hội thoại / inference thật','g1-conversational-state-latest.json'),
 ('Antigravity / prompts đã rà soát','g1-state-prompts-reviewed.json'),
 ('ALIF time constants / diagnostic','p2-timescale-view-latest.json'),
 ('ALIF firing noise / diagnostic','p2-inference-dynamics-latest.json'),
 ('P2 cue/time/noise / chỉ chẩn đoán','p2-cue-information-latest.json'),
 ('P2 acquisition/retention / baseline','p2-paired-score-diagnostic-latest.json'),
 ('Paired-score / audit và attribution','p1-paired-score-v2-audit.json'),
 ('Paired-score / xác nhận P1','p1-paired-score-v2-latest.json'),
 ('Score eligibility / audit toán','p1-score-integrity-latest.json'),
 ('Audit optimizer và coverage / chỉ đối chứng','p1-control-factors-latest.json'),
 ('Audit local classifier / vòng cuối','p1-local-classifier-v2-audit.json'),
 ('Local classifier / vòng cuối','p1-local-classifier-v2-latest.json'),
 ('Trace thực trên lõi đang dùng','live-observatory-latest.json'),
 ('Tạo dữ liệu Antigravity','antigravity-generation-latest.json'),
 ('Local classifier / P1','p1-local-classifier-latest.json'),
 ('Ảnh thật / đối chứng đã audit','rgb-object-grounding-audit.json'),
 ('Bộ nhớ làm việc khi phát byte','byte-working-memory-latest.json'),
 ('Audit trạng thái decoder','decoder-state-retention-audit.json'),
 ('BPTT chỉ làm đối chứng','byte-bptt-control-latest.json'),
 ('Decoder UTF-8','byte-dialogue-latest.json'),
 ('Hội thoại và Qwen4B','qwen-dialogue-reference-latest.json'),
 ('Prototype hội thoại theo sự kiện','event-dialogue-latest.json'),
 ('Chuẩn hóa readout / 20 context','p2-conditioning-confirmation-latest.json'),
 ('Random feedback / đã dừng','p1-random-feedback-latest.json'))


def _safe(value,depth=0):
    if depth>5:return '[truncated]'
    if value is None or isinstance(value,(bool,int)):return value
    if isinstance(value,float):return value if value==value and abs(value)!=float('inf') else None
    if isinstance(value,str):return value[:800]
    if isinstance(value,dict):return {str(k)[:80]:_safe(v,depth+1) for k,v in list(value.items())[:48] if str(k).lower() not in ('token','password','api_key','authorization','secret','credentials','headers')}
    if isinstance(value,(list,tuple)):return [_safe(v,depth+1) for v in value[:128]]
    return str(value)[:160]


def _location(run):
    run=Path(run).resolve()
    if run.parent.name!='runs' or not RUN_ID.fullmatch(run.name):raise ValueError('Expected registered run directory')
    return run.parent.parent/'local/experiment-status'/(run.name+'.json')


def _write(path,value):
    raw=json.dumps(_safe(value),ensure_ascii=False,allow_nan=False).encode()
    if len(raw)>196608:raise ValueError('Experiment status exceeds192KB')
    path.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(dir=path.parent,suffix='.tmp')
    try:
        with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def start_run(run,config):
    path=_location(run);proc=psutil.Process()
    record={'run_id':Path(run).name,'run':f'runs/{Path(run).name}','kind':config.get('observability_kind','research_clone'),
      'title':config.get('display_title',Path(run).name),'model_scope':config.get('model_scope','Bản thử nghiệm; không thay model trò chuyện'),
      'pid':proc.pid,'process_created':proc.create_time(),'started':time.time(),'updated':time.time(),'status':'running',
      'stage':'Đã đăng ký lượt chạy','config':_safe(config),'events':[],'progress':None,'neural':None}
    with _lock:_write(path,record);_owned[str(Path(run).resolve())]=path


def progress(run,stage,completed=None,total=None,metrics=None,neural=None,task=None):
    path=_location(run)
    with _lock:
        if not path.exists():return
        value=json.loads(path.read_text(encoding='utf-8'));value['updated']=time.time();value['stage']=str(stage)[:300]
        if value.get('pid')!=os.getpid():return # parent owns the journal; workers return measurements to it
        value['progress']={'completed':completed,'total':total}
        if metrics is not None:value['metrics']=_safe(metrics)
        if neural is not None:value['neural']=_safe(neural)
        if task is not None:value['task']=str(task)[:200]
        value['events']=(value.get('events',[])+[{'time':time.time(),'stage':stage,'progress':value['progress'],'metrics':_safe(metrics)}])[-40:]
        _write(path,value)


def complete_run(run,result):
    path=_location(run)
    with _lock:
        if not path.exists():return
        value=json.loads(path.read_text(encoding='utf-8'));value.update(status='completed',updated=time.time(),finished=time.time(),stage='Đã có kết quả')
        if value.get('pid')!=os.getpid():return
        value['result']=_summary(result);_write(path,value)


def _summary(value):
    keys=('decision','summary','selection','direct_gate','primary_representation_gate','normal_chat_or_vision_proven','normal_photo_qa_proven',
      'normal_chat_vision_proven','deployed','live_model_replaced','resources','screen_trials','confirmation_trials','metric_correction','image_grounding_gate',
      'successful_batches','expected_batches','trained','validation_pending','control_summary','all_matched','all_cold_exact',
      'new_training','cases','inferences','items','completed','expected','truncated','error','server_stopped',
      'all_order_passes','terminal_punctuation_overlap_count','all_state_unchanged','weights_unchanged',
      'stopped_identical_proposal','updates_before','updates_after','before_actual_neural','after_actual_neural','checks','pytest_summary',
      'gates','application_route_closed','paired_encoding_dev_gain','paired_hidden_dev_gain','paired_hidden_prior_gain','source_quality_decision',
      'control_only','interpretations','forecast_round_seconds','formal_training_permitted')
    result={k:value[k] for k in keys if k in value}
    if isinstance(value.get('conditions'),list):
        trials=_product_trials(value['conditions'])
        if trials:result['product_trials']=trials
    return _safe(result)


def _product_trials(rows):
    trials=[]
    for row in rows[:24]:
        if not isinstance(row,dict) or not isinstance(row.get('states'),dict):continue
        trial={k:row[k] for k in ('mode','condition','curriculum_order_seed','surface_normalization','screen_pass','lost_old_correct_digits') if k in row}
        reset=row['states'].get('canonicalreset',{})
        if not isinstance(reset,dict):reset={}
        for name,key in (('known_reset','known'),('antigravity_reset','antigravity')):
            v=reset.get(key);trial[name]=v if type(v) in (int,float) and math.isfinite(v) else None
        trial['lost_guards_total']=sum(v.get('lost_personal_runtime_guards',v.get('lost_personal_guards',0))
            for v in row['states'].values() if isinstance(v,dict) and type(v.get('lost_personal_runtime_guards',v.get('lost_personal_guards',0))) in (int,float))
        trials.append(trial)
    return trials


def _on_exit():
    for _,path in list(_owned.items()):
        try:
            value=json.loads(path.read_text(encoding='utf-8'))
            if value['status']=='running':value.update(status='stopped_without_result',updated=time.time(),stage='Tiến trình đã dừng; chưa có kết quả đầy đủ');_write(path,value)
        except (OSError,ValueError):continue


atexit.register(_on_exit)


def _process(record):
    try:
        proc=psutil.Process(record['pid'])
        if abs(proc.create_time()-record['process_created'])>.25 or not proc.is_running():return False,{}
        processes=[proc]+proc.children(recursive=True);rss=commit=0
        for p in processes:
            try:info=p.memory_info();rss+=info.rss;commit+=getattr(info,'private',info.vms)
            except (psutil.NoSuchProcess,psutil.AccessDenied):continue
        return True,{'resident_tree_bytes':rss,'commit_tree_bytes':commit,'processes':len(processes)}
    except (psutil.NoSuchProcess,psutil.AccessDenied,KeyError):return False,{}


def dashboard(root):
    root=Path(root).resolve();directory=root/'local/experiment-status';jobs=[]
    files=sorted(directory.glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:16] if directory.exists() else []
    for path in files:
        try:
            if path.stat().st_size>196608:continue
            value=json.loads(path.read_text(encoding='utf-8'));alive,memory=_process(value)
            value['process_alive']=alive;value['process_resources']=memory
            if value.get('status')=='running' and not alive:value['status']='stopped_without_result';value['stage']='Không còn tiến trình; chưa có kết quả đầy đủ'
            if value.get('status')=='completed' and value.get('result',{}).get('primary_representation_gate') is True:
                statistics=primary_statistics(root,value.get('run_id'))
                if statistics:value['result']['primary_statistics']=statistics
            if value.get('status')=='completed':
                retention=retention_statistics(root,value.get('run_id'))
                if retention:value.setdefault('result',{})['retention_statistics']=retention
                product=product_statistics(root,value.get('run_id'))
                if product:value.setdefault('result',{})['product_trials']=product
                words=word_statistics(root,value.get('run_id'))
                if words:value.setdefault('result',{})['word_trials']=words
            jobs.append(value)
        except (OSError,ValueError):continue
    history=[]
    for title,name in CATALOG:
        path=root/'artifacts'/name
        try:
            if not path.is_file() or path.stat().st_size>5000000:continue
            value=json.loads(path.read_text(encoding='utf-8'));run=value.get('run')
            if not isinstance(run,str) or not run.startswith('runs/') or not RUN_ID.fullmatch(run[5:]):continue
            history.append({'title':title,'run_id':run[5:],'status':'completed','result':_summary(value),
              'report_url':'/api/research/report?run_id='+run[5:]})
        except (OSError,ValueError):continue
    return {'jobs':jobs,'history':history,'updated':time.time(),'note':'Kết quả và trace thí nghiệm tách khỏi phiên trò chuyện. Không có thao tác tự chạy lại job.'}


def primary_statistics(root,run_id):
    """Only finite registered confirmation metrics; no arbitrary result contents."""
    if not isinstance(run_id,str) or not RUN_ID.fullmatch(run_id):return {}
    base=(Path(root)/'runs').resolve();path=(base/run_id/'result.json').resolve()
    if not path.is_relative_to(base) or not path.is_file() or path.stat().st_size>262144:return {}
    try:
        data=json.loads(path.read_text(encoding='utf-8'));rows=data.get('confirmation_statistics',data.get('source_confirmation_statistics',{}));result={}
        if not isinstance(rows,dict):return {}
        def finite(value):return value if type(value) in (int,float) and math.isfinite(value) else None
        for task,row in list(rows.items())[:8]:
            if not isinstance(row,dict):continue
            gain=row.get('probe_gain',{});direct=row.get('direct',{})
            if not isinstance(gain,dict) or not isinstance(direct,dict):continue
            values={'gain':finite(gain.get('mean')),'lower95':finite(gain.get('lower95')),'upper95':finite(gain.get('upper95')),
                'direct':finite(direct.get('mean')),'seeds':finite(gain.get('n_seeds')),'holm_p':finite(row.get('holm_gain_p')),'pass':row.get('pass') is True}
            if all(values[k] is not None for k in ('gain','lower95','upper95','direct')):result[str(task)[:80]]=values
        return result
    except (OSError,ValueError,TypeError):return {}


def product_statistics(root,run_id):
    if not isinstance(run_id,str) or not RUN_ID.fullmatch(run_id):return []
    base=(Path(root)/'runs').resolve();path=(base/run_id/'result.json').resolve()
    if not path.is_relative_to(base) or not path.is_file() or path.stat().st_size>262144:return []
    try:
        value=json.loads(path.read_text(encoding='utf-8'));rows=value.get('conditions')
        return _safe(_product_trials(rows)) if isinstance(rows,list) else []
    except (OSError,ValueError,TypeError):return []


def word_statistics(root,run_id):
    """Bounded actual word-transfer metrics; never expose model/data paths."""
    if not isinstance(run_id,str) or not RUN_ID.fullmatch(run_id):return []
    base=(Path(root)/'runs').resolve();path=(base/run_id/'result.json').resolve()
    if not path.is_relative_to(base) or not path.is_file() or path.stat().st_size>262144:return []
    try:
        data=json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(data,dict):return []
        summary=data.get('summary',{});source=run_id;control_requested=data.get('control_only') is True
        if not isinstance(summary,dict):return []
        if not any(k in summary for k in ('legacy','known-sparse128-v1','known-digest128-v1')):
            linked=data.get('source_run')
            if not isinstance(linked,str) or not linked.startswith('runs/') or not RUN_ID.fullmatch(linked[5:]):return []
            source=linked[5:];path=(base/source/'result.json').resolve()
            if not path.is_relative_to(base) or not path.is_file() or path.stat().st_size>262144:return []
            data=json.loads(path.read_text(encoding='utf-8'))
            if not isinstance(data,dict):return []
            if control_requested and data.get('control_only') is not True:return []
            summary=data.get('summary',{})
            if not isinstance(summary,dict):return []
        decision=data.get('decision')
        if decision not in ('STOP_WORD_SCORE_INPUT_TRANSFER_V2','WORD_SCORE_INPUT_FRESH_VALIDATION_REQUIRED','ISOLATED_WORD_LEARNABILITY_CONTROL_ONLY'):decision=None
        rows=[]
        def metric(row,split,key):
            r=row.get(split,{});v=r.get(key) if isinstance(r,dict) else None
            return v if type(v) in (int,float) and math.isfinite(v) and 0<=v<=1 else None
        for encoding in ('legacy','known-sparse128-v1','known-digest128-v1'):
            variants=summary.get(encoding,{})
            if not isinstance(variants,dict):continue
            for condition in ('frozen','full','shuffled','local_reference'):
                if condition=='local_reference' and data.get('control_only') is not True:continue
                row=variants.get(condition)
                if not isinstance(row,dict):continue
                dev=metric(row,'development','normalized_style_exact')
                if dev is None:continue
                rows.append({'input_encoding':encoding,'condition':condition,'development':dev,
                    'prior':metric(row,'prior','normalized_style_exact'),'train16':metric(row,'train16','normalized_style_exact'),
                    'teacher_token_accuracy':metric(row,'development','teacher_token_accuracy'),'source_run':source,'source_quality_decision':decision,
                    'control_only':data.get('control_only') is True,
                    'method':('surrogate-BPTT · đối chứng' if condition=='full' else 'readout-only · baseline' if condition=='frozen' else 'local-score v2 · đã STOP') if data.get('control_only') is True else condition})
        return rows
    except (OSError,ValueError,TypeError):return []


def retention_statistics(root,run_id):
    """Finite P2 metrics, optionally from the one linked source run of an audit."""
    base=(Path(root)/'runs').resolve()
    def read(identifier):
        if not isinstance(identifier,str) or not RUN_ID.fullmatch(identifier):return None
        path=(base/identifier/'result.json').resolve()
        if not path.is_relative_to(base) or not path.is_file() or path.stat().st_size>262144:return None
        return json.loads(path.read_text(encoding='utf-8'))
    try:
        data=read(run_id)
        if not isinstance(data,dict):return {}
        summary=data.get('summary',{})
        def is_retention(value):return isinstance(value,dict) and any(isinstance(r,dict) and 'mean_forgetting' in r and 'final' in r for r in value.values())
        source=run_id
        if not is_retention(summary):
            linked=data.get('source_run')
            if not isinstance(linked,str) or not linked.startswith('runs/'):return {}
            source=linked[5:];data=read(source)
            if not isinstance(data,dict):return {}
            summary=data.get('summary',{})
        if not is_retention(summary):return {}
        rows={};gates=data.get('absolute_gates',{})
        if not isinstance(gates,dict):gates={}
        for name,row in list(summary.items())[:12]:
            if not isinstance(row,dict) or 'final' not in row:continue
            values={k:(row[k] if type(row.get(k)) in (int,float) and math.isfinite(row[k]) else None)
                for k in ('acquisition','final','mean_forgetting','worst_forgetting','joint_refit_probe')}
            if values['final'] is not None:
                rows[str(name)[:100]]={**values,'gate':gates.get(name) is True,'offline':str(name).startswith('offline')}
        return {'source_run':source,'rows':rows} if rows else {}
    except (OSError,ValueError,TypeError):return {}


def report(root,run_id):
    if not isinstance(run_id,str) or not RUN_ID.fullmatch(run_id):raise ValueError('Invalid run ID')
    base=(Path(root)/'runs').resolve();path=(base/run_id/'report.md').resolve()
    if not path.is_relative_to(base) or not path.is_file() or path.stat().st_size>400000:raise ValueError('Report unavailable or too large')
    return path.read_bytes()
