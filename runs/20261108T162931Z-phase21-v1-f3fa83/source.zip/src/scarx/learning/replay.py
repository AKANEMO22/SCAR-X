"""Fixed-capacity raw-sequence replay; task labels are explicit context cues."""
import json
import numpy as np


class ReplayBuffer:
    def __init__(self,capacity,steps,inputs,policy,seed):
        if policy not in ("none","reservoir","balanced"): raise ValueError("Replay policy")
        self.policy=policy; self.capacity=capacity; self.size=0; self.seen=0
        self.x=np.zeros((capacity,steps,inputs),np.float32)
        self.y=np.zeros(capacity,np.int32); self.context=np.zeros(capacity,np.int32)
        self.rng=np.random.default_rng(seed)

    def add(self,x,y,context):
        self.seen+=1
        if self.policy=="none": return
        if self.size<self.capacity:
            index=self.size; self.size+=1
        elif self.policy=="reservoir":
            index=int(self.rng.integers(self.seen))
            if index>=self.capacity: return
        else:
            groups=self.context[:self.size]*100+self.y[:self.size]
            group=context*100+y
            values,counts=np.unique(groups,return_counts=True)
            count=dict(zip(values.tolist(),counts.tolist()))
            maximum=int(counts.max())
            if count.get(group,0)<maximum:
                candidates=np.where(np.isin(groups,values[counts==maximum]))[0]
            else:
                candidates=np.where(groups==group)[0]
                if not len(candidates): return
            index=int(self.rng.choice(candidates))
        self.x[index]=x; self.y[index]=y; self.context[index]=context

    def sample(self,n):
        if not self.size: return []
        indices=self.rng.choice(self.size,size=n,replace=self.size<n)
        return [(self.x[i].copy(),int(self.y[i])) for i in indices]

    def save(self,path):
        metadata={"policy":self.policy,"capacity":self.capacity,"size":self.size,"seen":self.seen,"rng":self.rng.bit_generator.state}
        np.savez(path,x=self.x,y=self.y,context=self.context,metadata=np.array(json.dumps(metadata)))

    @classmethod
    def load(cls,path):
        with np.load(path,allow_pickle=False) as z:
            meta=json.loads(str(z["metadata"]))
            m=cls(meta["capacity"],z["x"].shape[1],z["x"].shape[2],meta["policy"],0)
            m.x[:]=z["x"]; m.y[:]=z["y"]; m.context[:]=z["context"]
            m.size=meta["size"]; m.seen=meta["seen"]; m.rng.bit_generator.state=meta["rng"]
        return m
