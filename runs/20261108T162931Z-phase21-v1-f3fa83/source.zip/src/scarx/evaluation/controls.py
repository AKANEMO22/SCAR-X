"""ISOLATED BACKPROP CONTROL. Never imported by production neural modules.

Same ALIF forward equations, sparse topology and initial weights. A triangular
surrogate derivative supplies BPTT. All synapses train, unlike rotating blocks
in the local rule; this compute difference is disclosed in the report.
"""
import json
from pathlib import Path
import time
import numpy as np
import torch
from ..neural.core import Config, SpikingCore
from ..runtime.resources import ResourceMonitor
from .tasks import episodes, accuracy
from .runs import new_run, write_json


class Spike(torch.autograd.Function):
    @staticmethod
    def forward(ctx,x):
        ctx.save_for_backward(x)
        return (x>=0).float()

    @staticmethod
    def backward(ctx,grad):
        (x,) = ctx.saved_tensors
        return grad*(1-x.abs()).clamp(min=0)


class BPTTControl:
    def __init__(self,config):
        self.config = config
        base = SpikingCore(config)
        self.parameters = [torch.tensor(getattr(base,n),requires_grad=True) for n in ("w_in","w_rec","w_out","bias")]
        self.indices = torch.tensor(base.indices,dtype=torch.long)
        self.optimizer = torch.optim.SGD(self.parameters,lr=config.readout_lr)
        self.logits = None

    def forward(self,sequence,track=False):
        c = self.config
        wi,wr,wo,b = self.parameters
        v,a,z,f = [torch.zeros(c.hidden) for _ in range(4)]
        with torch.set_grad_enabled(track):
            for item in sequence:
                x = torch.from_numpy(item)
                v = c.leak*v+wi@x+(wr*z[self.indices]).sum(dim=1)
                limit = c.threshold+c.adaptation_strength*a
                z = Spike.apply(v-limit)
                v = v-z*limit
                a = c.adaptation_decay*a+z
                f = c.feature_decay*f+(1-c.feature_decay)*z
            self.logits = wo@f+b
            return self.logits.softmax(dim=0).detach().numpy().copy()

    def learn(self,target):
        self.optimizer.zero_grad(set_to_none=True)
        loss = torch.nn.functional.cross_entropy(self.logits[None,:],torch.tensor([target]))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.parameters,1.)
        self.optimizer.step()
        with torch.no_grad():
            for p in self.parameters: p.clamp_(-self.config.weight_clip,self.config.weight_clip)
        return float(loss.detach())


def run_control(root):
    torch.set_num_threads(2)
    settings = json.loads((Path(root)/"configs/phase2.json").read_text())
    run = new_run(root,"bptt-control-v1",settings)
    rows = []
    with ResourceMonitor() as monitor:
        for seed in settings["seeds"]:
            c = Config(inputs=5,hidden=settings["hidden"],fan_in=settings["fan_in"],plastic_rows=settings["plastic_rows"],seed=seed)
            m = BPTTControl(c)
            start = time.perf_counter()
            for x,y in episodes(1000+seed,settings["train_examples"]):
                m.forward(x,track=True); m.learn(y)
            row = {"seed":seed,"accuracy":float(accuracy(m,list(episodes(2000+seed,settings["test_examples"]))).mean()),
                   "delayed_accuracy":float(accuracy(m,list(episodes(2500+seed,settings["test_examples"],delay=8))).mean()),
                   "seconds":time.perf_counter()-start}
            rows.append(row)
            print(row,flush=True)
            monitor.check()
    result = {"control_only":True,"trials":rows,"resources":monitor.report(),
              "torch_version":torch.__version__,"device":"cpu","continual_test":"not_run",
              "note":"Matched forward ALIF/topology/initialization and 512 training examples; surrogate BPTT updates all weights, uses temporal graph. Not local learning."}
    write_json(run/"result.json",result)
    (run/"report.md").write_text("# Backprop control only\n\n```json\n"+json.dumps(result,indent=2)+"\n```\n",encoding="utf-8")
    return run


if __name__ == "__main__":
    print(run_control(Path.cwd()))
