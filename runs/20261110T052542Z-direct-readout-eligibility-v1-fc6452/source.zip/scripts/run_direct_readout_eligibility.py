"""Preregistered proposal30 screen; no new serving model or globalbackward candidate."""
import os
for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[k]='1'
from pathlib import Path
import sys,json,time,itertools,subprocess,hashlib
from concurrent.futures import ProcessPoolExecutor,wait,FIRST_COMPLETED
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root/'src'))
import numpy as np
from direct_eligibility_common import TASKS,METHODS,DEV,CONFIRM
from direct_eligibility_worker import trial
from visual_word_control_common import atomic
from scarx.evaluation.runs import new_run,write_json
from scarx.evaluation.phase21 import interval,signflip,holm
from scarx.runtime.work_trace import activity
from scarx.runtime.experiment_status import progress
from scarx.runtime.resources import ResourceMonitor
from scarx.runtime.limits import apply_memory_limit


def child(job,run,monitor,deadline):
    phase,task,seed,method,_=job['trial'];mode=job['mode'];identifier=f'{phase}-{task}-{seed}-{method}';path=run/f'job-{identifier}-{mode}.json';atomic(path,job)
    out=(run/f'{identifier}-{mode}.stdout.log').open('wb');err=(run/f'{identifier}-{mode}.stderr.log').open('wb');started=time.perf_counter()
    p=subprocess.Popen([sys.executable,str(root/'scripts/direct_eligibility_worker.py'),'--job',str(path)],cwd=root,stdout=out,stderr=err,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
    signature=None
    try:
        while p.poll() is None:
            monitor.check()
            if time.perf_counter()>deadline:raise TimeoutError('Registered eligibility childdeadline')
            beat=run/f'heartbeat-{identifier}.json'
            if mode=='train' and beat.is_file() and beat.stat().st_size<65536:
                r=json.loads(beat.read_text(encoding='utf-8'))
                if r.get('examples')!=signature:
                    signature=r['examples'];progress(run,f'{identifier} · {signature}/1024',metrics={k:r[k] for k in ('task','seed','method','examples','loss_mean','hidden_updates','elapsed_seconds')},neural=r['neural'])
            time.sleep(.25)
        if p.returncode:raise RuntimeError(f'{identifier}/{mode} failed; actual logs retained')
    finally:
        if p.poll() is None:
            p.terminate()
            try:p.wait(timeout=5)
            except subprocess.TimeoutExpired:p.kill();p.wait()
        out.close();err.close()
    return time.perf_counter()-started


def cold_check(row,run,monitor,deadline):
    job=(row['phase'],row['task'],row['seed'],row['method'],str(run));checkpoint=root/row['checkpoint']
    assert hashlib.sha256(checkpoint.read_bytes()).hexdigest()==row['checkpoint_sha256']
    seconds=child({'mode':'cold','trial':job,'checkpoint':row['checkpoint'],'sha256':row['checkpoint_sha256']},run,monitor,min(deadline,time.perf_counter()+max(1.,180-row['seconds'])))
    path=run/f"cold-{row['phase']}-{row['task']}-{row['seed']}-{row['method']}.json"
    assert json.loads(path.read_text(encoding='utf-8'))==row.pop('cold_expected') and hashlib.sha256(checkpoint.read_bytes()).hexdigest()==row['checkpoint_sha256']
    row['cold_exact']=True;row['active_seconds_including_cold']=row['seconds']+seconds
    if row['active_seconds_including_cold']>180:raise TimeoutError('Eligibilitytrial incl cold exceeded180s')


def run_phase(phase,seeds,run,monitor,deadline):
    local=[(phase,t,s,c,str(run)) for t,s,c in itertools.product(TASKS,seeds,METHODS[:-1])];rows=[];pending={};todo=iter(local);signature=None
    progress(run,phase+' · localeligibility trials',0,len(seeds)*15)
    with ProcessPoolExecutor(max_workers=2) as pool:
        for _ in range(2):
            job=next(todo);pending[pool.submit(trial,job)]=job
        while pending:
            ready,_=wait(pending,timeout=.25,return_when=FIRST_COMPLETED);monitor.check()
            if time.perf_counter()>deadline:raise TimeoutError('Registered eligibilityphase deadline')
            beats=[run/f"heartbeat-{'-'.join(map(str,job[:4]))}.json" for job in pending.values()]
            beats=[p for p in beats if p.is_file()]
            if beats:
                newest=max(beats,key=lambda p:p.stat().st_mtime)
                if newest.stat().st_size<65536:
                    value=json.loads(newest.read_text(encoding='utf-8'));key=(newest.name,value['examples'])
                    if key!=signature:
                        signature=key;progress(run,f"{phase}/{value['task']}/seed{value['seed']}/{value['method']} · {value['examples']}/1024",len(rows),len(seeds)*15,
                            metrics={k:value[k] for k in ('task','seed','method','examples','loss_mean','hidden_updates','elapsed_seconds')},neural=value['neural'])
            for future in ready:
                row,neural=future.result();pending.pop(future);cold_check(row,run,monitor,deadline);rows.append(row);atomic(run/(phase+'-progress.json'),rows)
                progress(run,f"{phase}: {row['task']}/{row['seed']}/{row['method']} done/coldexact",len(rows),len(seeds)*15,metrics={k:row[k] for k in ('task','seed','method','direct','probe_gain','train_seconds')},neural=neural)
                print(json.dumps({k:row[k] for k in ('phase','task','seed','method','direct','probe_gain')}),flush=True)
                try:job=next(todo);pending[pool.submit(trial,job)]=job
                except StopIteration:pass
    # NumPyworkers have exited before any Torchchild, keeping totalmemory bounded.
    for task,seed in itertools.product(TASKS,seeds):
        job=(phase,task,seed,'bptt_control',str(run));progress(run,f'{phase}/{task}/{seed}/BPTT CONTROL initializing',len(rows),len(seeds)*15)
        child({'mode':'train','trial':job},run,monitor,min(deadline,time.perf_counter()+180))
        row=json.loads((run/f'{phase}-{task}-{seed}-bptt_control.json').read_text(encoding='utf-8'))['record'];cold_check(row,run,monitor,deadline);rows.append(row);atomic(run/(phase+'-progress.json'),rows)
        progress(run,f'{phase}/{task}/{seed}/BPTT CONTROL done/coldexact',len(rows),len(seeds)*15,metrics={k:row[k] for k in ('task','seed','method','direct','probe_gain')})
        print(json.dumps({k:row[k] for k in ('phase','task','seed','method','direct','probe_gain')}),flush=True)
    for task,seed in itertools.product(TASKS,seeds):
        zero=next(r for r in rows if r['task']==task and r['seed']==seed and r['method']=='zero');frozen=next(r for r in rows if r['task']==task and r['seed']==seed and r['method']=='frozen')
        assert zero['core_weight_fingerprint']==frozen['core_weight_fingerprint'] and zero['head_sha256']==frozen['head_sha256'] and all(zero[k]==frozen[k] for k in ('direct','probe','probe_gain'))
    return rows


def summary(rows):
    return {t:{method:{k:float(np.mean([r[k] for r in rows if r['task']==t and r['method']==method])) for k in ('direct','probe','probe_gain','bag_only','train_seconds','probe_time_permuted','probe_state_reset')} for method in METHODS} for t in TASKS}


def main():
    if hasattr(sys.stdout,'reconfigure'):sys.stdout.reconfigure(encoding='utf-8')
    cap=apply_memory_limit();began=time.perf_counter();engineering=json.loads((root/'artifacts/direct-eligibility-engineering.json').read_text(encoding='utf-8'))
    assert engineering['formal_screen_permitted'] and engineering['proposal30_approved']
    manifest=json.loads((root/engineering['run']/'manifest.json').read_text(encoding='utf-8'))
    for name in ('src/scarx/evaluation/readout_eligibility.py','src/scarx/evaluation/controls.py','src/scarx/evaluation/readout_conditioning.py','src/scarx/neural/core.py','src/scarx/evaluation/tasks21.py','src/scarx/evaluation/binding_audit21.py','scripts/direct_eligibility_common.py','experiments/direct-readout-eligibility-v1.md'):
        assert hashlib.sha256((root/name).read_bytes()).hexdigest()==manifest['source_sha256'][name],name
    run=new_run(root,'direct-readout-eligibility-v1',{'protocol':'experiments/direct-readout-eligibility-v1.md','display_title':'PROPOSAL30 · one-stepreadouterror/localeligibility',
        'model_scope':'APPROVED RESEARCH, no deployment. SameALIF, forwardown-neuron traces; BPTT onlyisolatedcontrol. Numerictemporalclassifiers, NOT normalchat/vision.',
        'proposal30_approved':True,'development_seeds':DEV,'confirmation_seeds':CONFIRM,'tasks':TASKS,'methods':METHODS,'examples_per_trial':1024,
        'engineering_run':engineering['run'],'num_workers':2,'torch_children_at_once':1})
    (run/'report.md').write_text('# Proposal30 localeligibility screen\n\nActual training in progress, no mainquality/deployment claim. All criteria fixed before scores.\n',encoding='utf-8')
    activity(run,'Bắt đầu45thử nghiệm cơ chế30 đãduyệt','P0math64/partialcheckpoint/zero-frozen qua.3freshseed×3task×5methods,1024experiences. MainALIF/Hermesgiữ nguyên; khôngTransformer/networkbackwardcandidate.',status='started',evidence={'engineering':engineering['run'],'registered_protocol':'experiments/direct-readout-eligibility-v1.md','formal_trials':45})
    confirmation=[];stats={}
    with ResourceMonitor(interval=.1) as monitor:
        development=run_phase('development',DEV,run,monitor,began+1800);atomic(run/'development.json',development);screen_summary=summary(development)
        valid={t:all(r['bag_only']<=.6 for r in development if r['task']==t) for t in TASKS}
        screen_tasks={}
        for task in TASKS:
            correct=screen_summary[task]['correct'];frozen=screen_summary[task]['frozen']
            screen_tasks[task]={'valid_bag_baseline':valid[task],'mean_probe_gain':correct['probe_gain'],'mean_direct':correct['direct'],
                'mean_probe_vs_frozen':correct['probe']-frozen['probe'],'pass':valid[task] and correct['probe_gain']>=.05 and correct['direct']>=.65 and correct['probe']>frozen['probe']}
        screen=sum(r['pass'] for r in screen_tasks.values())>=2 and any(screen_tasks[t]['pass'] for t in ('xor','strict_binding'))
        selection={'fixed_rule_no_parameter_selection':True,'screen_tasks':screen_tasks,'screen_pass':screen,'confirmation_opened':False}
        atomic(run/'screen-locked.json',selection)
        forecast_confirm=96*engineering['timing']['correct']['forecast_trial_with25pct_headroom']+24*engineering['timing']['bptt_control']['forecast_trial_with25pct_headroom']
        if screen and forecast_confirm<3600:
            selection['confirmation_opened']=True;confirmation=run_phase('confirmation',CONFIRM,run,monitor,time.perf_counter()+3600);atomic(run/'confirmation.json',confirmation)
            for task in TASKS:
                full=[r for r in confirmation if r['task']==task and r['method']=='correct'];gain=[r['probe_gain'] for r in full]
                def contrast(method):return [r['probe']-next(b['probe'] for b in confirmation if b['task']==task and b['seed']==r['seed'] and b['method']==method) for r in full]
                diff=contrast('frozen');stats[task]={'probe_gain':interval(gain),'direct':interval([r['direct'] for r in full]),'vs_frozen':interval(diff),'vs_shuffled':interval(contrast('shuffled')),
                    'gain_p':signflip(gain),'vs_frozen_p':signflip(diff),'valid_bag_baseline':all(r['bag_only']<=.6 for r in confirmation if r['task']==task)}
            gp=holm([stats[t]['gain_p'] for t in TASKS]);fp=holm([stats[t]['vs_frozen_p'] for t in TASKS])
            for i,t in enumerate(TASKS):
                v=stats[t];v['holm_gain_p']=gp[i];v['holm_vs_frozen_p']=fp[i]
                v['pass']=v['valid_bag_baseline'] and v['probe_gain']['lower95']>=.05 and v['direct']['mean']>=.65 and v['vs_frozen']['mean']>0 and gp[i]<=.05 and fp[i]<=.05
        gate=sum(r.get('pass',False) for r in stats.values())>=2 and any(stats.get(t,{}).get('pass',False) for t in ('xor','strict_binding'))
        decision='GO_DIRECT_ELIGIBILITY_P2_RESEARCH_ONLY' if gate else 'CONFIRM_DIRECT_READOUT_ELIGIBILITY_REQUIRED' if screen and not confirmation else 'STOP_DIRECT_READOUT_ELIGIBILITY_V1'
        actual=confirmation or development;result={'run':run.relative_to(root).as_posix(),'decision':decision,'proposal30_approved':True,'selection':selection,'confirmation_statistics':stats,
            'control_summary':summary(actual),'primary_representation_gate':gate,'screen_trials':len(development),'confirmation_trials':len(confirmation),
            'all_cold_exact':True,'zero_frozen_equivalence':True,'deployed':False,'main_weights_changed':False,'normal_chat_or_vision_proven':False,'retention_proven':False,
            'candidate_network_backward':False,'candidate_signal_locality':'One learned readout-error transport, own-neuron forwardtrace; not fullybiological local/exactgradient.',
            'engineering_run':engineering['run'],'resources':monitor.report(),'cap':cap,'seconds':time.perf_counter()-began,
            'limits':['Fresh3developmentseeds; confirmation8onlyifscreenpassed. Order isweakrecency/delayed task, not complexreasoning.',
                'Readout-only localdelta and correct/shuffled/zero hiddenablations; BPTTcontrol separate extra graphcost, not main.',
                'No word/vision/retention/modelscale or deployment authorization follows from toyrepresentationgate.']}
        (run/'report.md').write_text('# Approved proposal30 research\n\n'+decision+'\n\nNo productioncore/weightschange; no normalchat/vision/P2claim.\n\n'+json.dumps(result,indent=2)+'\n',encoding='utf-8')
        write_json(run/'result.json',result);write_json(root/'artifacts/direct-eligibility-latest.json',result)
        activity(run,'Hoàn tất cơ chế30 boundedresearch',decision+'; actualtrials/coldresumes/ablation giữnguồn. Không đổiqualitygate hoặc đưa candidate/control vàoHermes.',evidence={'decision':decision,'screen_trials':len(development),'confirmation_trials':len(confirmation),'primary_representation_gate':gate})
        print(json.dumps({'run':result['run'],'decision':decision,'selection':selection,'confirmation_statistics':stats,'control_summary':result['control_summary'],'resources':result['resources']},ensure_ascii=False))


if __name__=='__main__':main()
