"""ISOLATED BACKPROP CONTROL. Never imported by production neural modules.

Same ALIF forward equations, sparse topology and initial weights. A triangular
surrogate derivative supplies BPTT. All synapses train, unlike rotating blocks
in the local rule; this compute difference is disclosed in the report.
"""
import json
from pathlib import Path
import time
import numpy as np
import torch
from ..neural.core import Config, SpikingCore
from ..runtime.resources import ResourceMonitor
from .tasks import episodes, accuracy
from .runs import new_run, write_json


class Spike(torch.autograd.Function):
    @staticmethod
    def forward(ctx,x):
        ctx.save_for_backward(x)
        return (x>=0).float()

    @staticmethod
    def backward(ctx,grad):
        (x,) = ctx.saved_tensors
        return grad*(1-x.abs()).clamp(min=0)


class BPTTControl:
    def __init__(self,config):
        self.config = config
        base = SpikingCore(config)
        self.parameters = [torch.tensor(getattr(base,n),requires_grad=True) for n in ("w_in","w_rec","w_out","bias")]
        self.indices = torch.tensor(base.indices,dtype=torch.long)
        self.optimizer = torch.optim.SGD(self.parameters,lr=config.readout_lr)
        self.logits = None

    def forward(self,sequence,track=False):
        c = self.config
        wi,wr,wo,b = self.parameters
        v,a,z,f = [torch.zeros(c.hidden) for _ in range(4)]
        with torch.set_grad_enabled(track):
            for item in sequence:
                x = torch.from_numpy(item)
                v = c.leak*v+wi@x+(wr*z[self.indices]).sum(dim=1)
                limit = c.threshold+c.adaptation_strength*a
                z = Spike.apply(v-limit)
                v = v-z*limit
                a = c.adaptation_decay*a+z
                f = c.feature_decay*f+(1-c.feature_decay)*z
            self.logits = wo@f+b
            return self.logits.softmax(dim=0).detach().numpy().copy()

    def learn(self,target):
        self.optimizer.zero_grad(set_to_none=True)
        loss = torch.nn.functional.cross_entropy(self.logits[None,:],torch.tensor([target]))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(self.parameters,1.)
        self.optimizer.step()
        with torch.no_grad():
            for p in self.parameters: p.clamp_(-self.config.weight_clip,self.config.weight_clip)
        return float(loss.detach())


def run_control(root):
    torch.set_num_threads(2)
    settings = json.loads((Path(root)/"configs/phase2.json").read_text())
    run = new_run(root,"bptt-control-v1",settings)
    rows = []
    with ResourceMonitor() as monitor:
        for seed in settings["seeds"]:
            c = Config(inputs=5,hidden=settings["hidden"],fan_in=settings["fan_in"],plastic_rows=settings["plastic_rows"],seed=seed)
            m = BPTTControl(c)
            start = time.perf_counter()
            for x,y in episodes(1000+seed,settings["train_examples"]):
                m.forward(x,track=True); m.learn(y)
            row = {"seed":seed,"accuracy":float(accuracy(m,list(episodes(2000+seed,settings["test_examples"]))).mean()),
                   "delayed_accuracy":float(accuracy(m,list(episodes(2500+seed,settings["test_examples"],delay=8))).mean()),
                   "seconds":time.perf_counter()-start}
            rows.append(row)
            print(row,flush=True)
            monitor.check()
    result = {"control_only":True,"trials":rows,"resources":monitor.report(),
              "torch_version":torch.__version__,"device":"cpu","continual_test":"not_run",
              "note":"Matched forward ALIF/topology/initialization and 512 training examples; surrogate BPTT updates all weights, uses temporal graph. Not local learning."}
    write_json(run/"result.json",result)
    (run/"report.md").write_text("# Backprop control only\n\n```json\n"+json.dumps(result,indent=2)+"\n```\n",encoding="utf-8")
    return run


def run_phase21_control(root):
    from .tasks21 import representation
    torch.set_num_threads(1)
    settings=json.loads((Path(root)/'configs/phase21.json').read_text())
    output=new_run(root,'phase21-bptt-control-v1',settings); rows=[]
    with ResourceMonitor() as monitor:
        for seed in settings['confirmation_seeds']:
            for task in settings['representation_tasks']:
                model=BPTTControl(Config(inputs=8,outputs=2,hidden=48,fan_in=8,plastic_rows=12,seed=seed))
                x,y=representation(task,10000+seed,512)
                start=time.perf_counter()
                for seq,label in zip(x,y): model.forward(seq,track=True); model.learn(int(label))
                elapsed=time.perf_counter()-start
                tx,ty=representation(task,30000+seed,256)
                correct=[int(np.argmax(model.forward(seq)))==label for seq,label in zip(tx,ty)]
                row={'seed':seed,'task':task,'accuracy':float(np.mean(correct)),'train_seconds':elapsed,'updates':512}
                rows.append(row)
                with (output/'trials.jsonl').open('a') as f: f.write(json.dumps(row)+'\n')
                print('BPTT21 '+json.dumps(row),flush=True); monitor.check()
    result={'trials':rows,'resources':monitor.report(),'control_only':True,
            'caveat':'Same sparse shape and training examples; deterministic surrogate-ALIF vs stochastic local network. Updates matched, actual CPU time reported; not evidence of fully matched hardware efficiency.'}
    write_json(output/'result.json',result)
    (output/'report.md').write_text('# Phase2.1 isolated BPTT control\n\n```json\n'+json.dumps(result,indent=2)+'\n```\n')
    return output


class ByteBPTTControl:
    """Isolated same-forward byte learner. Never a production/local-learning path."""
    def __init__(self, calibrated_byte_model, hidden_frozen=False):
        from ..neural.input_events import InputEvents
        self.config=calibrated_byte_model.core.config
        self.encoder=InputEvents(256)
        self.parameters=[torch.tensor(getattr(calibrated_byte_model.core,n),requires_grad=(not hidden_frozen or n in ('w_out','bias')))
          for n in ('w_in','w_rec','w_out','bias')]
        self.indices=torch.tensor(calibrated_byte_model.core.indices,dtype=torch.long)
        self.state=[torch.tensor(getattr(calibrated_byte_model.core,n)) for n in ('voltage','adaptation','spikes','features')]
        self.mean=torch.tensor(calibrated_byte_model.head.mean.astype(np.float32))
        self.scale=torch.tensor(np.maximum(np.sqrt(calibrated_byte_model.head.m2/(calibrated_byte_model.head.count-1)),.05).astype(np.float32))
        self.optimizer=torch.optim.Adam([p for p in self.parameters if p.requires_grad],lr=.001)
        self.updates=0;self.byte_steps=0;self.hidden_frozen=hidden_frozen

    def step(self,x):
        c=self.config;wi,wr,wo,b=self.parameters;v,a,z,f=self.state
        current=wi@torch.as_tensor(x,dtype=torch.float32)+(wr*z[self.indices]).sum(dim=1)
        v=c.leak*v+current
        limit=c.threshold+c.adaptation_strength*a;z=Spike.apply(v-limit);v=v-z*limit
        a=c.adaptation_decay*a+z;f=c.feature_decay*f+(1-c.feature_decay)*z
        self.state=[v,a,z,f]

    def prepare(self,messages):
        events=self.encoder.dialogue(messages)
        self.state=[s.detach() for s in self.state]
        for _ in range(12):self.step(np.zeros(454,np.float32))
        context=events[:,256:384].sum(0);context/=max(1.,float(np.linalg.norm(context)))
        for x in events:self.step(x)
        return context

    def byte_step(self,previous,context,position):
        x=np.zeros(454,np.float32)
        if previous>=2:x[previous-2]=.8
        x[256:384]=context*1.6;x[-6:]=[1.,0.,-1. if previous==1 else .2,position/128.,.2*np.sin(position),.2*np.cos(position)]
        for _ in range(3):self.step(x)
        self.byte_steps+=1

    def logits(self,mask):
        f=((self.state[3]-self.mean)/self.scale).clamp(-5,5)
        return (self.parameters[2]@f+self.parameters[3]).masked_fill(~torch.as_tensor(mask),float('-inf'))

    def learn(self,messages,target):
        from ..neural.byte_codec import UTF8Codec,UTF8Cursor
        tokens=UTF8Codec.encode(target);cursor=UTF8Cursor();context=self.prepare(messages);previous=1;losses=[]
        self.optimizer.zero_grad(set_to_none=True)
        for position,token in enumerate(tokens+[0]):
            self.byte_step(previous,context,position)
            losses.append(torch.nn.functional.cross_entropy(self.logits(cursor.mask(257-position))[None,:],torch.tensor([token])))
            if token:cursor.accept(token)
            previous=token
        loss=torch.stack(losses).mean();loss.backward()
        torch.nn.utils.clip_grad_norm_([p for p in self.parameters if p.requires_grad],1.)
        self.optimizer.step()
        with torch.no_grad():
            for index,p in enumerate(self.parameters):p.clamp_(-20 if index<2 else -3,20 if index<2 else 3)
        self.updates+=1
        return float(loss.detach())

    def generate(self,messages,max_bytes=128):
        from ..neural.byte_codec import UTF8Codec,UTF8Cursor
        with torch.no_grad():
            cursor=UTF8Cursor();context=self.prepare(messages);previous=1;tokens=[];stopped=False
            for position in range(max_bytes):
                self.byte_step(previous,context,position);token=int(self.logits(cursor.mask(max_bytes-position)).argmax())
                if token==0:stopped=True;break
                cursor.accept(token);tokens.append(token);previous=token
            return {'text':UTF8Codec.decode(tokens),'stopped':stopped,'bytes':len(tokens),'utf8_valid':True}

    def score(self,examples):
        from ..neural.byte_codec import UTF8Codec,UTF8Cursor
        from ..neural.language import tokenize
        saved=[s.detach().clone() for s in self.state];steps=self.byte_steps
        outputs=[];count=0;correct=0;nll=0.
        try:
            with torch.no_grad():
                for row in examples:
                    generated=self.generate(row['messages']);text=generated['text'];tokens=UTF8Codec.encode(row['target'])
                    outputs.append({'id':row['id'],'target':row['target'],'generated':text,'exact':tokenize(text)==tokenize(row['target']),'stopped':generated['stopped']})
                    cursor=UTF8Cursor();context=self.prepare(row['messages']);previous=1
                    for position,token in enumerate(tokens+[0]):
                        self.byte_step(previous,context,position);logits=self.logits(cursor.mask(257-position))
                        nll+=float(torch.nn.functional.cross_entropy(logits[None,:],torch.tensor([token])));correct+=int(logits.argmax()==token);count+=1
                        if token:cursor.accept(token)
                        previous=token
        finally:self.state=saved;self.byte_steps=steps
        return {'exact':sum(r['exact'] for r in outputs)/len(outputs),'byte_nll':nll/count,'teacher_forced_byte_accuracy':correct/count,'target_bytes_including_eos':count,'outputs':outputs}

    def export_arrays(self,path):
        arrays={n:p.detach().numpy() for n,p in zip(('w_in','w_rec','w_out','bias'),self.parameters)}
        arrays.update({n:s.detach().numpy() for n,s in zip(('voltage','adaptation','spikes','features'),self.state)})
        arrays.update(mean=self.mean.numpy(),scale=self.scale.numpy(),indices=self.indices.numpy())
        np.savez(path,metadata=np.array(json.dumps({'format':'isolated-byte-bptt-control-arrays','not_a_scarx_checkpoint':True,'optimizer_resume_included':False,'updates':self.updates})),**arrays)


if __name__ == "__main__":
    import sys
    print(run_phase21_control(Path.cwd()) if '--phase21' in sys.argv else run_control(Path.cwd()))
