"""Read real inference/learning transactions. No training or job-launch on GET."""
import json,time
from datetime import datetime
from pathlib import Path
from ..runtime.work_trace import read


def answers_case(root, identifier):
    """Pinned public corpus/reference; labels never enter neural input."""
    if not isinstance(identifier,str) or len(identifier)>80:raise ValueError('Invalid case ID')
    root=Path(root).resolve()
    reference=json.loads((root/'artifacts/qwen-dialogue-reference-latest.json').read_text(encoding='utf-8'))
    data=(root/reference['data']).resolve()
    if not data.is_relative_to(root/'data/candidates'):raise ValueError('Invalid corpus path')
    records=[json.loads(line) for line in (data/'experiences.jsonl').read_text(encoding='utf-8').splitlines()]
    case=next((r for r in records if r['id']==identifier and r['split']=='development'),None)
    if case is None:raise ValueError('Unknown public development case')
    qwen=next((r for r in reference['outputs'] if r['id']==identifier),None)
    if qwen is None or qwen['messages']!=case['messages'] or qwen['one_reference_target']!=case['target']:
        raise ValueError('Reference and dataset disagree')
    manifest=(root/reference['run']/'manifest.json').resolve()
    if not manifest.is_relative_to(root/'runs'):raise ValueError('Invalid reference run')
    measured=json.loads(manifest.read_text(encoding='utf-8'))['created_utc']
    return case,{'generated':qwen['generated'],'finish_reason':qwen['finish_reason'],'measured_at_utc':measured,
        'run':reference['run'],'scope':'archived measured Qwen3-4B; full prefix; not live or an oracle'}


def observe_answer(app,root,data):
    case,reference=answers_case(root,data.get('case_id'))
    prompt=next(m['text'] for m in reversed(case['messages']) if m['role']=='user')
    return app.chat(prompt,record_experience=False,observation={'case_id':case['id'],
        'messages':case['messages'],'target':case['target'],'qwen':reference,
        'input_scope':'SCAR-X receives latest user text only; Qwen received full prefix. Not an equal-context quality benchmark.'})


def feed(app,root):
    with app.lock:
        rows=app.db.execute("SELECT id,created,action,details FROM events WHERE action IN ('answer-trace','teach','online-learn','online-reject') ORDER BY id DESC LIMIT 180").fetchall()
        controller={'accepted':app.dialogue.accepted_updates,'rejected':app.dialogue.rejected_updates,
            'queued':sum(l['status']=='queued' for l in app.dialogue.lessons),'updates':app.model.core.updates}
        live=[]
        for identifier,created,action,details in rows:
            item=json.loads(details);stamp=datetime.fromisoformat(created).timestamp()
            live.append({**item,'event_id':f'live-{identifier}','time':stamp,'kind':'answer' if action=='answer-trace' else 'learning',
                'action':action,'scope':'Lõi đang dùng','run_id':None})
    records=live+read(Path(root).resolve())
    records.sort(key=lambda r:r['time'],reverse=True)
    return {'answers':[r for r in records if r['kind']=='answer'][:60],
        'learning':[r for r in records if r['kind']=='learning'][:100],
        'controller':controller,'updated':time.time()}
