"""Bounded retry for transient Windows readers denying atomic replacement."""
import os,time


def replace_with_retry(source,target,attempts=20):
    if type(attempts) is not int or not 1<=attempts<=40:raise ValueError('Bounded replace attempts required')
    for index in range(attempts):
        try:
            os.replace(source,target);return
        except PermissionError:
            if index+1==attempts:raise
            time.sleep(min(.005*(index+1),.05))
