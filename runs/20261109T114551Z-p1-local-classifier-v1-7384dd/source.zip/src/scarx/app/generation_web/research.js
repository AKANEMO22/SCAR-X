(() => {
  const el=id=>document.getElementById(id);
  const statuses={idle:'Chưa chạy',running:'Đang chạy',completed:'Đã có kết quả',failed:'Lỗi',cancelled:'Đã dừng',stopped_without_result:'Đã dừng / thiếu kết quả'};
  let loading=false,data=null,selectedJob='',selectedStep=null,lastDemoStart=null;
  function node(tag,text,cls){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;}
  async function call(path,body){
    const options={};
    if(body!==undefined){
      const status=await (await fetch('/api/status')).json();
      Object.assign(options,{method:'POST',headers:{'Content-Type':'application/json','X-SCARX-Token':status.token},body:JSON.stringify(body)});
    }
    const response=await fetch(path,options),result=await response.json();
    if(!response.ok)throw new Error(typeof result.error==='string'?result.error:result.error?.message||'Không đọc được trạng thái');
    return result;
  }
  function neurons(canvas,snapshot){
    const c=canvas.getContext('2d'),w=canvas.width,h=canvas.height;c.clearRect(0,0,w,h);
    if(!snapshot||!Array.isArray(snapshot.spikes)){
      c.fillStyle='#92a5ab';c.font='13px Segoe UI';c.fillText('Chưa có trace từ lượt này.',20,35);return;
    }
    const count=snapshot.allocated||snapshot.spikes.length,active=snapshot.computed??count;
    const cols=Math.ceil(Math.sqrt(count*2.6)),rows=Math.ceil(count/cols);
    for(let i=0;i<count;i++){
      const x=20+(i%cols)*(w-40)/Math.max(1,cols-1),y=24+Math.floor(i/cols)*(h-46)/Math.max(1,rows-1);
      const dormant=i>=active,spike=!dormant&&snapshot.spikes[i];
      c.beginPath();c.arc(x,y,spike?6:4,0,Math.PI*2);c.strokeStyle=dormant?'#60727a':spike?'#b8efc7':'#607e8b';
      if(!dormant){c.fillStyle=spike?'#b8efc7':'#294553';c.fill();}c.stroke();
      c.fillStyle='#92a5ab';c.font='8px Consolas';c.textAlign='center';c.fillText(String(i),x,y+15);
    }
  }
  function drawDemo(demo){
    el('demo-status').textContent=statuses[demo.status]||demo.status;el('demo-start').disabled=demo.status==='running';
    el('demo-note').textContent=demo.note||'';el('demo-error').hidden=!demo.error;if(demo.error)el('demo-error').textContent=demo.error;
    if(demo.started!==lastDemoStart){selectedStep=null;lastDemoStart=demo.started;}
    const steps=demo.steps||[],body=el('demo-steps');body.replaceChildren();
    if(!steps.length){const tr=node('tr'),td=node('td','Chưa có task được đo.','muted');td.colSpan=6;tr.append(td);body.append(tr);}
    steps.forEach((row,index)=>{
      const tr=node('tr');tr.dataset.selected=String(selectedStep===index);
      const first=node('td'),button=node('button',row.title,'secondary task-select');
      button.onclick=()=>{selectedStep=index;drawDemo(data.capacity_demo);};first.append(button);tr.append(first);
      [row.words,row.active,row.allocated,row.dormant,row.grew_by?'+'+row.grew_by:'0'].forEach(v=>tr.append(node('td',String(v))));body.append(tr);
    });
    const index=selectedStep===null?steps.length-1:selectedStep,row=steps[index];
    if(row){
      const frames=row.frames||[],frame=frames[frames.length-1];neurons(el('demo-neurons'),frame);
      el('demo-counts').textContent=`${row.active} đang tính / ${row.allocated} đã cấp / ${row.max_neurons} tối đa · ${row.dormant} ngủ · ${row.neural_ticks} tick thực`;
      const detail=el('demo-detail');detail.replaceChildren(node('strong',row.title),node('p',row.prompt));
      detail.append(node('p',`Cùng object core: ${row.same_core_identity?'có':'chưa xác nhận'} · Cấp thêm ${row.grew_by} · Mảng neural ${(row.neural_arrays_bytes/1000).toFixed(1)} KB · Tính thực ${(row.inference_seconds*1000).toFixed(1)} ms.`));
      detail.append(node('p','Đầu ra neural chưa xác minh: '+(row.generated||'[rỗng]')),
        node('p','Mức huy động theo tải; không chứng minh task khó hơn hoặc thêm neuron làm đúng hơn. Nhịp chờ hiển thị tách khỏi thời gian tính.'));
    }else neurons(el('demo-neurons'),null);
  }
  function drawJobs(jobs){
    const select=el('research-job'),ids=jobs.map(j=>j.run_id);
    if(!ids.includes(selectedJob))selectedJob=ids[0]||'';
    select.replaceChildren();
    jobs.forEach(j=>{const option=node('option',`${statuses[j.status]||j.status} · ${j.run_id}`);option.value=j.run_id;select.append(option);});
    select.value=selectedJob;
    if(!jobs.length){el('research-current').textContent='Chưa có job mới đang được theo dõi. Các kết quả đã chạy ở bên dưới.';neurons(el('research-neurons'),null);return;}
    const job=jobs.find(j=>j.run_id===selectedJob),current=el('research-current'),wasOpen=!!current.querySelector('details')?.open;current.replaceChildren(node('strong',statuses[job.status]||job.status),node('p',job.stage));
    if(job.task)current.append(node('p','Bài: '+job.task));
    const resources=job.process_resources||{},progress=job.progress||{};
    el('research-progress').max=progress.total||1;el('research-progress').value=progress.completed||0;
    el('research-metrics').textContent=[progress.total?`${progress.completed||0}/${progress.total} lượt`:null,
      resources.resident_tree_bytes?`${(resources.resident_tree_bytes/1e6).toFixed(1)} MB RSS`:null,
      job.process_alive?'Đã xác nhận tiến trình còn sống':'Không báo chạy chỉ từ file trạng thái'].filter(Boolean).join(' · ');
    const advanced=node('details'),summary=node('summary','Cấu hình và số đo'),pre=node('pre',JSON.stringify({configuration:job.config,metrics:job.metrics,result:job.result},null,2));advanced.open=wasOpen;advanced.append(summary,pre);current.append(advanced);
    const events=el('research-events');events.replaceChildren();
    (job.events||[]).slice(-8).reverse().forEach(event=>events.append(node('p',new Date(event.time*1000).toLocaleTimeString('vi-VN')+' · '+event.stage)));
    neurons(el('research-neurons'),job.neural);
    if(job.neural){const n=job.neural;el('research-neural-counts').textContent=`${n.computed??n.spikes?.length} đang tính / ${n.allocated??n.spikes?.length} đã cấp · tick ${n.tick??'—'} · mẫu thật gần nhất, không phải độc thoại nội tâm.`;}
    else el('research-neural-counts').textContent='Lượt này chưa công bố mẫu neuron; không tạo trace giả.';
  }
  function drawHistory(history){
    const box=el('research-history'),opened=new Set([...box.querySelectorAll('details[open]')].map(d=>d.dataset.run));box.replaceChildren();
    history.forEach(item=>{
      const details=node('details'),summary=node('summary',item.title+' · '+(item.result.decision||'Đã có kết quả'));
      details.dataset.run=item.run_id;details.open=opened.has(item.run_id);
      const link=node('a','Mở báo cáo nguồn ↗');link.href=item.report_url;link.target='_blank';link.rel='noopener';
      details.append(summary,link,node('pre',JSON.stringify(item.result,null,2)));box.append(details);
    });
  }
  async function poll(){
    if(loading)return;loading=true;
    try{
      data=await call('/api/research');el('research-connection').textContent='● Trạng thái được cập nhật';el('research-error').hidden=true;
      const live=data.live_capacity;el('capacity-live').textContent=`Lõi trò chuyện hiện: ${live.active} đang tính / ${live.allocated} đã cấp / ${live.maximum} tối đa.`;
      if(live.workload)el('capacity-live').textContent+=` Lượt gần nhất: ${live.workload.input_characters} ký tự, ${live.workload.active_neurons} neuron.`;
      drawDemo(data.capacity_demo);drawJobs(data.jobs);drawHistory(data.history);
    }catch(error){el('research-connection').textContent='○ Chưa kết nối';el('research-error').hidden=false;el('research-error').textContent=error.message;}
    finally{loading=false;}
  }
  el('demo-start').onclick=async()=>{
    el('demo-start').disabled=true;
    try{await call('/api/capacity-demo',{origin:el('demo-origin').value});await poll();}
    catch(error){el('demo-error').hidden=false;el('demo-error').textContent=error.message;el('demo-start').disabled=false;}
  };
  el('research-job').onchange=()=>{selectedJob=el('research-job').value;if(data)drawJobs(data.jobs);};
  poll();setInterval(poll,1500);
})();
