"""Real bounded allocation/compute demonstration on a checkpoint clone."""
import threading,time,hashlib,json
from pathlib import Path
import numpy as np
from ..neural.unified import UnifiedCore
from .workload import plan_workload,finish_workload


def cases():
    short='Chào bạn.'
    story='An đến thư viện để đọc sách. Bình mang theo một cuốn sổ. Hai bạn chọn một bàn gần cửa sổ rồi cùng ghi lại những điều vừa đọc.'
    items=[('greeting','Chào hỏi ngắn',short),('summary','Tóm tắt một đoạn','Tóm tắt đoạn sau: '+story)]
    items.append(('relations','Theo dõi nhiều sự kiện','Ai giữ cuốn sổ ở cuối câu chuyện? '+story+' An đưa sổ cho Bình. Bình đưa sổ cho Chi. Chi đi sang phòng bên cạnh, gặp Dũng rồi đưa cuốn sổ cho Dũng. Dũng đọc một trang và đưa sổ lại cho An. Hãy theo dõi thứ tự thay vì chỉ đếm tên.'))
    items.append(('long_input','Tải đầu vào dài','Tóm tắt và phân biệt những sự kiện lặp lại trong các đoạn sau. '+story+' '+story+' '+story+' '+story))
    items.append(('return','Quay về đầu vào ngắn',short))
    return items


class CapacityLab:
    def __init__(self,app):
        self.app=app;self.lock=threading.Lock();self.stop=threading.Event();self.thread=None
        self.value={'status':'idle','steps':[],'frames':[],'note':'Chưa chạy. Thử trên bản sao checkpoint, không sửa phiên trò chuyện.'}

    def status(self):
        with self.lock:return json.loads(json.dumps(self.value,ensure_ascii=False))

    def start(self,origin='release'):
        if origin not in ('release','current'):raise ValueError('Origin release/current')
        with self.lock:
            if self.thread is not None and self.thread.is_alive():return {'started':False,'reason':'Một lượt đang chạy','status':self.value['status']}
        with self.app.lock:
            if origin=='current':payload=self.app.model.dumps()
            else:
                root=Path(__file__).resolve().parents[3];info=json.loads((root/'artifacts/generation1-release.json').read_text(encoding='utf-8'))
                path=(root/info['checkpoint']).resolve()
                if not path.is_relative_to((root/'artifacts').resolve()):raise ValueError('Release path')
                payload=path.read_bytes()
                if hashlib.sha256(payload).hexdigest()!=info['sha256']:raise ValueError('Release checksum')
        self.stop.clear()
        with self.lock:
            self.value={'status':'running','origin':origin,'started':time.time(),'steps':[],'frames':[],
              'note':'Chọn neuron theo lượng đầu vào/loại dữ liệu; chưa đo độ khó ngữ nghĩa. Không học hoặc sửa phiên đang dùng.'}
            self.thread=threading.Thread(target=self._run,args=(payload,),daemon=True,name='scarx-capacity-lab');self.thread.start()
        return {'started':True,'status':'running'}

    def _run(self,payload):
        try:
            model=UnifiedCore.loads(payload);identity=id(model.core);initial_updates=model.core.updates
            for index,(identifier,title,prompt) in enumerate(cases()):
                if self.stop.is_set():break
                while self.app.pending and not self.stop.wait(.02):pass
                allocated_before=model.core.config.hidden;planned=plan_workload(model,prompt)
                model.select_capacity(planned['requested_neurons']);start_ticks=model.ticks;began=time.perf_counter();frames=[]
                def on_tick(kind,source):
                    if len(frames)>=24:return
                    c=model.core
                    frames.append({'kind':kind,'tick':model.ticks,'computed':model.active_count,'allocated':c.config.hidden,
                      'spikes':[int(v) if i<model.active_count else 0 for i,v in enumerate(c.spikes)],'voltage':np.round(c.voltage,4).tolist()})
                model.on_tick=on_tick;generated=model.generate(prompt,max_words=8);model.on_tick=None
                workload=finish_workload(model,planned,self.app.process.memory_info().rss)
                row={'id':identifier,'title':title,'prompt':prompt,'words':len(prompt.split()),'allocated_before':allocated_before,
                  'allocated':model.core.config.hidden,'active':model.active_count,'dormant':model.core.config.hidden-model.active_count,
                  'grew_by':model.core.config.hidden-allocated_before,'max_neurons':model.max_neurons,'neural_ticks':model.ticks-start_ticks,
                  'inference_seconds':time.perf_counter()-began,'neural_arrays_bytes':model.core.memory_bytes(),
                  'process_rss_bytes':workload['process_rss_bytes'],'generated':generated['text'],'quality_verified':False,
                  'reason':planned['allocation_reason'],'same_core_identity':id(model.core)==identity,'weights_updated':False,'frames':frames}
                with self.lock:
                    self.value['steps'].append(row);self.value['frames']=frames;self.value['current']=title;self.value['progress']={'completed':index+1,'total':len(cases())}
                # Display dwell is separate from actual inference time above.
                # It lets the user see each measured transition without pretending
                # that waiting is additional neural reasoning.
                if self.stop.wait(.9):break
            if model.core.updates!=initial_updates:raise RuntimeError('Demo unexpectedly learned')
            with self.lock:self.value.update(status='cancelled' if self.stop.is_set() else 'completed',finished=time.time(),display_dwell_seconds=.9)
        except Exception as exc:
            with self.lock:self.value.update(status='failed',error=str(exc)[:300],finished=time.time())

    def close(self):
        self.stop.set()
        if self.thread:self.thread.join(timeout=1)
