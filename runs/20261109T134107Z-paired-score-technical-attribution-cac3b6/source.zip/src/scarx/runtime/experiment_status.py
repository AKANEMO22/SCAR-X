"""Bounded local experiment observability; never launch/restart a job here."""
import atexit,json,os,re,time,tempfile,threading
from pathlib import Path
import psutil

_owned={};_lock=threading.RLock()
RUN_ID=re.compile(r'^[A-Za-z0-9][A-Za-z0-9._-]{0,160}$')
CATALOG=(
 ('Audit optimizer và coverage / chỉ đối chứng','p1-control-factors-latest.json'),
 ('Audit local classifier / vòng cuối','p1-local-classifier-v2-audit.json'),
 ('Local classifier / vòng cuối','p1-local-classifier-v2-latest.json'),
 ('Trace thực trên lõi đang dùng','live-observatory-latest.json'),
 ('Tạo dữ liệu Antigravity','antigravity-generation-latest.json'),
 ('Local classifier / P1','p1-local-classifier-latest.json'),
 ('Ảnh thật / đối chứng đã audit','rgb-object-grounding-audit.json'),
 ('Bộ nhớ làm việc khi phát byte','byte-working-memory-latest.json'),
 ('Audit trạng thái decoder','decoder-state-retention-audit.json'),
 ('BPTT chỉ làm đối chứng','byte-bptt-control-latest.json'),
 ('Decoder UTF-8','byte-dialogue-latest.json'),
 ('Hội thoại và Qwen4B','qwen-dialogue-reference-latest.json'),
 ('Prototype hội thoại theo sự kiện','event-dialogue-latest.json'),
 ('Chuẩn hóa readout / 20 context','p2-conditioning-confirmation-latest.json'),
 ('Random feedback / đã dừng','p1-random-feedback-latest.json'))


def _safe(value,depth=0):
    if depth>5:return '[truncated]'
    if value is None or isinstance(value,(bool,int)):return value
    if isinstance(value,float):return value if value==value and abs(value)!=float('inf') else None
    if isinstance(value,str):return value[:800]
    if isinstance(value,dict):return {str(k)[:80]:_safe(v,depth+1) for k,v in list(value.items())[:48] if str(k).lower() not in ('token','password','api_key','authorization','secret','credentials','headers')}
    if isinstance(value,(list,tuple)):return [_safe(v,depth+1) for v in value[:128]]
    return str(value)[:160]


def _location(run):
    run=Path(run).resolve()
    if run.parent.name!='runs' or not RUN_ID.fullmatch(run.name):raise ValueError('Expected registered run directory')
    return run.parent.parent/'local/experiment-status'/(run.name+'.json')


def _write(path,value):
    raw=json.dumps(_safe(value),ensure_ascii=False,allow_nan=False).encode()
    if len(raw)>196608:raise ValueError('Experiment status exceeds192KB')
    path.parent.mkdir(parents=True,exist_ok=True);fd,tmp=tempfile.mkstemp(dir=path.parent,suffix='.tmp')
    try:
        with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def start_run(run,config):
    path=_location(run);proc=psutil.Process()
    record={'run_id':Path(run).name,'run':f'runs/{Path(run).name}','kind':config.get('observability_kind','research_clone'),
      'title':config.get('display_title',Path(run).name),'model_scope':config.get('model_scope','Bản thử nghiệm; không thay model trò chuyện'),
      'pid':proc.pid,'process_created':proc.create_time(),'started':time.time(),'updated':time.time(),'status':'running',
      'stage':'Đã đăng ký lượt chạy','config':_safe(config),'events':[],'progress':None,'neural':None}
    with _lock:_write(path,record);_owned[str(Path(run).resolve())]=path


def progress(run,stage,completed=None,total=None,metrics=None,neural=None,task=None):
    path=_location(run)
    with _lock:
        if not path.exists():return
        value=json.loads(path.read_text(encoding='utf-8'));value['updated']=time.time();value['stage']=str(stage)[:300]
        if value.get('pid')!=os.getpid():return # parent owns the journal; workers return measurements to it
        value['progress']={'completed':completed,'total':total}
        if metrics is not None:value['metrics']=_safe(metrics)
        if neural is not None:value['neural']=_safe(neural)
        if task is not None:value['task']=str(task)[:200]
        value['events']=(value.get('events',[])+[{'time':time.time(),'stage':stage,'progress':value['progress'],'metrics':_safe(metrics)}])[-40:]
        _write(path,value)


def complete_run(run,result):
    path=_location(run)
    with _lock:
        if not path.exists():return
        value=json.loads(path.read_text(encoding='utf-8'));value.update(status='completed',updated=time.time(),finished=time.time(),stage='Đã có kết quả')
        if value.get('pid')!=os.getpid():return
        value['result']=_summary(result);_write(path,value)


def _summary(value):
    keys=('decision','summary','selection','direct_gate','primary_representation_gate','normal_chat_or_vision_proven','normal_photo_qa_proven',
      'normal_chat_vision_proven','deployed','live_model_replaced','resources','screen_trials','confirmation_trials','metric_correction','image_grounding_gate',
      'successful_batches','expected_batches','trained','validation_pending','control_summary','all_matched','all_cold_exact')
    return _safe({k:value[k] for k in keys if k in value})


def _on_exit():
    for _,path in list(_owned.items()):
        try:
            value=json.loads(path.read_text(encoding='utf-8'))
            if value['status']=='running':value.update(status='stopped_without_result',updated=time.time(),stage='Tiến trình đã dừng; chưa có kết quả đầy đủ');_write(path,value)
        except (OSError,ValueError):continue


atexit.register(_on_exit)


def _process(record):
    try:
        proc=psutil.Process(record['pid'])
        if abs(proc.create_time()-record['process_created'])>.25 or not proc.is_running():return False,{}
        processes=[proc]+proc.children(recursive=True);rss=commit=0
        for p in processes:
            try:info=p.memory_info();rss+=info.rss;commit+=getattr(info,'private',info.vms)
            except (psutil.NoSuchProcess,psutil.AccessDenied):continue
        return True,{'resident_tree_bytes':rss,'commit_tree_bytes':commit,'processes':len(processes)}
    except (psutil.NoSuchProcess,psutil.AccessDenied,KeyError):return False,{}


def dashboard(root):
    root=Path(root).resolve();directory=root/'local/experiment-status';jobs=[]
    files=sorted(directory.glob('*.json'),key=lambda p:p.stat().st_mtime,reverse=True)[:16] if directory.exists() else []
    for path in files:
        try:
            if path.stat().st_size>196608:continue
            value=json.loads(path.read_text(encoding='utf-8'));alive,memory=_process(value)
            value['process_alive']=alive;value['process_resources']=memory
            if value.get('status')=='running' and not alive:value['status']='stopped_without_result';value['stage']='Không còn tiến trình; chưa có kết quả đầy đủ'
            jobs.append(value)
        except (OSError,ValueError):continue
    history=[]
    for title,name in CATALOG:
        path=root/'artifacts'/name
        try:
            if not path.is_file() or path.stat().st_size>5000000:continue
            value=json.loads(path.read_text(encoding='utf-8'));run=value.get('run')
            if not isinstance(run,str) or not run.startswith('runs/') or not RUN_ID.fullmatch(run[5:]):continue
            history.append({'title':title,'run_id':run[5:],'status':'completed','result':_summary(value),
              'report_url':'/api/research/report?run_id='+run[5:]})
        except (OSError,ValueError):continue
    return {'jobs':jobs,'history':history,'updated':time.time(),'note':'Kết quả và trace thí nghiệm tách khỏi phiên trò chuyện. Không có thao tác tự chạy lại job.'}


def report(root,run_id):
    if not isinstance(run_id,str) or not RUN_ID.fullmatch(run_id):raise ValueError('Invalid run ID')
    base=(Path(root)/'runs').resolve();path=(base/run_id/'report.md').resolve()
    if not path.is_relative_to(base) or not path.is_file() or path.stat().st_size>400000:raise ValueError('Report unavailable or too large')
    return path.read_bytes()
