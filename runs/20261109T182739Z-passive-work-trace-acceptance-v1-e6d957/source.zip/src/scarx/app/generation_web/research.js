(() => {
  const el=id=>document.getElementById(id);
  const statuses={idle:'Chưa chạy',running:'Đang chạy',completed:'Đã có kết quả',failed:'Lỗi',cancelled:'Đã dừng',stopped_without_result:'Đã dừng / thiếu kết quả'};
  let loading=false,traceLoading=false;
  let demoSignature='',historySignature='',answerSignature='',learningSignature='',jobSignature='',activitySignature='';
  function node(tag,text,cls){const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;}
  async function call(path,body){
    const options={};
    if(body!==undefined){
      const status=await (await fetch('/api/status')).json();
      Object.assign(options,{method:'POST',headers:{'Content-Type':'application/json','X-SCARX-Token':status.token},body:JSON.stringify(body)});
    }
    const response=await fetch(path,options),result=await response.json();
    if(!response.ok)throw new Error(typeof result.error==='string'?result.error:result.error?.message||'Không đọc được trạng thái');
    return result;
  }
  function neurons(canvas,snapshot){
    const c=canvas.getContext('2d'),w=canvas.width,h=canvas.height;c.clearRect(0,0,w,h);
    if(!snapshot||!Array.isArray(snapshot.spikes)){
      c.fillStyle='#92a5ab';c.font='13px Segoe UI';c.fillText('Chưa có trace từ lượt này.',20,35);return;
    }
    const count=snapshot.allocated||snapshot.spikes.length,active=snapshot.computed??count;
    const cols=Math.ceil(Math.sqrt(count*2.6)),rows=Math.ceil(count/cols);
    for(let i=0;i<count;i++){
      const x=20+(i%cols)*(w-40)/Math.max(1,cols-1),y=24+Math.floor(i/cols)*(h-46)/Math.max(1,rows-1);
      const dormant=i>=active,spike=!dormant&&snapshot.spikes[i];
      c.beginPath();c.arc(x,y,spike?6:4,0,Math.PI*2);c.strokeStyle=dormant?'#60727a':spike?'#b8efc7':'#607e8b';
      if(!dormant){c.fillStyle=spike?'#b8efc7':'#294553';c.fill();}c.stroke();
      c.fillStyle='#92a5ab';c.font='8px Consolas';c.textAlign='center';c.fillText(String(i),x,y+15);
    }
  }
  function drawDemo(demo){
    const signature=JSON.stringify([demo.status,demo.started,demo.steps?.length,demo.error]);
    if(signature===demoSignature)return;demoSignature=signature;
    el('demo-status').textContent=statuses[demo.status]||demo.status;
    el('demo-note').textContent=(demo.restored_history?'Kết quả lượt gần nhất đã lưu, không phải job còn chạy. ':'')+(demo.note||'');el('demo-error').hidden=!demo.error;if(demo.error)el('demo-error').textContent=demo.error;
    const steps=demo.steps||[],body=el('demo-steps');body.replaceChildren();
    if(!steps.length){const tr=node('tr'),td=node('td','Chưa có task được đo.','muted');td.colSpan=6;tr.append(td);body.append(tr);}
    steps.forEach((row,index)=>{
      const tr=node('tr');tr.dataset.selected=String(index===steps.length-1);
      tr.append(node('td',row.title));
      [row.words,row.active,row.allocated,row.dormant,row.grew_by?'+'+row.grew_by:'0'].forEach(v=>tr.append(node('td',String(v))));body.append(tr);
    });
    const row=steps[steps.length-1];
    if(row){
      const frames=row.frames||[],frame=frames[frames.length-1];neurons(el('demo-neurons'),frame);
      el('demo-counts').textContent=`${row.active} đang tính / ${row.allocated} đã cấp / ${row.max_neurons} tối đa · ${row.dormant} ngủ · ${row.neural_ticks} tick thực`;
      const detail=el('demo-detail');detail.replaceChildren(node('strong',row.title),node('p',row.prompt));
      detail.append(node('p',`Cùng object core: ${row.same_core_identity?'có':'chưa xác nhận'} · Cấp thêm ${row.grew_by} · Mảng neural ${(row.neural_arrays_bytes/1000).toFixed(1)} KB · ${row.timing_includes_persistence?'Cả lượt (gồm lưu trạng thái)':'Xử lý neural'} ${(row.inference_seconds*1000).toFixed(1)} ms.`));
      detail.append(node('p','Đầu ra neural chưa xác minh: '+(row.generated||'[rỗng]')),
        node('p','Mức huy động theo tải; không chứng minh task khó hơn hoặc thêm neuron làm đúng hơn. Nhịp chờ hiển thị tách khỏi thời gian tính.'));
    }else neurons(el('demo-neurons'),null);
  }
  function drawJobs(jobs){
    if(!jobs.length){el('research-current').textContent='Chưa có job mới đang được theo dõi. Các kết quả đã chạy ở bên dưới.';neurons(el('research-neurons'),null);return;}
    const job=jobs.find(j=>j.status==='running')||jobs[0],signature=JSON.stringify(job);
    if(signature===jobSignature)return;jobSignature=signature;
    const current=el('research-current'),wasOpen=!!current.querySelector('details')?.open;current.replaceChildren(node('strong',statuses[job.status]||job.status),node('p',job.title||job.run_id),node('p',job.stage));
    if(job.task)current.append(node('p','Bài: '+job.task));
    if(job.model_scope)current.append(node('p',job.model_scope));
    if(job.kind==='data_generation')current.append(node('p','Lượt tạo dữ liệu này không huấn luyện neural core. Trạng thái sử dụng về sau được ghi riêng trong báo cáo học.','muted'));
    if(job.result?.decision)current.append(node('p','Kết luận: '+job.result.decision,'lab-verdict'));
    if(job.result?.deployed===false)current.append(node('p','Chưa thay model đang dùng.','muted'));
    if(job.result?.server_stopped===true)current.append(node('p',`Server đối chứng đã tắt · ${job.result.completed??'—'}/${job.result.expected??'—'} câu · ${job.result.truncated??'—'} câu bị giới hạn độ dài.`, 'muted'));
    if(job.result?.selection?.screen_pass===false)current.append(node('p','Chưa đạt ngưỡng representation. Không thay model đang dùng.'));
    if(job.result?.primary_representation_gate===true)current.append(node('p','Qua gate representation đã đăng ký. Chỉ mở nghiên cứu P2; chưa xác nhận retention hoặc năng lực hội thoại/ảnh.','lab-verdict'));
    if(job.result?.primary_statistics){
      const wrap=node('div',undefined,'table-scroll'),table=node('table',undefined,'lab-table'),head=node('tr');
      ['Bài','Gain hidden · CI95%','Accuracy','Seed / Holm p','Gate'].forEach(t=>head.append(node('th',t)));table.append(head);
      Object.entries(job.result.primary_statistics).forEach(([task,s])=>{const row=node('tr');
        [task,`${(s.gain*100).toFixed(2)}đ [${(s.lower95*100).toFixed(2)}; ${(s.upper95*100).toFixed(2)}]`,(s.direct*100).toFixed(2)+'%',`${s.seeds??'—'} / ${s.holm_p===null?'chưa ghi':s.holm_p.toFixed(4)}`,s.pass?'Qua':'Chưa qua'].forEach(t=>row.append(node('td',t)));table.append(row);});
      wrap.append(table);current.append(node('p','Xác nhận độc lập · gain từ refit probe so initial/frozen · CI bootstrap theo seed.','muted'),wrap);
    }
    if(job.result?.retention_statistics){
      const source=job.result.retention_statistics,wrap=node('div',undefined,'table-scroll'),table=node('table',undefined,'lab-table'),head=node('tr');
      ['Cấu hình P2','Học mới','Cuối','Quên TB / tệ nhất','Probe offline','Gate'].forEach(t=>head.append(node('th',t)));table.append(head);
      const pct=v=>typeof v==='number'?(v*100).toFixed(2)+'%':'—';
      const points=v=>typeof v==='number'?(v*100).toFixed(2)+'đ':'—';
      Object.entries(source.rows).forEach(([name,r])=>{const row=node('tr');
        [name,pct(r.acquisition),pct(r.final),r.offline?'không áp dụng':`${points(r.mean_forgetting)} / ${points(r.worst_forgetting)}`,pct(r.joint_refit_probe),r.offline?'Offline control':r.gate?'Qua':'Chưa qua'].forEach(t=>row.append(node('td',t)));table.append(row);});
      wrap.append(table);current.append(node('p','P2 · trung bình3seed, chưa confirmation; offline control có future labels. Quên tính theo điểm phần trăm, không phải tỷ lệ tương đối.','muted'),wrap);
      const link=node('a','Báo cáo P2 nguồn ↗');link.href='/api/research/report?run_id='+encodeURIComponent(source.source_run);link.target='_blank';link.rel='noopener';current.append(link);
    }
    const cueSummary=job.result?.summary;
    if(cueSummary?.public_release?.canonicalreset&&cueSummary?.current_private?.canonicalreset){
      const wrap=node('div',undefined,'table-scroll'),table=node('table',undefined,'lab-table'),head=node('tr');
      ['Checkpoint','Trạng thái trước câu hỏi','Câu quen','48 cách nói mới','Khác reset'].forEach(t=>head.append(node('th',t)));table.append(head);
      Object.entries(cueSummary).forEach(([scope,states])=>Object.entries(states).forEach(([state,r])=>{const row=node('tr');
        [scope,state,...['known_control_exact','antigravity_exact','disagreement_vs_reset'].map(k=>typeof r[k]==='number'?(r[k]*100).toFixed(2)+'%':'chưa ghi')].forEach(t=>row.append(node('td',t)));table.append(row);}));
      wrap.append(table);current.append(node('p','Exact-match tới một đáp án kiểu mẫu, không là điểm hiểu ngôn ngữ; hai checkpoint khác weights/vocabulary/capacity.','muted'),wrap);
    }
    if(job.result?.product_trials){
      const wrap=node('div',undefined,'table-scroll'),table=node('table',undefined,'lab-table'),head=node('tr');
      ['Mode / thứ tự','Dấu câu','Câu quen, reset','Cách nói mới, reset','Guard mất','Screen'].forEach(t=>head.append(node('th',t)));table.append(head);
      job.result.product_trials.forEach(r=>{const row=node('tr');
        [(r.mode||r.condition)+' / '+r.curriculum_order_seed,r.surface_normalization===undefined?'theo cấu hình':r.surface_normalization?'chuẩn hóa':'gốc',
          typeof r.known_reset==='number'?(r.known_reset*100).toFixed(2)+'%':'chưa ghi',typeof r.antigravity_reset==='number'?(r.antigravity_reset*100).toFixed(2)+'%':'chưa ghi',String(r.lost_guards_total??'chưa ghi'),r.screen_pass?'Qua':'Giữ model cũ'].forEach(t=>row.append(node('td',t)));table.append(row);});
      wrap.append(table);current.append(node('p','Product clone acceptance · exact-style trên8nhóm câu; guard cũ và runtime-normalized được ghi riêng trong báo cáo nguồn. Không chứng minh normalchat hoặc lifelongP2.','muted'),wrap);
    }
    if(cueSummary?.offline_joint_full?.baseline?.probe!==undefined){
      const wrap=node('div',undefined,'table-scroll'),table=node('table',undefined,'lab-table'),head=node('tr');
      ['Nguồn','Dynamics view','Head cũ','Refit probe','Gain'].forEach(t=>head.append(node('th',t)));table.append(head);
      Object.entries(cueSummary).forEach(([scope,views])=>Object.entries(views).forEach(([view,r])=>{const row=node('tr');
        [scope,view,...['direct','probe','gain'].map(k=>typeof r[k]==='number'?(r[k]*100).toFixed(2)+(k==='gain'?'đ':'%'):'chưa ghi')].forEach(t=>row.append(node('td',t)));table.append(row);}));
      wrap.append(table);current.append(node('p','Dynamics inference-view diagnostic; weights bất biến, refit head chưa triển khai.','muted'),wrap);
    }
    if(cueSummary&&Object.values(cueSummary).some(v=>v&&v['8']&&v['64']&&typeof v['8']['12']==='number')){
      const wrap=node('div',undefined,'table-scroll'),table=node('table',undefined,'lab-table'),head=node('tr');
      ['Feature nguồn','MC rollouts','Tick2','Tick6','Tick12'].forEach(t=>head.append(node('th',t)));table.append(head);
      Object.entries(cueSummary).forEach(([name,s])=>{if(!s?.['8']||!s?.['64'])return;
        ['8','64'].forEach(mc=>{const row=node('tr');[name,mc,...['2','6','12'].map(t=>Number.isFinite(s[mc][t])?(s[mc][t]*100).toFixed(2)+'%':'chưa ghi')].forEach(t=>row.append(node('td',t)));table.append(row);});});
      wrap.append(table);current.append(node('p','Chẩn đoán thông tin · refit head, không train core; MC64 dùng thêm8× lượt inference, không phải cải thiện cùng compute hoặc model đã triển khai.','muted'),wrap);
    }
    if(job.result?.control_summary){
      const wrap=node('div',undefined,'table-scroll'),table=node('table',undefined,'lab-table'),thead=node('thead'),labels=node('tr');
      ['Bài đo','Đối chứng','Accuracy','Hidden probe gain'].forEach(v=>labels.append(node('th',v)));thead.append(labels);table.append(thead);
      const body=node('tbody');
      Object.entries(job.result.control_summary).forEach(([task,conditions])=>Object.entries(conditions).forEach(([condition,value])=>{
        const row=node('tr'),accuracy=typeof value==='number'?value:value?.direct,gain=value?.probe_gain;
        [task,condition,typeof accuracy==='number'?(accuracy*100).toFixed(2)+'%':'chưa ghi',typeof gain==='number'?(gain*100).toFixed(2)+' điểm %':'chưa ghi'].forEach(v=>row.append(node('td',v)));body.append(row);
      }));table.append(body);wrap.append(table);current.append(node('p','So sánh các cấu hình của lượt thử · accuracy trên bộ bài đã công bố.','muted'),wrap);
    }
    const resources=job.process_resources||{},progress=job.progress||{};
    el('research-progress').max=progress.total||1;el('research-progress').value=progress.completed||0;
    el('research-metrics').textContent=[progress.total?`${progress.completed||0}/${progress.total} lượt`:null,
      resources.resident_tree_bytes?`${(resources.resident_tree_bytes/1e6).toFixed(1)} MB RSS`:null,
      job.process_alive?'Đã xác nhận tiến trình còn sống':'Không báo chạy chỉ từ file trạng thái'].filter(Boolean).join(' · ');
    const advanced=node('details'),summary=node('summary','Cấu hình và số đo'),pre=node('pre',JSON.stringify({configuration:job.config,metrics:job.metrics,result:job.result},null,2));advanced.open=wasOpen;advanced.append(summary,pre);current.append(advanced);
    const events=el('research-events');events.replaceChildren();
    (job.events||[]).slice(-8).reverse().forEach(event=>events.append(node('p',new Date(event.time*1000).toLocaleTimeString('vi-VN')+' · '+event.stage)));
    neurons(el('research-neurons'),job.neural);
    if(job.neural){const n=job.neural;el('research-neural-counts').textContent=`${n.computed??n.spikes?.length} đang tính / ${n.allocated??n.spikes?.length} đã cấp · tick ${n.tick??'—'} · mẫu thật gần nhất, không phải độc thoại nội tâm.`;}
    else el('research-neural-counts').textContent='Lượt này chưa công bố mẫu neuron; không tạo trace giả.';
  }
  function drawHistory(history){
    const signature=JSON.stringify(history);if(signature===historySignature)return;historySignature=signature;
    const box=el('research-history'),opened=new Set([...box.querySelectorAll('details[open]')].map(d=>d.dataset.run));box.replaceChildren();
    history.forEach(item=>{
      const details=node('details'),summary=node('summary',item.title+' · '+(item.result.decision||'Đã có kết quả'));
      details.dataset.run=item.run_id;details.open=opened.has(item.run_id);
      const link=node('a','Mở báo cáo nguồn ↗');link.href=item.report_url;link.target='_blank';link.rel='noopener';
      details.append(summary,link,node('pre',JSON.stringify(item.result,null,2)));box.append(details);
    });
  }
  async function poll(){
    if(loading)return;loading=true;
    try{
      const data=await call('/api/research');el('research-connection').textContent='● Trạng thái được cập nhật';el('research-error').hidden=true;
      const live=data.live_capacity;el('capacity-live').textContent=`Lõi trò chuyện hiện: ${live.active} đang tính / ${live.allocated} đã cấp / ${live.maximum} tối đa.`;
      if(live.workload)el('capacity-live').textContent+=` Lượt gần nhất: ${live.workload.input_characters} ký tự, ${live.workload.active_neurons} neuron.`;
      drawDemo(data.capacity_demo);drawJobs(data.jobs);drawHistory(data.history);
    }catch(error){el('research-connection').textContent='○ Chưa kết nối';el('research-error').hidden=false;el('research-error').textContent=error.message;}
    finally{loading=false;}
  }
  const stamp=row=>new Date(row.time*1000).toLocaleString('vi-VN');
  function field(parent,title,text){const box=node('div',undefined,'trace-field');box.append(node('small',title),node('p',text??'Chưa có'));parent.append(box);}
  function drawActivities(rows){
    const signature=JSON.stringify(rows);if(signature===activitySignature)return;activitySignature=signature;
    const box=el('activity-trace');if(!rows.length)return;box.replaceChildren();
    const labels={started:'Đã bắt đầu',completed:'Đã hoàn tất',failed:'Chưa đạt / lỗi'};
    rows.slice(0,12).forEach((row,index)=>{
      const card=node('details',undefined,'trace-card');card.open=index===0;
      card.append(node('summary',`${stamp(row)} · ${labels[row.status]||'Đã ghi nhận'} · ${row.title}`));
      field(card,'Công việc kỹ thuật',row.detail);
      if(row.evidence)field(card,'Bằng chứng đã ghi',JSON.stringify(row.evidence,null,2));
      const link=node('a','Lượt công việc / báo cáo nguồn ↗');link.href='/api/research/report?run_id='+encodeURIComponent(row.run_id);link.target='_blank';link.rel='noopener';card.append(link);box.append(card);
    });
  }
  function drawAnswers(rows){
    const signature=JSON.stringify(rows);if(signature===answerSignature)return;answerSignature=signature;
    const box=el('answer-trace');if(!rows.length)return;box.replaceChildren();
    rows.forEach((row,index)=>{
      const card=node('details',undefined,'trace-card');card.open=index===0;
      card.append(node('summary',`${stamp(row)} · ${row.scope||'Bản thử nghiệm'} · ${row.case_id||row.prompt||row.run_id}`));
      field(card,'Đầu vào / ngữ cảnh',row.messages?row.messages.map(m=>`${m.role}: ${m.text}`).join('\n'):row.prompt);
      field(card,'Đầu vào thực sự gửi SCAR-X',row.prompt);
      field(card,'Phạm vi đầu vào',row.input_scope);
      const grid=node('div',undefined,'answer-columns');
      field(grid,'SCAR-X sinh thực tế',row.generated===''?'[Đầu ra rỗng]':row.generated);
      field(grid,'Một đáp án mẫu · không phải nhãn tự học',row.target??'Không có đáp án mẫu cho lượt này');
      field(grid,'Qwen3-4B · bản đo đã lưu',row.qwen?.generated??'Chưa chạy Qwen cho cùng bài này');card.append(grid);
      if(row.qwen)card.append(node('p',`${row.qwen.scope} · ${row.qwen.measured_at_utc||row.qwen.run} · kết thúc: ${row.qwen.finish_reason}${row.qwen.finish_reason==='length'?' (đã bị cắt)':''}`,'muted'));
      card.append(node('p',`${row.neural_ticks??'—'} tick · ${row.active??'—'}/${row.allocated??'—'} neuron · ${row.seconds===undefined?'chưa ghi':row.seconds===0?'dưới độ phân giải đồng hồ cũ':(row.seconds*1000).toFixed(2)+' ms'} · checkpoint ${row.checkpoint??'chưa ghi'}`,'muted'));box.append(card);
    });
  }
  const fmt=v=>typeof v==='number'?v.toPrecision(4):'chưa ghi';
  const weights=value=>value?Object.entries(value).map(([k,v])=>`${k}: ${fmt(v)}`).join(' · '):'chưa ghi';
  function drawLearning(rows,controller){
    el('learning-counters').textContent=`${controller.accepted} giữ · ${controller.rejected} hoàn tác · ${controller.queued} bài chờ · ${controller.updates} bước cập nhật token`;
    const signature=JSON.stringify(rows);if(signature===learningSignature)return;learningSignature=signature;
    if(!rows.length)return;const box=el('learning-trace');box.replaceChildren();
    const points=rows.filter(r=>typeof r.loss_mean==='number').slice(0,40).reverse();
    const canvas=el('learning-loss'),ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);
    if(points.length){
      const max=Math.max(.01,...points.map(r=>r.loss_mean));ctx.strokeStyle='#60727a';ctx.beginPath();ctx.moveTo(45,12);ctx.lineTo(45,135);ctx.lineTo(975,135);ctx.stroke();
      ctx.fillStyle='#92a5ab';ctx.font='12px Segoe UI';ctx.fillText(max.toFixed(2),3,20);ctx.fillText('0',20,139);
      points.forEach((r,i)=>{const x=52+(points.length===1?0:i/(points.length-1))*910,y=132-r.loss_mean/max*112;
        ctx.fillStyle=r.rolled_back?'#f6a477':'#b8efc7';ctx.beginPath();ctx.arc(x,y,4,0,Math.PI*2);ctx.fill();});
      el('loss-caption').textContent=`${points.length} giao dịch có loss gần nhất, từ cũ → mới; có thể gồm nhiều bài khác nhau. Chấm cam = thử rồi rollback. Không nối thành loss huấn luyện của một dataset.`;
    }else el('loss-caption').textContent='Log cũ chưa ghi loss; không dựng đường giả.';
    rows.slice(0,30).forEach((row,index)=>{
      const card=node('details',undefined,'trace-card');card.open=index===0;
      const accepted=row.accepted??row.action!=='online-reject';
      card.append(node('summary',`${stamp(row)} · ${accepted?(row.guard_checked?'GUARD GIỮ':'ĐÃ GIỮ · guard chưa ghi/không dùng'):'ROLLBACK'} · loss ${fmt(row.loss_mean)} · ${row.prompt||row.run_id}`));
      field(card,'Nguồn / bài học',`${row.scope||'Bản thử nghiệm'} · ${row.prompt||'chưa ghi'} → ${row.target||'chưa ghi'}`);
      field(card,'Lượt học / loss',`${row.passes??row.repeats??'chưa ghi'} lượt · loss TB ${fmt(row.loss_mean)} · ${(row.losses||[]).map(fmt).join(' → ')||'chưa ghi từng lượt'}`);
      field(card,'Cập nhật synapse',`${row.update_steps??'chưa ghi'} bước ${row.update_unit||'token'} · số trọng số đổi ròng: ${row.changed_synapses?Object.entries(row.changed_synapses).map(([k,v])=>`${k}: ${v}`).join(' · '):'chưa ghi'}${row.hidden_update_steps!==undefined?' · '+row.hidden_update_steps+' hidden updates':''}`);
      field(card,'ΔW thử trước guard',weights(row.attempted_weight_delta));field(card,'ΔW giữ lại sau giao dịch',weights(row.weight_delta));
      field(card,'Guard',row.reason||`${row.guard_probe_count??'chưa ghi'} probe · mất ${row.guard_lost??'chưa ghi'} probe · ${row.rolled_back?'đã hoàn tác':accepted?'giao dịch được giữ':'chưa rõ'}`);
      if(row.stopped_identical_proposal)card.append(node('p',`Đã dừng sau ${row.identical_guard_rejections} đề xuất giống hệt bị guard từ chối. Trọng số giữ nguyên; không hạ ngưỡng để ép học.`, 'lab-verdict'));
      if(row.before!==undefined)field(card,'Sinh trước học → sau lần thử',`${row.before||'[rỗng]'} → ${row.after_attempt||'[rỗng]'}${row.rolled_back?' (bản thử này đã bị hoàn tác)':''}`);
      box.append(card);
    });
  }
  async function pollTrace(){
    if(traceLoading)return;traceLoading=true;
    try{const trace=await call('/api/trace');drawActivities(trace.activities||[]);drawAnswers(trace.answers);drawLearning(trace.learning,trace.controller);
      const connection='● Tự cập nhật · '+new Date().toLocaleTimeString('vi-VN');el('trace-connection').textContent=connection;el('activity-connection').textContent=connection;el('trace-error').hidden=true;}
    catch(error){el('trace-connection').textContent='○ Mất kết nối';el('activity-connection').textContent='○ Mất kết nối';el('trace-error').hidden=false;el('trace-error').textContent=error.message;}
    finally{traceLoading=false;}
  }
  poll();pollTrace();setInterval(poll,1500);setInterval(pollTrace,1500);
})();
