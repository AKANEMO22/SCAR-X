"""Explicit provider-owned stateful chat, separate from prompt-based agents.

The transcript is a UI ledger; the backend owns working state and learning.
No assumption that its input buffer describes neural memory or intelligence.
"""
from copy import deepcopy


def configure_stateful_chat(agent, config):
    agent._stateful_chat_backend = False
    endpoint = str(getattr(agent, 'base_url', '') or '').rstrip('/')
    model = str(getattr(agent, 'model', '') or '')
    providers = config.get('providers', {})
    if not endpoint or not isinstance(providers, dict):
        return False
    profile = next((p for p in providers.values() if isinstance(p, dict)
                    and p.get('interaction_mode') == 'stateful_chat'
                    and str(p.get('api', '')).rstrip('/') == endpoint
                    and isinstance(p.get('models'), (dict, list, tuple))
                    and model in p['models']), None)
    if profile is None:
        return False
    maximum = profile.get('max_input_characters')
    if type(maximum) is not int or maximum <= 0:
        raise ValueError('stateful_chat requires a positive max_input_characters')
    agent._stateful_chat_backend = True
    agent._stateful_chat_max_input_characters = maximum
    agent.tools = []
    agent.valid_tool_names = set()
    agent._tool_capability_names = frozenset()
    agent._tool_snapshot_generation = 0
    agent._kanban_worker_guidance = ''
    agent.enabled_toolsets = []
    agent.skip_context_files = True
    agent.skip_background_review = True
    agent.disable_persistent_search = True
    agent.ephemeral_system_prompt = None
    # A failed request must stay on the selected stateful service, rather than
    # falling back to a prompt-model with different state and learning semantics.
    agent._fallback_chain = []
    agent._fallback_model = None
    return True


def prepare_stateful_chat_turn(agent, user_message):
    if getattr(agent, 'tools', None):
        raise ValueError('stateful_chat does not support agent tools')
    maximum = agent._stateful_chat_max_input_characters
    if isinstance(user_message, str):
        text = user_message
    elif isinstance(user_message, list):
        text = '\n'.join(p.get('text', '') for p in user_message
                         if isinstance(p, dict) and p.get('type') == 'text')
    else:
        raise ValueError('stateful_chat needs text or multimodal content parts')
    if len(text) > maximum:
        raise ValueError(f'Stateful backend input limit: {maximum} characters per message; this is not a memory/context-capacity score.')
    if not text.strip() and not isinstance(user_message, list):
        raise ValueError('User message is empty')
    # Keep the actual caller data and persisted transcript immutable.
    agent._stateful_chat_raw_user_message = deepcopy(user_message)
    return deepcopy(user_message)
