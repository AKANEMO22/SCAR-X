import { cleanup, render, screen } from '@testing-library/react'
import { afterEach, expect, it } from 'vitest'

import { contextBarLabel, usageContextLabel } from '@/lib/statusbar'
import type { UsageStats } from '@/types/hermes'

import { ContextUsagePanel } from './context-usage-panel'

afterEach(cleanup)

it('does not display a transcript occupancy percentage as neural memory capacity', () => {
  const usage: UsageStats = {
    calls: 1, input: 0, output: 0, total: 0,
    context_mode: 'backend_state', input_limit_characters: 2048,
    context_max: 4096, context_used: 1800, context_percent: 44
  }
  expect(usageContextLabel(usage)).toBe('Backend state')
  expect(contextBarLabel(usage)).toBe('')
  render(<ContextUsagePanel breakdown={null} loading={false} usage={usage} />)
  expect(screen.getByText(/Input limit: 2048 characters/)).toBeTruthy()
  expect(screen.getByText(/Memory horizon, retained skills and learning capacity: not measured/)).toBeTruthy()
  expect(screen.queryByText(/44%/)).toBeNull()
})
