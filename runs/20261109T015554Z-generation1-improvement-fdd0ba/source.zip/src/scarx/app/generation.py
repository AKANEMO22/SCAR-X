"""Generation 1 session: one live core, bounded idle scheduler and atomic state."""
from collections import deque
from contextlib import contextmanager
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import sqlite3
import threading
import time
import uuid
import zipfile
import numpy as np
import psutil
from ..neural.unified import UnifiedCore
from ..runtime.resources import ResourceMonitor
from .locking import DirectoryLease

MODEL = 'scarx-generation1'
ROOT = Path(__file__).resolve().parents[3]


class Generation:
    def __init__(self, directory, seed=17, background=True, release=None):
        self.directory = Path(directory); self.directory.mkdir(parents=True, exist_ok=True)
        self.lock = threading.RLock(); self.queue_lock = threading.Lock()
        self.pending = 0; self.stop_event = threading.Event(); self.closed = False
        self.trace = deque(maxlen=256); self.sequence = 0
        self.idle_enabled = True; self.idle_hz = 20; self.idle_steps = 0
        self.probe = None; self.replay_cursor = 0; self.memories = []
        self.rng = np.random.default_rng(seed); self.active = None
        self.limit_status = {'enforced': False}; self.state = 'idle'; self.error = None
        self.lease = DirectoryLease(self.directory/'session.lock')
        self.db = None; self.monitor = None
        try:
            self.db = sqlite3.connect(self.directory/'generation1.sqlite', check_same_thread=False)
            self.db.execute('PRAGMA journal_mode=WAL'); self.db.execute('PRAGMA synchronous=FULL')
            self.db.executescript('''CREATE TABLE IF NOT EXISTS checkpoints(id TEXT PRIMARY KEY,created TEXT,action TEXT,sha TEXT,payload BLOB);
                CREATE TABLE IF NOT EXISTS runtime(singleton INTEGER PRIMARY KEY CHECK(singleton=1),sha TEXT,payload BLOB);
                CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY,created TEXT,action TEXT,details TEXT);''')
            row = self.db.execute('SELECT sha,payload FROM runtime WHERE singleton=1').fetchone()
            if row:
                if hashlib.sha256(row[1]).hexdigest() != row[0]: raise ValueError('Session checksum mismatch; giữ database để phục hồi.')
                self._unpack(row[1])
            else:
                descriptor = Path(release) if release else ROOT/'artifacts/generation1-release.json'
                info = json.loads(descriptor.read_text(encoding='utf-8'))
                checkpoint = (ROOT/info['checkpoint']).resolve()
                if not checkpoint.is_relative_to((ROOT/'artifacts').resolve()): raise ValueError('Release path outside artifacts')
                payload = checkpoint.read_bytes()
                if hashlib.sha256(payload).hexdigest() != info['sha256']: raise ValueError('Release checksum mismatch')
                self.model = UnifiedCore.loads(payload)
                self.memories = [{'prompt': p, 'source': 'project authored probe; no automatic label'} for p in ('chào bạn', 'hi', 'bạn là ai', 'bạn học được không')]
                self._commit('init')
            self.model.on_tick = self._tick
            self.process = psutil.Process(); self.process.cpu_percent(None)
            self.monitor = ResourceMonitor(interval=.5).__enter__()
            self.thread = threading.Thread(target=self._run, name='scarx-shared-core-idle', daemon=True)
            if background: self.thread.start()
        except BaseException:
            if self.monitor: self.monitor.__exit__(None,None,None)
            if self.db: self.db.close()
            self.lease.close(); raise

    def _pack(self):
        data = self.model.dumps()
        meta = {'format': 'scarx-generation1-session', 'sha256': hashlib.sha256(data).hexdigest(),
                'rng': self.rng.bit_generator.state, 'memories': self.memories,
                'probe': self.probe, 'replay_cursor': self.replay_cursor,
                'idle_enabled': self.idle_enabled, 'idle_hz': self.idle_hz,
                'idle_steps': self.idle_steps, 'sequence': self.sequence, 'active': self.active}
        stream = io.BytesIO()
        with zipfile.ZipFile(stream,'w') as archive:
            archive.writestr(zipfile.ZipInfo('model.zip'),data)
            archive.writestr(zipfile.ZipInfo('session.json'),json.dumps(meta,ensure_ascii=False))
        return stream.getvalue()

    def _unpack(self, payload):
        if len(payload)>3_000_000: raise ValueError('Session quá lớn')
        with zipfile.ZipFile(io.BytesIO(payload)) as archive:
            if len(archive.namelist())!=2 or set(archive.namelist())!={'model.zip','session.json'} or sum(i.file_size for i in archive.infolist())>3_000_000:
                raise ValueError('Session format')
            data=archive.read('model.zip'); meta=json.loads(archive.read('session.json'))
        if meta.get('format')!='scarx-generation1-session' or hashlib.sha256(data).hexdigest()!=meta['sha256']: raise ValueError('Session checksum')
        model=UnifiedCore.loads(data)
        memories=meta['memories']
        if not isinstance(memories,list) or len(memories)>128 or any(not isinstance(m,dict) or not isinstance(m.get('prompt'),str) or not 1<=len(m['prompt'])<=2048 or not isinstance(m.get('source'),str) for m in memories): raise ValueError('Invalid memory')
        if type(meta['idle_enabled']) is not bool or type(meta['idle_hz']) is not int or not 1<=meta['idle_hz']<=30: raise ValueError('Invalid idle policy')
        for name in ('idle_steps','sequence','replay_cursor'):
            if type(meta[name]) is not int or meta[name]<0: raise ValueError('Invalid controller counter')
        probe=meta['probe']
        if probe is not None:
            if not isinstance(probe,dict) or not isinstance(probe.get('prompt'),str) or not 1<=len(probe['prompt'])<=2048 or type(probe.get('position')) is not int or not 0<=probe['position']<=8 or type(probe.get('previous')) is not int or not 0<=probe['previous']<len(model.vocabulary) or not isinstance(probe.get('words'),list) or len(probe['words'])>8 or any(t not in model.ids for t in probe['words']): raise ValueError('Invalid pending probe')
        rng=np.random.default_rng(); rng.bit_generator.state=meta['rng']
        self.model=model; self.model.on_tick=self._tick; self.rng=rng
        self.memories=memories; self.probe=probe
        for name in ('idle_enabled','idle_hz','idle_steps','sequence','replay_cursor','active'):setattr(self,name,meta[name])

    def _persist(self):
        payload=self._pack()
        self.db.execute('INSERT OR REPLACE INTO runtime VALUES(1,?,?)',(hashlib.sha256(payload).hexdigest(),payload))

    def _commit(self, action, details=None):
        previous=self.active; identifier=uuid.uuid4().hex; self.active=identifier
        try:
            if self.db.execute('SELECT COUNT(*) FROM checkpoints').fetchone()[0]>=2000:raise ValueError('Đã đạt2000checkpoint; sao lưu/quản lý trước khi học tiếp.')
            payload=self._pack(); now=datetime.now(timezone.utc).isoformat()
            with self.db:
                self.db.execute('INSERT INTO checkpoints VALUES(?,?,?,?,?)',(identifier,now,action,hashlib.sha256(payload).hexdigest(),payload))
                self._persist()
                self.db.execute('INSERT INTO events(created,action,details) VALUES(?,?,?)',(now,action,json.dumps(details or {},ensure_ascii=False)))
        except BaseException:
            self.active=previous; raise
        return identifier

    @contextmanager
    def attention(self):
        with self.queue_lock:self.pending+=1
        try:
            with self.lock:
                if self.closed:raise RuntimeError('Session closed')
                self.state='foreground'
                try:yield
                finally:self.state='idle' if self.idle_enabled else 'paused'
        finally:
            with self.queue_lock:self.pending-=1

    def _tick(self, kind, source):
        c=self.model.core; self.sequence+=1
        self.trace.append({'id':self.sequence,'time':time.time(),'tick':self.model.ticks,
            'mode':self.state,'kind':kind,'source':str(source or 'recurrent dynamics; no external input')[:160],
            'spikes':c.spikes.astype(int).tolist(),'voltage':np.round(c.voltage,4).tolist(),
            'spiking':int(np.count_nonzero(c.spikes)),'computed':48,'allocated':48,
            'updates':c.updates,'eligibility_norm':float(np.linalg.norm(c.elig_rec)),
            'weights_updated':False})

    def idle_once(self):
        # Caller holds session lock. Exactly one bounded quantum of SAME core.
        self.idle_steps+=1
        if self.probe is None and self.memories and self.idle_steps%20==0:
            memory=self.memories[self.replay_cursor%len(self.memories)]; self.replay_cursor+=1
            self.probe={'prompt':memory['prompt'],'position':0,'previous':1,'words':[]}
            self.model.boundary()
        elif self.probe is not None:
            probe=self.probe
            p=self.model.word_step(probe['previous'],self.model.context(probe['prompt']),probe['position'],source=probe['prompt'])
            token=int(np.argmax(p)); probe['position']+=1
            if token!=0:probe['words'].append(self.model.vocabulary[token]); probe['previous']=token
            if token==0 or probe['position']>=8:
                self.sequence+=1
                self.trace.append({'id':self.sequence,'time':time.time(),'mode':'idle','kind':'probe_result',
                    'source':probe['prompt'],'generated':' '.join(probe['words']),'verified':False,
                    'weights_updated':False,'note':'Neural probe output; not a transcript of semantic thoughts or a learning label.'})
                self.probe=None
        else:self.model.tick(kind='idle')

    def _run(self):
        last_save=time.monotonic()
        while not self.stop_event.wait(1/max(1,self.idle_hz)):
            if self.pending or not self.lock.acquire(timeout=.002):continue
            try:
                if self.pending or not self.idle_enabled:continue
                if self.idle_steps % max(1,self.idle_hz)==0:self.monitor.check()
                self.state='idle'; self.idle_once()
                if time.monotonic()-last_save>=30:
                    with self.db:self._persist()
                    last_save=time.monotonic()
            except Exception as exc:
                self.error=f'{type(exc).__name__}: {exc}'; self.idle_enabled=False; self.state='paused'
            finally:self.lock.release()

    def chat(self, prompt, max_words=24):
        with self.attention():
            self.monitor.check(); self.probe=None
            result=self.model.generate(prompt,max_words)
            self.memories.append({'prompt':prompt,'source':'user input; content not automatically verified'})
            self.memories=self.memories[-128:]
            # Persist the evolving recurrent state without duplicating model objects.
            with self.db:self._persist()
            return {**result,'model':MODEL,'checkpoint':self.active,'quality_gate_passed':False}

    def vision(self, data):
        from .pilots import PilotLab
        pixels,digest=PilotLab.pixels(data.get('image'))
        with self.attention():
            self.monitor.check(); self.probe=None
            result=self.model.image(pixels)
            with self.db:self._persist()
            return {**result,'image_sha256':digest,'model':MODEL,'checkpoint':self.active,'presentation':'server-formatted digit classification from shared core'}

    def teach(self, data):
        if data.get('confirmation') is not True:raise ValueError('Cần xác nhận lời dạy rõ ràng.')
        prompt=data.get('prompt'); answer=data.get('answer'); repeats=data.get('repeats',16)
        if not isinstance(answer,str) or type(repeats) is not int or not 1<=repeats<=32:raise ValueError('Câu trả lời dạngtext; repeats1–32.')
        self.model.context(prompt)
        with self.attention():
            self.monitor.check(); original=self._pack(); self.probe=None
            before={name:getattr(self.model.core,name).copy() for name in ('w_in','w_rec','w_out')}
            try:
                output_before=self.model.generate(prompt); began=time.monotonic()
                for _ in range(repeats):
                    self.model.train_pair(prompt,answer); self.monitor.check()
                    if time.monotonic()-began>15:raise TimeoutError('Teaching15s budget')
                output_after=self.model.generate(prompt)
                delta={name:float(np.linalg.norm(getattr(self.model.core,name)-old)) for name,old in before.items()}
                self.memories.append({'prompt':prompt,'source':'explicit user lesson, not independently verified','answer':answer})
                self.memories=self.memories[-128:]
                checkpoint=self._commit('teach',{'prompt':prompt,'repeats':repeats,'verified':False,'weight_delta':delta})
                self.sequence+=1;self.trace.append({'id':self.sequence,'time':time.time(),'kind':'learning_update','mode':'foreground','weights_updated':True,'delta':delta,'source':prompt})
                return {'before':output_before,'after':output_after,'weight_delta':delta,'checkpoint':checkpoint,'verified':False,'note':'Explicit human teaching; factual correctness is not automatically established.'}
            except BaseException:
                self._unpack(original);self.trace.clear();raise

    def configure(self, data):
        enabled=data.get('enabled',self.idle_enabled); hz=data.get('hz',self.idle_hz)
        if type(enabled) is not bool or type(hz) is not int or not 1<=hz<=30:raise ValueError('enabled boolean, hz1–30.')
        with self.attention():
            original=self._pack()
            try:
                self.idle_enabled=enabled;self.idle_hz=hz;self.error=None
                with self.db:self._persist()
            except BaseException:self._unpack(original);raise
        return {'enabled':enabled,'hz':hz,'idle_weight_learning':False}

    def checkpoint(self):
        with self.attention():
            self.monitor.check()
            return {'checkpoint':self._commit('manual')}

    def restore(self, identifier):
        with self.attention():
            self.monitor.check();original=self._pack()
            row=self.db.execute('SELECT sha,payload FROM checkpoints WHERE id=?',(identifier,)).fetchone()
            if not row or hashlib.sha256(row[1]).hexdigest()!=row[0]:raise ValueError('Checkpoint không hợp lệ.')
            try:
                old_sequence=self.sequence;self._unpack(row[1]);self.sequence=max(old_sequence,self.sequence)
                new=self._commit('restore',{'source':identifier});self.trace.clear()
                return {'checkpoint':new,'restored_from':identifier}
            except BaseException:self._unpack(original);raise

    def status(self, after=0):
        with self.lock:
            memory=self.process.memory_info()
            return {'product':'SCAR-X · Thế hệ đầu','model':MODEL,'cores_loaded':1,'hidden':48,
                'synapses':self.model.core.w_in.size+self.model.core.w_rec.size+self.model.core.w_out.size,
                'state':self.state,'ticks':self.model.ticks,'updates':self.model.core.updates,
                'idle':{'enabled':self.idle_enabled,'hz':self.idle_hz,'quanta':self.idle_steps,'weight_learning':False,'error':self.error},
                'pending_messages':self.pending,'ram_bytes':memory.rss,'commit_bytes':getattr(memory,'private',memory.vms),
                'cpu_percent_one_core':self.process.cpu_percent(None),'resources':self.monitor.report(),
                'memory_limit':self.limit_status,'checkpoint':self.active,'memories':len(self.memories),
                'trace':[r for r in self.trace if r['id']>after], 'trace_cursor':self.sequence,
                'trace_capacity':256,'recurrent_indices':self.model.core.indices.tolist(),
                'recurrent_weights':np.round(self.model.core.w_rec,4).tolist(),'general_chat':False,'general_vision':False,
                'note':'All48neurons computed each tick; spikes do not imply sparse compute. Idle uses the same core, does not modify weights.'}

    def checkpoints(self):
        with self.lock:return [{'id':r[0],'created':r[1],'action':r[2]} for r in self.db.execute('SELECT id,created,action FROM checkpoints ORDER BY rowid DESC LIMIT 40')]

    def export(self):
        with self.attention():return self._pack()

    def close(self):
        self.stop_event.set()
        if getattr(self,'thread',None) and self.thread.is_alive():self.thread.join(timeout=5)
        with self.lock:
            if self.closed:return
            try:
                with self.db:self._persist()
            finally:
                self.closed=True;self.db.close();self.monitor.__exit__(None,None,None);self.lease.close()
