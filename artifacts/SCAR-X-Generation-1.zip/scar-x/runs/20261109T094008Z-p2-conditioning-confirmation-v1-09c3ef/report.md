# P2 conditioning confirmation /20context stress

All8fresh independent seeds; identical fixed hidden cores and local readout budget. No hidden learning gain, new language/vision competence or deployment.

{
  "run": "runs/20261109T094008Z-p2-conditioning-confirmation-v1-09c3ef",
  "direct_confirmation": {
    "order": {
      "accuracy": {
        "mean": 0.955322265625,
        "lower95": 0.935296630859375,
        "upper95": 0.9726623535156249,
        "n_seeds": 8
      },
      "gain_vs_raw": {
        "mean": 0.35693359375,
        "lower95": 0.289306640625,
        "upper95": 0.420654296875,
        "n_seeds": 8
      },
      "signflip_p": 0.0078125,
      "holm_p": 0.0234375,
      "condition_gate": true
    },
    "xor": {
      "accuracy": {
        "mean": 0.869873046875,
        "lower95": 0.803466796875,
        "upper95": 0.9287109375,
        "n_seeds": 8
      },
      "gain_vs_raw": {
        "mean": 0.3525390625,
        "lower95": 0.278314208984375,
        "upper95": 0.416748046875,
        "n_seeds": 8
      },
      "signflip_p": 0.0078125,
      "holm_p": 0.0234375,
      "condition_gate": true
    },
    "strict_binding": {
      "accuracy": {
        "mean": 0.617431640625,
        "lower95": 0.5654296875,
        "upper95": 0.66845703125,
        "n_seeds": 8
      },
      "gain_vs_raw": {
        "mean": 0.07958984375,
        "lower95": 0.047119140625,
        "upper95": 0.115234375,
        "n_seeds": 8
      },
      "signflip_p": 0.0078125,
      "holm_p": 0.0234375,
      "condition_gate": false
    }
  },
  "direct_gate": true,
  "continual_summary": {
    "raw": {
      "acquisition": {
        "mean": 0.41518554687500003,
        "lower95": 0.40053588867187495,
        "upper95": 0.43168945312499996,
        "n_seeds": 8
      },
      "final": {
        "mean": 0.317041015625,
        "lower95": 0.305810546875,
        "upper95": 0.32851684570312495,
        "n_seeds": 8
      },
      "mean_forgetting_pp": {
        "mean": 21.015625,
        "lower95": 19.306640625,
        "upper95": 22.7978515625,
        "n_seeds": 8
      },
      "worst_forgetting_pp": {
        "mean": 50.48828125,
        "lower95": 45.21484375,
        "upper95": 57.91015625,
        "n_seeds": 8
      },
      "every_seed_gate": false
    },
    "normalized": {
      "acquisition": {
        "mean": 0.62099609375,
        "lower95": 0.5889611816406249,
        "upper95": 0.651904296875,
        "n_seeds": 8
      },
      "final": {
        "mean": 0.29023437500000004,
        "lower95": 0.275732421875,
        "upper95": 0.304931640625,
        "n_seeds": 8
      },
      "mean_forgetting_pp": {
        "mean": 35.1416015625,
        "lower95": 32.0703125,
        "upper95": 38.173828125,
        "n_seeds": 8
      },
      "worst_forgetting_pp": {
        "mean": 80.56640625,
        "lower95": 74.70703125,
        "upper95": 86.42578125,
        "n_seeds": 8
      },
      "every_seed_gate": false
    },
    "raw_replay": {
      "acquisition": {
        "mean": 0.329443359375,
        "lower95": 0.3154296875,
        "upper95": 0.343310546875,
        "n_seeds": 8
      },
      "final": {
        "mean": 0.31796875,
        "lower95": 0.295166015625,
        "upper95": 0.339990234375,
        "n_seeds": 8
      },
      "mean_forgetting_pp": {
        "mean": 15.0634765625,
        "lower95": 13.9404296875,
        "upper95": 16.1669921875,
        "n_seeds": 8
      },
      "worst_forgetting_pp": {
        "mean": 45.01953125,
        "lower95": 37.3046875,
        "upper95": 53.127441406249964,
        "n_seeds": 8
      },
      "every_seed_gate": false
    },
    "normalized_replay": {
      "acquisition": {
        "mean": 0.540576171875,
        "lower95": 0.5130859375,
        "upper95": 0.567822265625,
        "n_seeds": 8
      },
      "final": {
        "mean": 0.310400390625,
        "lower95": 0.296239013671875,
        "upper95": 0.324072265625,
        "n_seeds": 8
      },
      "mean_forgetting_pp": {
        "mean": 27.9443359375,
        "lower95": 25.9375,
        "upper95": 29.985595703124996,
        "n_seeds": 8
      },
      "worst_forgetting_pp": {
        "mean": 70.21484375,
        "lower95": 61.9140625,
        "upper95": 77.9296875,
        "n_seeds": 8
      },
      "every_seed_gate": false
    }
  },
  "continual_every_seed_gate": false,
  "direct_trials": [
    {
      "seed": 4103,
      "task": "order",
      "condition": "raw",
      "accuracy": 0.599609375,
      "ridge_probe": 0.896484375,
      "updates": 1536
    },
    {
      "seed": 4103,
      "task": "order",
      "condition": "normalized",
      "accuracy": 0.927734375,
      "ridge_probe": 0.896484375,
      "updates": 1536
    },
    {
      "seed": 4103,
      "task": "xor",
      "condition": "raw",
      "accuracy": 0.54296875,
      "ridge_probe": 0.861328125,
      "updates": 1536
    },
    {
      "seed": 4103,
      "task": "xor",
      "condition": "normalized",
      "accuracy": 0.92578125,
      "ridge_probe": 0.861328125,
      "updates": 1536
    },
    {
      "seed": 4103,
      "task": "strict_binding",
      "condition": "raw",
      "accuracy": 0.5,
      "ridge_probe": 0.6484375,
      "updates": 1536
    },
    {
      "seed": 4103,
      "task": "strict_binding",
      "condition": "normalized",
      "accuracy": 0.666015625,
      "ridge_probe": 0.6484375,
      "updates": 1536
    },
    {
      "seed": 4111,
      "task": "order",
      "condition": "raw",
      "accuracy": 0.673828125,
      "ridge_probe": 0.916015625,
      "updates": 1536
    },
    {
      "seed": 4111,
      "task": "order",
      "condition": "normalized",
      "accuracy": 0.90234375,
      "ridge_probe": 0.916015625,
      "updates": 1536
    },
    {
      "seed": 4111,
      "task": "xor",
      "condition": "raw",
      "accuracy": 0.5,
      "ridge_probe": 0.88671875,
      "updates": 1536
    },
    {
      "seed": 4111,
      "task": "xor",
      "condition": "normalized",
      "accuracy": 0.9296875,
      "ridge_probe": 0.88671875,
      "updates": 1536
    },
    {
      "seed": 4111,
      "task": "strict_binding",
      "condition": "raw",
      "accuracy": 0.51171875,
      "ridge_probe": 0.5625,
      "updates": 1536
    },
    {
      "seed": 4111,
      "task": "strict_binding",
      "condition": "normalized",
      "accuracy": 0.529296875,
      "ridge_probe": 0.5625,
      "updates": 1536
    },
    {
      "seed": 4127,
      "task": "order",
      "condition": "raw",
      "accuracy": 0.513671875,
      "ridge_probe": 0.97265625,
      "updates": 1536
    },
    {
      "seed": 4127,
      "task": "order",
      "condition": "normalized",
      "accuracy": 0.970703125,
      "ridge_probe": 0.97265625,
      "updates": 1536
    },
    {
      "seed": 4127,
      "task": "xor",
      "condition": "raw",
      "accuracy": 0.56640625,
      "ridge_probe": 0.744140625,
      "updates": 1536
    },
    {
      "seed": 4127,
      "task": "xor",
      "condition": "normalized",
      "accuracy": 0.73046875,
      "ridge_probe": 0.744140625,
      "updates": 1536
    },
    {
      "seed": 4127,
      "task": "strict_binding",
      "condition": "raw",
      "accuracy": 0.5,
      "ridge_probe": 0.59765625,
      "updates": 1536
    },
    {
      "seed": 4127,
      "task": "strict_binding",
      "condition": "normalized",
      "accuracy": 0.5390625,
      "ridge_probe": 0.59765625,
      "updates": 1536
    },
    {
      "seed": 4133,
      "task": "order",
      "condition": "raw",
      "accuracy": 0.6796875,
      "ridge_probe": 0.93359375,
      "updates": 1536
    },
    {
      "seed": 4133,
      "task": "order",
      "condition": "normalized",
      "accuracy": 0.97265625,
      "ridge_probe": 0.93359375,
      "updates": 1536
    },
    {
      "seed": 4133,
      "task": "xor",
      "condition": "raw",
      "accuracy": 0.5,
      "ridge_probe": 0.896484375,
      "updates": 1536
    },
    {
      "seed": 4133,
      "task": "xor",
      "condition": "normalized",
      "accuracy": 0.896484375,
      "ridge_probe": 0.896484375,
      "updates": 1536
    },
    {
      "seed": 4133,
      "task": "strict_binding",
      "condition": "raw",
      "accuracy": 0.62890625,
      "ridge_probe": 0.58984375,
      "updates": 1536
    },
    {
      "seed": 4133,
      "task": "strict_binding",
      "condition": "normalized",
      "accuracy": 0.685546875,
      "ridge_probe": 0.58984375,
      "updates": 1536
    },
    {
      "seed": 4153,
      "task": "order",
      "condition": "raw",
      "accuracy": 0.525390625,
      "ridge_probe": 0.978515625,
      "updates": 1536
    },
    {
      "seed": 4153,
      "task": "order",
      "condition": "normalized",
      "accuracy": 0.96875,
      "ridge_probe": 0.978515625,
      "updates": 1536
    },
    {
      "seed": 4153,
      "task": "xor",
      "condition": "raw",
      "accuracy": 0.5,
      "ridge_probe": 0.974609375,
      "updates": 1536
    },
    {
      "seed": 4153,
      "task": "xor",
      "condition": "normalized",
      "accuracy": 0.98046875,
      "ridge_probe": 0.974609375,
      "updates": 1536
    },
    {
      "seed": 4153,
      "task": "strict_binding",
      "condition": "raw",
      "accuracy": 0.568359375,
      "ridge_probe": 0.6328125,
      "updates": 1536
    },
    {
      "seed": 4153,
      "task": "strict_binding",
      "condition": "normalized",
      "accuracy": 0.697265625,
      "ridge_probe": 0.6328125,
      "updates": 1536
    },
    {
      "seed": 4159,
      "task": "order",
      "condition": "raw",
      "accuracy": 0.50390625,
      "ridge_probe": 0.9140625,
      "updates": 1536
    },
    {
      "seed": 4159,
      "task": "order",
      "condition": "normalized",
      "accuracy": 0.939453125,
      "ridge_probe": 0.9140625,
      "updates": 1536
    },
    {
      "seed": 4159,
      "task": "xor",
      "condition": "raw",
      "accuracy": 0.50390625,
      "ridge_probe": 0.74609375,
      "updates": 1536
    },
    {
      "seed": 4159,
      "task": "xor",
      "condition": "normalized",
      "accuracy": 0.724609375,
      "ridge_probe": 0.74609375,
      "updates": 1536
    },
    {
      "seed": 4159,
      "task": "strict_binding",
      "condition": "raw",
      "accuracy": 0.509765625,
      "ridge_probe": 0.556640625,
      "updates": 1536
    },
    {
      "seed": 4159,
      "task": "strict_binding",
      "condition": "normalized",
      "accuracy": 0.568359375,
      "ridge_probe": 0.556640625,
      "updates": 1536
    },
    {
      "seed": 4177,
      "task": "order",
      "condition": "raw",
      "accuracy": 0.525390625,
      "ridge_probe": 0.943359375,
      "updates": 1536
    },
    {
      "seed": 4177,
      "task": "order",
      "condition": "normalized",
      "accuracy": 0.97265625,
      "ridge_probe": 0.943359375,
      "updates": 1536
    },
    {
      "seed": 4177,
      "task": "xor",
      "condition": "raw",
      "accuracy": 0.5,
      "ridge_probe": 0.8125,
      "updates": 1536
    },
    {
      "seed": 4177,
      "task": "xor",
      "condition": "normalized",
      "accuracy": 0.84375,
      "ridge_probe": 0.8125,
      "updates": 1536
    },
    {
      "seed": 4177,
      "task": "strict_binding",
      "condition": "raw",
      "accuracy": 0.583984375,
      "ridge_probe": 0.65234375,
      "updates": 1536
    },
    {
      "seed": 4177,
      "task": "strict_binding",
      "condition": "normalized",
      "accuracy": 0.708984375,
      "ridge_probe": 0.65234375,
      "updates": 1536
    },
    {
      "seed": 4201,
      "task": "order",
      "condition": "raw",
      "accuracy": 0.765625,
      "ridge_probe": 0.990234375,
      "updates": 1536
    },
    {
      "seed": 4201,
      "task": "order",
      "condition": "normalized",
      "accuracy": 0.98828125,
      "ridge_probe": 0.990234375,
      "updates": 1536
    },
    {
      "seed": 4201,
      "task": "xor",
      "condition": "raw",
      "accuracy": 0.525390625,
      "ridge_probe": 0.884765625,
      "updates": 1536
    },
    {
      "seed": 4201,
      "task": "xor",
      "condition": "normalized",
      "accuracy": 0.927734375,
      "ridge_probe": 0.884765625,
      "updates": 1536
    },
    {
      "seed": 4201,
      "task": "strict_binding",
      "condition": "raw",
      "accuracy": 0.5,
      "ridge_probe": 0.541015625,
      "updates": 1536
    },
    {
      "seed": 4201,
      "task": "strict_binding",
      "condition": "normalized",
      "accuracy": 0.544921875,
      "ridge_probe": 0.541015625,
      "updates": 1536
    }
  ],
  "stream_trials": [
    {
      "seed": 4103,
      "condition": "raw",
      "acquisition": 0.451171875,
      "final": 0.30703125,
      "mean_forgetting_pp": 25.156250000000004,
      "worst_forgetting_pp": 73.4375,
      "signed_bwt": -0.15172697368421054,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.23500000000058208
    },
    {
      "seed": 4103,
      "condition": "normalized",
      "acquisition": 0.658984375,
      "final": 0.26171875,
      "mean_forgetting_pp": 41.2109375,
      "worst_forgetting_pp": 93.75,
      "signed_bwt": -0.41817434210526316,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.2649999999994179
    },
    {
      "seed": 4103,
      "condition": "raw_replay",
      "acquisition": 0.321484375,
      "final": 0.3515625,
      "mean_forgetting_pp": 14.726562500000002,
      "worst_forgetting_pp": 64.0625,
      "signed_bwt": 0.031661184210526314,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.25
    },
    {
      "seed": 4103,
      "condition": "normalized_replay",
      "acquisition": 0.596484375,
      "final": 0.328515625,
      "mean_forgetting_pp": 30.2734375,
      "worst_forgetting_pp": 82.8125,
      "signed_bwt": -0.28207236842105265,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.2819999999992433
    },
    {
      "seed": 4111,
      "condition": "raw",
      "acquisition": 0.391015625,
      "final": 0.3421875,
      "mean_forgetting_pp": 17.0703125,
      "worst_forgetting_pp": 39.0625,
      "signed_bwt": -0.05139802631578947,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.25
    },
    {
      "seed": 4111,
      "condition": "normalized",
      "acquisition": 0.589453125,
      "final": 0.31953125,
      "mean_forgetting_pp": 29.6875,
      "worst_forgetting_pp": 71.09375,
      "signed_bwt": -0.28412828947368424,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.2649999999994179
    },
    {
      "seed": 4111,
      "condition": "raw_replay",
      "acquisition": 0.297265625,
      "final": 0.30546875,
      "mean_forgetting_pp": 12.109375,
      "worst_forgetting_pp": 27.34375,
      "signed_bwt": 0.008634868421052632,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.23500000000058208
    },
    {
      "seed": 4111,
      "condition": "normalized_replay",
      "acquisition": 0.50703125,
      "final": 0.32421875,
      "mean_forgetting_pp": 25.742187500000004,
      "worst_forgetting_pp": 50.78125,
      "signed_bwt": -0.1924342105263158,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.5469999999986612
    },
    {
      "seed": 4127,
      "condition": "raw",
      "acquisition": 0.4421875,
      "final": 0.320703125,
      "mean_forgetting_pp": 21.2890625,
      "worst_forgetting_pp": 50.78125,
      "signed_bwt": -0.1278782894736842,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.5310000000026776
    },
    {
      "seed": 4127,
      "condition": "normalized",
      "acquisition": 0.656640625,
      "final": 0.294921875,
      "mean_forgetting_pp": 37.8125,
      "worst_forgetting_pp": 85.15625,
      "signed_bwt": -0.3807565789473684,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.6719999999986612
    },
    {
      "seed": 4127,
      "condition": "raw_replay",
      "acquisition": 0.313671875,
      "final": 0.30234375,
      "mean_forgetting_pp": 16.5625,
      "worst_forgetting_pp": 58.59375,
      "signed_bwt": -0.011924342105263159,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.5630000000019209
    },
    {
      "seed": 4127,
      "condition": "normalized_replay",
      "acquisition": 0.553125,
      "final": 0.338671875,
      "mean_forgetting_pp": 26.132812500000004,
      "worst_forgetting_pp": 77.34375,
      "signed_bwt": -0.22574013157894737,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.6089999999967404
    },
    {
      "seed": 4133,
      "condition": "raw",
      "acquisition": 0.39375,
      "final": 0.31953125,
      "mean_forgetting_pp": 20.5859375,
      "worst_forgetting_pp": 50.0,
      "signed_bwt": -0.078125,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.5309999999954016
    },
    {
      "seed": 4133,
      "condition": "normalized",
      "acquisition": 0.544921875,
      "final": 0.265625,
      "mean_forgetting_pp": 31.171875,
      "worst_forgetting_pp": 75.78125,
      "signed_bwt": -0.29399671052631576,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.625
    },
    {
      "seed": 4133,
      "condition": "raw_replay",
      "acquisition": 0.3546875,
      "final": 0.34453125,
      "mean_forgetting_pp": 15.234375,
      "worst_forgetting_pp": 42.96875,
      "signed_bwt": -0.01069078947368421,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.5780000000013388
    },
    {
      "seed": 4133,
      "condition": "normalized_replay",
      "acquisition": 0.505078125,
      "final": 0.291015625,
      "mean_forgetting_pp": 25.937500000000004,
      "worst_forgetting_pp": 69.53125,
      "signed_bwt": -0.22532894736842105,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.6560000000026776
    },
    {
      "seed": 4153,
      "condition": "raw",
      "acquisition": 0.403515625,
      "final": 0.302734375,
      "mean_forgetting_pp": 21.6796875,
      "worst_forgetting_pp": 50.0,
      "signed_bwt": -0.10608552631578948,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.5310000000026776
    },
    {
      "seed": 4153,
      "condition": "normalized",
      "acquisition": 0.608203125,
      "final": 0.293359375,
      "mean_forgetting_pp": 33.8671875,
      "worst_forgetting_pp": 67.1875,
      "signed_bwt": -0.3314144736842105,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.625
    },
    {
      "seed": 4153,
      "condition": "raw_replay",
      "acquisition": 0.358203125,
      "final": 0.336328125,
      "mean_forgetting_pp": 14.453125,
      "worst_forgetting_pp": 37.5,
      "signed_bwt": -0.023026315789473683,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.625
    },
    {
      "seed": 4153,
      "condition": "normalized_replay",
      "acquisition": 0.47890625,
      "final": 0.281640625,
      "mean_forgetting_pp": 23.59375,
      "worst_forgetting_pp": 53.90625,
      "signed_bwt": -0.20764802631578946,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.6719999999986612
    },
    {
      "seed": 4159,
      "condition": "raw",
      "acquisition": 0.400390625,
      "final": 0.340625,
      "mean_forgetting_pp": 19.375,
      "worst_forgetting_pp": 45.3125,
      "signed_bwt": -0.06291118421052631,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.5310000000026776
    },
    {
      "seed": 4159,
      "condition": "normalized",
      "acquisition": 0.682421875,
      "final": 0.304296875,
      "mean_forgetting_pp": 38.828125,
      "worst_forgetting_pp": 84.375,
      "signed_bwt": -0.3980263157894737,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.5939999999973224
    },
    {
      "seed": 4159,
      "condition": "raw_replay",
      "acquisition": 0.34375,
      "final": 0.358984375,
      "mean_forgetting_pp": 13.8671875,
      "worst_forgetting_pp": 50.78125,
      "signed_bwt": 0.016036184210526317,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.5310000000026776
    },
    {
      "seed": 4159,
      "condition": "normalized_replay",
      "acquisition": 0.58515625,
      "final": 0.323046875,
      "mean_forgetting_pp": 32.5390625,
      "worst_forgetting_pp": 71.09375,
      "signed_bwt": -0.2759046052631579,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.6569999999992433
    },
    {
      "seed": 4177,
      "condition": "raw",
      "acquisition": 0.403125,
      "final": 0.31015625,
      "mean_forgetting_pp": 18.7890625,
      "worst_forgetting_pp": 46.875,
      "signed_bwt": -0.09786184210526316,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.5310000000026776
    },
    {
      "seed": 4177,
      "condition": "normalized",
      "acquisition": 0.65078125,
      "final": 0.26796875,
      "mean_forgetting_pp": 39.4140625,
      "worst_forgetting_pp": 78.125,
      "signed_bwt": -0.4029605263157895,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.625
    },
    {
      "seed": 4177,
      "condition": "raw_replay",
      "acquisition": 0.331640625,
      "final": 0.27734375,
      "mean_forgetting_pp": 17.7734375,
      "worst_forgetting_pp": 43.75,
      "signed_bwt": -0.057154605263157895,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.5630000000019209
    },
    {
      "seed": 4177,
      "condition": "normalized_replay",
      "acquisition": 0.570703125,
      "final": 0.308203125,
      "mean_forgetting_pp": 31.0546875,
      "worst_forgetting_pp": 71.09375,
      "signed_bwt": -0.27631578947368424,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.6559999999954016
    },
    {
      "seed": 4201,
      "condition": "raw",
      "acquisition": 0.436328125,
      "final": 0.293359375,
      "mean_forgetting_pp": 24.1796875,
      "worst_forgetting_pp": 48.4375,
      "signed_bwt": -0.15049342105263158,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.5310000000026776
    },
    {
      "seed": 4201,
      "condition": "normalized",
      "acquisition": 0.5765625,
      "final": 0.314453125,
      "mean_forgetting_pp": 29.140624999999996,
      "worst_forgetting_pp": 89.0625,
      "signed_bwt": -0.2759046052631579,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.6399999999994179
    },
    {
      "seed": 4201,
      "condition": "raw_replay",
      "acquisition": 0.31484375,
      "final": 0.2671875,
      "mean_forgetting_pp": 15.78125,
      "worst_forgetting_pp": 35.15625,
      "signed_bwt": -0.05016447368421053,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.5629999999946449
    },
    {
      "seed": 4201,
      "condition": "normalized_replay",
      "acquisition": 0.528125,
      "final": 0.287890625,
      "mean_forgetting_pp": 28.281250000000004,
      "worst_forgetting_pp": 85.15625,
      "signed_bwt": -0.25287828947368424,
      "gate": false,
      "updates": 2560,
      "resume_exact": true,
      "replay_examples": 128,
      "seconds": 0.625
    }
  ],
  "resources": {
    "peak_rss_bytes": 51245056,
    "peak_commit_or_vms_bytes": 71155712,
    "os_process_peak_working_set_bytes": 54910976,
    "os_process_peak_pagefile_commit_bytes": 75169792,
    "samples": 194,
    "interval_seconds": 0.1,
    "limit_bytes": 2000000000,
    "observed_over_limit": false,
    "elapsed_seconds": 24.285350799997104,
    "hard_cap_enforced": false,
    "igpu_measured": false,
    "energy_joules": null,
    "note": "Tree sums may double-count shared pages; Windows pagefile is commit, not bytes swapped. No iGPU allocated."
  },
  "cap": {
    "enforced": true,
    "limit_bytes": 2000000000,
    "kind": "Windows per-process committed memory; shared pages monitored separately"
  },
  "deployed": false,
  "hidden_frozen": true,
  "hidden_representation_gate": false,
  "equal_time_comparison_performed": false,
  "normal_chat_or_vision_proven": false,
  "decision": "P2_DIRECT_CONDITIONING_CONFIRMED_RETENTION_PENDING"
}
