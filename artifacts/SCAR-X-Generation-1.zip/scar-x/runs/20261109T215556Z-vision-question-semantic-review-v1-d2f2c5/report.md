# Public visual-question editorial review

All32actualCLIquestions read; attributeintent matches controlledfixtures. Threewording caveats retained. No targettruthcertification or trainingimport.

{
  "run": "runs/20261109T215556Z-vision-question-semantic-review-v1-d2f2c5",
  "source_generation_run": "runs/20261109T215349Z-antigravity-vision-questions-v1-bfbd17",
  "data": "data/candidates/20261109T215349Z-antigravity-vision-questions-v1-bfbd17/reviewed-questions.json",
  "sha256": "0be8315bad3e9db9ece7cb132246d24ecafb3f50f1d3a6cf8d17325719887fbb",
  "items": 32,
  "decision": "QUESTIONS_REVIEWED_FOR_PATH_AUDIT_ONLY",
  "editorial_notes": {
    "single_shape_01": "Vietnamese slightly stiff; asks the sole geometricshape unambiguously under fixture.",
    "single_shape_04": "Vietnamese slightly stiff, same single-shape attribute.",
    "left_color_04": "Interpret outer-left edge phrasing as uniqueleftmostobject in the controlledfixture; not a broadsemantic test."
  },
  "automatic_learning_allowed": false,
  "trained": false,
  "teacher_answers_used": false,
  "proposal30_approved": false
}
