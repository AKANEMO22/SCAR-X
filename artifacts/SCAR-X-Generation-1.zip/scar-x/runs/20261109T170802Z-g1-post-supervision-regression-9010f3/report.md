# Post-supervision regression diagnostic

Canonicalclones only; no more training or source mutation.

{
  "run": "runs/20261109T170802Z-g1-post-supervision-regression-9010f3",
  "decision": "POST_TEACHING_REGRESSION_DIAGNOSTIC",
  "source_checkpoint": "b16b19d31efd480584d946e3de4120ea",
  "digits": {
    "before": [
      {
        "id": 1115,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 1081,
        "target": 2,
        "predicted": 2
      },
      {
        "id": 1680,
        "target": 3,
        "predicted": 3
      },
      {
        "id": 1359,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 1288,
        "target": 1,
        "predicted": 1
      },
      {
        "id": 358,
        "target": 5,
        "predicted": 8
      },
      {
        "id": 1655,
        "target": 2,
        "predicted": 2
      },
      {
        "id": 521,
        "target": 5,
        "predicted": 4
      },
      {
        "id": 1551,
        "target": 6,
        "predicted": 8
      },
      {
        "id": 244,
        "target": 2,
        "predicted": 1
      },
      {
        "id": 1277,
        "target": 5,
        "predicted": 5
      },
      {
        "id": 1541,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 22,
        "target": 2,
        "predicted": 2
      },
      {
        "id": 675,
        "target": 9,
        "predicted": 9
      },
      {
        "id": 1222,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 122,
        "target": 8,
        "predicted": 8
      },
      {
        "id": 178,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 859,
        "target": 3,
        "predicted": 3
      },
      {
        "id": 1231,
        "target": 5,
        "predicted": 5
      },
      {
        "id": 501,
        "target": 2,
        "predicted": 2
      },
      {
        "id": 315,
        "target": 3,
        "predicted": 3
      },
      {
        "id": 1360,
        "target": 9,
        "predicted": 9
      },
      {
        "id": 1413,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 467,
        "target": 7,
        "predicted": 7
      },
      {
        "id": 324,
        "target": 4,
        "predicted": 6
      },
      {
        "id": 343,
        "target": 4,
        "predicted": 4
      },
      {
        "id": 44,
        "target": 7,
        "predicted": 7
      },
      {
        "id": 306,
        "target": 2,
        "predicted": 2
      },
      {
        "id": 1412,
        "target": 9,
        "predicted": 9
      },
      {
        "id": 789,
        "target": 3,
        "predicted": 3
      },
      {
        "id": 102,
        "target": 5,
        "predicted": 8
      },
      {
        "id": 1733,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 1701,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 352,
        "target": 8,
        "predicted": 8
      },
      {
        "id": 83,
        "target": 3,
        "predicted": 9
      },
      {
        "id": 1095,
        "target": 4,
        "predicted": 9
      },
      {
        "id": 290,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 1745,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 1005,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 64,
        "target": 4,
        "predicted": 4
      },
      {
        "id": 1624,
        "target": 3,
        "predicted": 3
      },
      {
        "id": 209,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 956,
        "target": 2,
        "predicted": 2
      },
      {
        "id": 16,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 1326,
        "target": 9,
        "predicted": 9
      },
      {
        "id": 1716,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 381,
        "target": 9,
        "predicted": 9
      },
      {
        "id": 500,
        "target": 8,
        "predicted": 7
      }
    ],
    "current": [
      {
        "id": 1115,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 1081,
        "target": 2,
        "predicted": 2
      },
      {
        "id": 1680,
        "target": 3,
        "predicted": 3
      },
      {
        "id": 1359,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 1288,
        "target": 1,
        "predicted": 1
      },
      {
        "id": 358,
        "target": 5,
        "predicted": 8
      },
      {
        "id": 1655,
        "target": 2,
        "predicted": 2
      },
      {
        "id": 521,
        "target": 5,
        "predicted": 4
      },
      {
        "id": 1551,
        "target": 6,
        "predicted": 8
      },
      {
        "id": 244,
        "target": 2,
        "predicted": 1
      },
      {
        "id": 1277,
        "target": 5,
        "predicted": 5
      },
      {
        "id": 1541,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 22,
        "target": 2,
        "predicted": 2
      },
      {
        "id": 675,
        "target": 9,
        "predicted": 9
      },
      {
        "id": 1222,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 122,
        "target": 8,
        "predicted": 8
      },
      {
        "id": 178,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 859,
        "target": 3,
        "predicted": 3
      },
      {
        "id": 1231,
        "target": 5,
        "predicted": 5
      },
      {
        "id": 501,
        "target": 2,
        "predicted": 2
      },
      {
        "id": 315,
        "target": 3,
        "predicted": 3
      },
      {
        "id": 1360,
        "target": 9,
        "predicted": 9
      },
      {
        "id": 1413,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 467,
        "target": 7,
        "predicted": 7
      },
      {
        "id": 324,
        "target": 4,
        "predicted": 6
      },
      {
        "id": 343,
        "target": 4,
        "predicted": 4
      },
      {
        "id": 44,
        "target": 7,
        "predicted": 7
      },
      {
        "id": 306,
        "target": 2,
        "predicted": 2
      },
      {
        "id": 1412,
        "target": 9,
        "predicted": 9
      },
      {
        "id": 789,
        "target": 3,
        "predicted": 3
      },
      {
        "id": 102,
        "target": 5,
        "predicted": 8
      },
      {
        "id": 1733,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 1701,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 352,
        "target": 8,
        "predicted": 8
      },
      {
        "id": 83,
        "target": 3,
        "predicted": 9
      },
      {
        "id": 1095,
        "target": 4,
        "predicted": 9
      },
      {
        "id": 290,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 1745,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 1005,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 64,
        "target": 4,
        "predicted": 4
      },
      {
        "id": 1624,
        "target": 3,
        "predicted": 3
      },
      {
        "id": 209,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 956,
        "target": 2,
        "predicted": 2
      },
      {
        "id": 16,
        "target": 6,
        "predicted": 6
      },
      {
        "id": 1326,
        "target": 9,
        "predicted": 9
      },
      {
        "id": 1716,
        "target": 0,
        "predicted": 0
      },
      {
        "id": 381,
        "target": 9,
        "predicted": 9
      },
      {
        "id": 500,
        "target": 8,
        "predicted": 7
      }
    ]
  },
  "math": {
    "before": [
      {
        "prompt": "QA ki\u1ec3m tra tab: 4 + 4 b\u1eb1ng m\u1ea5y?",
        "target": "8",
        "generated": "8",
        "correct": true
      },
      {
        "prompt": "7 + 8",
        "target": "15",
        "generated": "15",
        "correct": true
      }
    ],
    "current": [
      {
        "prompt": "QA ki\u1ec3m tra tab: 4 + 4 b\u1eb1ng m\u1ea5y?",
        "target": "8",
        "generated": "8",
        "correct": true
      },
      {
        "prompt": "7 + 8",
        "target": "15",
        "generated": "15",
        "correct": true
      }
    ]
  },
  "digit_accuracy": {
    "before": 0.8125,
    "current": 0.8125
  },
  "lost_old_correct_digits": 0,
  "old_correct_math_lost": 0,
  "new_training": false,
  "surface_normalization_enabled": false,
  "normal_chat_or_vision_proven": false,
  "retention_confirmed": false,
  "note": "48known public digits and2existing arithmetictrainingpoints on canonical diagnosticclones; not generalvision/longtermretention proof"
}
