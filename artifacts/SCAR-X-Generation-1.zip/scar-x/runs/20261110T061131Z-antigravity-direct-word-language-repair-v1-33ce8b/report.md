# One language repair

Originalcandidate retained, replacement requires review before anytraining.

{
  "run": "runs/20261110T061131Z-antigravity-direct-word-language-repair-v1-33ce8b",
  "source_run": "runs/20261110T060709Z-antigravity-direct-word-prompts-v1-820d4e",
  "data": "data/candidates/20261110T061131Z-antigravity-direct-word-language-repair-v1-33ce8b/repair.json",
  "sha256": "df78146344736d91a5dab37b1cb4776ae6f61de23bfc5095a50bce6d66ffaf06",
  "decision": "ONE_LANGUAGE_REPAIR_REQUIRES_REVIEW",
  "items": 1,
  "new_training": false,
  "private_content_sent": false,
  "teacher_answers_used": false,
  "seconds": 16.806950900005177,
  "usage": {
    "input_tokens": 28858,
    "output_tokens": 123,
    "thinking_tokens": 0,
    "cache_read_tokens": 0,
    "total_tokens": 28981
  }
}
