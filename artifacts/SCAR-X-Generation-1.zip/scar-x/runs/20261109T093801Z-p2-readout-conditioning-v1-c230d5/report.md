# P2 output-local conditioning diagnostic

No hidden updates. A possible decoding/acquisition control, not useful hidden representation or solved continual learning.

{
  "run": "runs/20261109T093801Z-p2-readout-conditioning-v1-c230d5",
  "trials": [
    {
      "task": "order",
      "seed": 3109,
      "condition": "raw",
      "accuracy": 0.515625,
      "ridge_probe": 0.88671875,
      "updates": 1536,
      "loss": 0.6767160565334575,
      "hidden_frozen": true
    },
    {
      "task": "order",
      "seed": 3109,
      "condition": "centered",
      "accuracy": 0.5,
      "ridge_probe": 0.88671875,
      "updates": 1536,
      "loss": 0.6905392665568896,
      "hidden_frozen": true
    },
    {
      "task": "order",
      "seed": 3109,
      "condition": "normalized",
      "accuracy": 0.921875,
      "ridge_probe": 0.88671875,
      "updates": 1536,
      "loss": 0.23984773675636886,
      "hidden_frozen": true
    },
    {
      "task": "order",
      "seed": 3119,
      "condition": "raw",
      "accuracy": 0.5,
      "ridge_probe": 0.94140625,
      "updates": 1536,
      "loss": 0.6834168982201257,
      "hidden_frozen": true
    },
    {
      "task": "order",
      "seed": 3119,
      "condition": "centered",
      "accuracy": 0.5,
      "ridge_probe": 0.94140625,
      "updates": 1536,
      "loss": 0.6999098427079072,
      "hidden_frozen": true
    },
    {
      "task": "order",
      "seed": 3119,
      "condition": "normalized",
      "accuracy": 0.953125,
      "ridge_probe": 0.94140625,
      "updates": 1536,
      "loss": 0.1501085885988666,
      "hidden_frozen": true
    },
    {
      "task": "order",
      "seed": 3137,
      "condition": "raw",
      "accuracy": 0.53515625,
      "ridge_probe": 0.91796875,
      "updates": 1536,
      "loss": 0.6707892553510625,
      "hidden_frozen": true
    },
    {
      "task": "order",
      "seed": 3137,
      "condition": "centered",
      "accuracy": 0.5,
      "ridge_probe": 0.91796875,
      "updates": 1536,
      "loss": 0.6814063617977597,
      "hidden_frozen": true
    },
    {
      "task": "order",
      "seed": 3137,
      "condition": "normalized",
      "accuracy": 0.96484375,
      "ridge_probe": 0.91796875,
      "updates": 1536,
      "loss": 0.15202223629959677,
      "hidden_frozen": true
    },
    {
      "task": "xor",
      "seed": 3109,
      "condition": "raw",
      "accuracy": 0.546875,
      "ridge_probe": 0.58984375,
      "updates": 1536,
      "loss": 0.7328695183226245,
      "hidden_frozen": true
    },
    {
      "task": "xor",
      "seed": 3109,
      "condition": "centered",
      "accuracy": 0.5,
      "ridge_probe": 0.58984375,
      "updates": 1536,
      "loss": 0.7597293693321827,
      "hidden_frozen": true
    },
    {
      "task": "xor",
      "seed": 3109,
      "condition": "normalized",
      "accuracy": 0.609375,
      "ridge_probe": 0.58984375,
      "updates": 1536,
      "loss": 0.9443881135851088,
      "hidden_frozen": true
    },
    {
      "task": "xor",
      "seed": 3119,
      "condition": "raw",
      "accuracy": 0.58203125,
      "ridge_probe": 0.81640625,
      "updates": 1536,
      "loss": 0.7229499456388396,
      "hidden_frozen": true
    },
    {
      "task": "xor",
      "seed": 3119,
      "condition": "centered",
      "accuracy": 0.66796875,
      "ridge_probe": 0.81640625,
      "updates": 1536,
      "loss": 0.7358894024537683,
      "hidden_frozen": true
    },
    {
      "task": "xor",
      "seed": 3119,
      "condition": "normalized",
      "accuracy": 0.84375,
      "ridge_probe": 0.81640625,
      "updates": 1536,
      "loss": 0.5436828658593998,
      "hidden_frozen": true
    },
    {
      "task": "xor",
      "seed": 3137,
      "condition": "raw",
      "accuracy": 0.5,
      "ridge_probe": 0.96484375,
      "updates": 1536,
      "loss": 0.709039306858137,
      "hidden_frozen": true
    },
    {
      "task": "xor",
      "seed": 3137,
      "condition": "centered",
      "accuracy": 0.5,
      "ridge_probe": 0.96484375,
      "updates": 1536,
      "loss": 0.7155656464612877,
      "hidden_frozen": true
    },
    {
      "task": "xor",
      "seed": 3137,
      "condition": "normalized",
      "accuracy": 0.9765625,
      "ridge_probe": 0.96484375,
      "updates": 1536,
      "loss": 0.2910170171444688,
      "hidden_frozen": true
    },
    {
      "task": "strict_binding",
      "seed": 3109,
      "condition": "raw",
      "accuracy": 0.5,
      "ridge_probe": 0.58984375,
      "updates": 1536,
      "loss": 0.7143316691160327,
      "hidden_frozen": true
    },
    {
      "task": "strict_binding",
      "seed": 3109,
      "condition": "centered",
      "accuracy": 0.5,
      "ridge_probe": 0.58984375,
      "updates": 1536,
      "loss": 0.7300463537530254,
      "hidden_frozen": true
    },
    {
      "task": "strict_binding",
      "seed": 3109,
      "condition": "normalized",
      "accuracy": 0.62890625,
      "ridge_probe": 0.58984375,
      "updates": 1536,
      "loss": 0.995589563318255,
      "hidden_frozen": true
    },
    {
      "task": "strict_binding",
      "seed": 3119,
      "condition": "raw",
      "accuracy": 0.50390625,
      "ridge_probe": 0.671875,
      "updates": 1536,
      "loss": 0.714380754173405,
      "hidden_frozen": true
    },
    {
      "task": "strict_binding",
      "seed": 3119,
      "condition": "centered",
      "accuracy": 0.5,
      "ridge_probe": 0.671875,
      "updates": 1536,
      "loss": 0.7440669446521241,
      "hidden_frozen": true
    },
    {
      "task": "strict_binding",
      "seed": 3119,
      "condition": "normalized",
      "accuracy": 0.69140625,
      "ridge_probe": 0.671875,
      "updates": 1536,
      "loss": 0.9468024795812369,
      "hidden_frozen": true
    },
    {
      "task": "strict_binding",
      "seed": 3137,
      "condition": "raw",
      "accuracy": 0.4765625,
      "ridge_probe": 0.546875,
      "updates": 1536,
      "loss": 0.7152650719661932,
      "hidden_frozen": true
    },
    {
      "task": "strict_binding",
      "seed": 3137,
      "condition": "centered",
      "accuracy": 0.5,
      "ridge_probe": 0.546875,
      "updates": 1536,
      "loss": 0.7316105467195987,
      "hidden_frozen": true
    },
    {
      "task": "strict_binding",
      "seed": 3137,
      "condition": "normalized",
      "accuracy": 0.640625,
      "ridge_probe": 0.546875,
      "updates": 1536,
      "loss": 0.8524524508282978,
      "hidden_frozen": true
    }
  ],
  "summary": {
    "centered": {
      "order": {
        "accuracy": 0.5,
        "gain_vs_raw": {
          "mean": -0.016927083333333332,
          "lower95": -0.03515625,
          "upper95": 0.0,
          "independent_seeds": 3,
          "method": "paired seed-cluster bootstrap; exploratory with only three clusters"
        }
      },
      "xor": {
        "accuracy": 0.5559895833333334,
        "gain_vs_raw": {
          "mean": 0.013020833333333334,
          "lower95": -0.046875,
          "upper95": 0.0859375,
          "independent_seeds": 3,
          "method": "paired seed-cluster bootstrap; exploratory with only three clusters"
        }
      },
      "strict_binding": {
        "accuracy": 0.5,
        "gain_vs_raw": {
          "mean": 0.006510416666666667,
          "lower95": -0.00390625,
          "upper95": 0.0234375,
          "independent_seeds": 3,
          "method": "paired seed-cluster bootstrap; exploratory with only three clusters"
        }
      }
    },
    "normalized": {
      "order": {
        "accuracy": 0.9466145833333334,
        "gain_vs_raw": {
          "mean": 0.4296875,
          "lower95": 0.40625,
          "upper95": 0.453125,
          "independent_seeds": 3,
          "method": "paired seed-cluster bootstrap; exploratory with only three clusters"
        }
      },
      "xor": {
        "accuracy": 0.8098958333333334,
        "gain_vs_raw": {
          "mean": 0.2669270833333333,
          "lower95": 0.0625,
          "upper95": 0.4765625,
          "independent_seeds": 3,
          "method": "paired seed-cluster bootstrap; exploratory with only three clusters"
        }
      },
      "strict_binding": {
        "accuracy": 0.6536458333333334,
        "gain_vs_raw": {
          "mean": 0.16015625,
          "lower95": 0.12890625,
          "upper95": 0.1875,
          "independent_seeds": 3,
          "method": "paired seed-cluster bootstrap; exploratory with only three clusters"
        }
      }
    }
  },
  "screen_informative": true,
  "resources": {
    "peak_rss_bytes": 52477952,
    "peak_commit_or_vms_bytes": 71090176,
    "os_process_peak_working_set_bytes": 53411840,
    "os_process_peak_pagefile_commit_bytes": 71733248,
    "samples": 23,
    "interval_seconds": 0.1,
    "limit_bytes": 2000000000,
    "observed_over_limit": false,
    "elapsed_seconds": 1.6471041000040714,
    "hard_cap_enforced": false,
    "igpu_measured": false,
    "energy_joules": null,
    "note": "Tree sums may double-count shared pages; Windows pagefile is commit, not bytes swapped. No iGPU allocated."
  },
  "cap": {
    "enforced": true,
    "limit_bytes": 2000000000,
    "kind": "Windows per-process committed memory; shared pages monitored separately"
  },
  "hidden_representation_gain": false,
  "retention_tested": false,
  "deployed": false,
  "normal_chat_or_vision": false,
  "decision": "REGISTER_CONFIRMATION_AND_RETENTION_NEXT"
}
