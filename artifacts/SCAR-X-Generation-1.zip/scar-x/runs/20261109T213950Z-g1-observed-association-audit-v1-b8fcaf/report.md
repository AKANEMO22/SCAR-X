# Observed-association technical audit

12coldprocessresumes exact; only contextsynapses plastic, frozen-erased arrays/ticks/sampler match. Qualitydecision remainsSTOP. No mainweights or sourcecheckpoints changed.

{
  "run": "runs/20261109T213950Z-g1-observed-association-audit-v1-b8fcaf",
  "source_run": "runs/20261109T213531Z-g1-observed-association-v1-d3e0e7",
  "decision": "ASSOCIATION_TECHNICAL_PASS_QUALITY_UNCHANGED",
  "source_quality_decision": "STOP_OBSERVED_ASSOCIATION_V1",
  "all_cold_exact": true,
  "all_input_block_locality": true,
  "all_frozen_erased_exact": true,
  "same_tick_and_sampler_budget_by_seed": true,
  "all_source_SHA_unchanged": true,
  "serving_core_unchanged": true,
  "array_bytes_each": 117562,
  "checks": [
    {
      "seed": 31013,
      "condition": "frozen",
      "source_sha256": "526203ae78d8eacf79657add0aded80c1ad6d0682eea8e70e2edb5283536c673",
      "cold_exact": true,
      "input_block_locality": true
    },
    {
      "seed": 31013,
      "condition": "paired",
      "source_sha256": "af9cb215b0ec6e874efeed52677f2bf00c4b99264c63226c48e2c756942784c2",
      "cold_exact": true,
      "input_block_locality": true
    },
    {
      "seed": 31013,
      "condition": "erase_trace",
      "source_sha256": "7af7567fce097d519a691f372dfc6bb6b0307468493e247271fec504f49c6eee",
      "cold_exact": true,
      "input_block_locality": true
    },
    {
      "seed": 31013,
      "condition": "cross_family",
      "source_sha256": "431eba7dc4431e352c425cb5a7a73cf1d4b60a3d0ee40508a3484ffe6bcc9c51",
      "cold_exact": true,
      "input_block_locality": true
    },
    {
      "seed": 31019,
      "condition": "frozen",
      "source_sha256": "f2ab09468ef0ea25cc6a97a7c587d2569287ad88f2c4e25373ba04324a1d9c92",
      "cold_exact": true,
      "input_block_locality": true
    },
    {
      "seed": 31019,
      "condition": "paired",
      "source_sha256": "a9b91db56ffe4756ee5c6736a78b982a789925cc29cd9df43da6c708e00daa80",
      "cold_exact": true,
      "input_block_locality": true
    },
    {
      "seed": 31019,
      "condition": "erase_trace",
      "source_sha256": "3cde2d59d6a882926efb0943f0e8db7b5d809c84c3541aaedf97b2946b5f67ce",
      "cold_exact": true,
      "input_block_locality": true
    },
    {
      "seed": 31019,
      "condition": "cross_family",
      "source_sha256": "2854cd6f65ba2123cf7de8bbc00a7a963bff20c0119a6f6c176fa0d970f0b6f0",
      "cold_exact": true,
      "input_block_locality": true
    },
    {
      "seed": 31033,
      "condition": "frozen",
      "source_sha256": "9e55e7350f6fb4602e4dfe35833541d66ed606972a1a83a6102f0d637eb32057",
      "cold_exact": true,
      "input_block_locality": true
    },
    {
      "seed": 31033,
      "condition": "paired",
      "source_sha256": "f6ccef01790092800a4bb6db36cfbdcbc8818f75ffc34875a25c8464f5a2fcbe",
      "cold_exact": true,
      "input_block_locality": true
    },
    {
      "seed": 31033,
      "condition": "cross_family",
      "source_sha256": "6ca9fe484bfd5ea9d16407acb450cf6cc4b9c247270b5e051e578a08c03daa38",
      "cold_exact": true,
      "input_block_locality": true
    },
    {
      "seed": 31033,
      "condition": "erase_trace",
      "source_sha256": "f34cbecd51a566c6f34cf5970c26db6ab8ef75531a8d1bd95bfd100d086e02a8",
      "cold_exact": true,
      "input_block_locality": true
    }
  ],
  "new_training": false,
  "deployed": false,
  "normal_chat_or_vision_proven": false,
  "note": "Onecontinuationexample on discardedcopies only; not formaltraining/quality/retention evidence.",
  "resources": {
    "peak_rss_bytes": 92155904,
    "peak_commit_or_vms_bytes": 58417152,
    "os_process_peak_working_set_bytes": 50716672,
    "os_process_peak_pagefile_commit_bytes": 35483648,
    "samples": 33,
    "interval_seconds": 0.1,
    "limit_bytes": 2000000000,
    "observed_over_limit": false,
    "elapsed_seconds": 2.325012599991169,
    "hard_cap_enforced": false,
    "igpu_measured": false,
    "energy_joules": null,
    "note": "Tree sums may double-count shared pages; Windows pagefile is commit, not bytes swapped. No iGPU allocated."
  },
  "cap": {
    "enforced": true,
    "limit_bytes": 2000000000,
    "kind": "Windows per-process committed memory; shared pages monitored separately"
  }
}
