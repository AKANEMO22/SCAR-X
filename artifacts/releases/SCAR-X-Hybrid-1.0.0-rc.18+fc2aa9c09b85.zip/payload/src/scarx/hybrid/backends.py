"""Owned native VLM/FP32 ASR workers with explicit CPU or CUDA execution."""

import base64
import hashlib
import json
import secrets
import os
import socket
from pathlib import Path
import subprocess
import threading
import time
from urllib.request import Request, urlopen
from .store import encode
from .config import HybridConfig
from ..runtime.asr_profiles import selected_profile, model_path, verify_asr_storage, verify_execution_log
from .device_budget import gpu_headroom, audio_requires_release


class NativeBackends:
    def __init__(self, directory, store, monitor, config=None):
        self.directory = Path(directory)
        self.store = store
        self.monitor = monitor
        self.config = config or HybridConfig()
        self.vlm = None
        self.asr = None
        self.lock = threading.RLock()
        self.asr_lock = threading.RLock()
        self.logs = []
        self.cancel_idle = threading.Event()
        self.vlm_url = "http://127.0.0.1:18776"
        self.native_token = secrets.token_urlsafe(32)
        self.vlm_command = None
        self.asset_signatures = None
        self.asr_asset_signature = None
        self.asr_storage_receipt = None

    def asr_profile(self):
        return selected_profile(self.config.asr_model_name, self.config.asr_revision,
                                self.config.execution_mode)

    def asr_model_path(self):
        return model_path(self.directory, self.asr_profile())

    def ensure_asr_storage(self):
        path = self.asr_model_path()
        stat = path.stat()
        signature = (str(path), stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns)
        if signature != self.asr_asset_signature:
            self.asr_storage_receipt = None
            receipt = verify_asr_storage(self.directory, self.config.asr_model_name,
                                        self.config.asr_revision, self.config.execution_mode)
            current = path.stat()
            if signature != (str(path), current.st_size, current.st_mtime_ns, current.st_ctime_ns):
                raise RuntimeError("ASR asset changed while verifying its integrity")
            self.asr_storage_receipt = receipt
            self.asr_asset_signature = signature
        return path

    def wait_asr(self, timeout=120):
        deadline = time.monotonic() + timeout
        while True:
            code = self.asr.poll()
            if code is not None:
                return code
            self.monitor.check()
            if self.config.execution_mode == "gpu":
                if gpu_headroom(self.config.gpu_device)["free_MiB"] < 512:
                    raise MemoryError("ASR physical GPU reserve below 512 MiB; stop owned ASR without CPU fallback")
            if self.cancel_idle.is_set():
                raise InterruptedError("Foreground work preempts the owned background ASR chunk")
            if time.monotonic() >= deadline:
                raise TimeoutError("Owned ASR chunk did not finish within its timeout")
            time.sleep(0.25)

    def whisper_executable(self):
        runtime = (
            "whisper.cpp-b5454-cuda12.4"
            if self.config.execution_mode == "gpu"
            else "whisper.cpp-b5454"
        )
        return self.directory / "runtime" / runtime / "Release/whisper-cli.exe"

    def headers(self):
        return {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + self.native_token,
        }

    def _spawn(self, command, logname):
        if Path(command[0]).name == "llama-server.exe":
            self.vlm_command = list(command)
        # Popen gives the child its own handle; do not retain one Python file
        # handle for every frozen-ASR activation across a long-running session.
        with (self.directory / logname).open("ab") as log:
            child_env = None
            if (
                Path(command[0]).name == "llama-server.exe"
                and self.config.execution_mode == "gpu"
            ):
                child_env = dict(os.environ)
                if self.config.cuda_graphs:
                    child_env.pop("GGML_CUDA_DISABLE_GRAPHS", None)
                else:
                    child_env["GGML_CUDA_DISABLE_GRAPHS"] = "1"
            process = subprocess.Popen(
                command,
                stdout=log,
                stderr=subprocess.STDOUT,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
                env=child_env,
            )
        self.store.event(
            "worker_started",
            {
                "pid": process.pid,
                "command": [
                    (
                        "<internal-key>"
                        if i and str(command[i - 1]) == "--api-key"
                        else str(value)
                    )
                    for i, value in enumerate(command)
                ],
            },
            "runtime",
        )
        return process

    def pause_vlm_for_audio(self):
        if (self.config.execution_mode == "gpu"
                and self.asr_profile().name == "openai/whisper-small"):
            headroom = gpu_headroom(self.config.gpu_device)
            if headroom["free_MiB"] < 1800:
                raise MemoryError("Whisper-small requires 1800 MiB physical launch headroom; VLM stays resident, no CPU fallback")
            return
        report = self.monitor.sample()
        projected = (
            report.get("conservative_ram_bytes", report["rss_bytes"]) + 600_000_000
        )
        gpu = None
        if self.config.execution_mode == "gpu":
            gpu = gpu_headroom(self.config.gpu_device)
            if not audio_requires_release(gpu):
                return
        elif self.monitor.limit is None or projected <= self.monitor.limit:
            return
        if self.vlm and self.vlm.poll() is None:
            self.vlm.terminate()
            try:
                self.vlm.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.vlm.kill()
                self.vlm.wait()
            self.store.event(
                "vlm_suspended_for_audio",
                {
                    "projected_bytes": projected,
                    "limit_bytes": self.monitor.limit,
                    "GPU_headroom": gpu,
                    "reason": (
                        "GPU workspace reserve" if gpu else "CPU aggregate RAM headroom"
                    ),
                    "state": "frozen sensory model unloaded as a whole; SNN/evidence/checkpoint retained",
                    "cost": "next VLM call reloads whole checkpoint and loses prefix cache; no layer/weight paging",
                },
                "runtime",
            )
        self.vlm = None

    def ensure_vlm(self):
        if self.vlm is not None and self.vlm.poll() is None:
            return
        if not self.vlm_command:
            raise RuntimeError("VLM was never initialized")
        current = self._asset_signatures()
        if self.asset_signatures is not None and current != self.asset_signatures:
            from .qualification import verify_native_storage

            verify_native_storage(self.directory, self.config)
            self.asset_signatures = current
        self.monitor.check()
        started = time.monotonic()
        self.vlm = self._spawn(self.vlm_command, "vlm.log")
        self.wait(self.vlm, self.vlm_url + "/health")
        self.store.event(
            "vlm_resumed",
            {
                "seconds": time.monotonic() - started,
                "prefix_cache": "cold",
                "precision": "original BF16/F32",
            },
            "runtime",
        )

    def hibernate(self, reason, permitted=None):
        with self.lock:
            if self.cancel_idle.is_set() or (permitted is not None and not permitted()):
                raise InterruptedError("Foreground preempts model hibernation")
            if self.vlm is None or self.vlm.poll() is not None:
                self.vlm = None
                return False
            pid = self.vlm.pid
            self.vlm.terminate()
            try:
                self.vlm.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.vlm.kill()
                self.vlm.wait()
            self.vlm = None
            self.store.event(
                "vlm_hibernated",
                {
                    "pid": pid,
                    "reason": reason,
                    "ALIF_retained": True,
                    "weights_changed": False,
                    "next_answer": "reloads frozen model; cold prefix",
                },
            )
            return True

    def wake(self):
        with self.lock:
            self.ensure_vlm()

    def _asset_signatures(self):
        return tuple(
            (p.name, p.stat().st_size, p.stat().st_mtime_ns)
            for p in (
                self.directory / "models/native/qwen-native-bf16.gguf",
                self.directory / "models/native/qwen-vision-native-bf16.gguf",
            )
        )

    def start(self):
        native = self.directory / "models/native"
        runtime = (
            "llama.cpp-b12360-cuda12.4"
            if self.config.execution_mode == "gpu"
            else "llama.cpp-b12360"
        )
        llama = self.directory / "runtime" / runtime / "llama-server.exe"
        whisper = self.whisper_executable()
        selected_asr = self.ensure_asr_storage()
        for path in (
            llama,
            whisper,
            native / "qwen-native-bf16.gguf",
            native / "qwen-vision-native-bf16.gguf",
            selected_asr,
        ):
            if not path.is_file():
                raise FileNotFoundError("Run setup/conversion first: " + str(path))
        for port in (18776,):
            with socket.socket() as probe:
                if probe.connect_ex(("127.0.0.1", port)) == 0:
                    raise RuntimeError(
                        "Native worker port is occupied; refusing to load a second model: "
                        + str(port)
                    )
        # Modes change execution placement, never stored BF16/F32 model tensors.
        placement = (
            ["--device", "CUDA" + str(self.config.gpu_device)]
            if self.config.execution_mode == "gpu"
            else ["--no-mmproj-offload"]
        )
        self.vlm = self._spawn(
            [
                str(llama),
                "-m",
                str(native / "qwen-native-bf16.gguf"),
                "--mmproj",
                str(native / "qwen-vision-native-bf16.gguf"),
                *placement,
                "--host",
                "127.0.0.1",
                "--port",
                "18776",
                "-ngl",
                "99" if self.config.execution_mode == "gpu" else "0",
                "-t",
                "4",
                "-tb",
                "4",
                "-c",
                str(self.config.context_tokens),
                "-np",
                "1",
                "-b",
                str(self.config.batch_size),
                "-ub",
                str(self.config.microbatch_size),
                "-fa",
                self.config.flash_attention,
                "--no-warmup",
                "--cache-ram",
                "0",
                "--cache-type-k",
                "bf16",
                "--cache-type-v",
                "bf16",
                "--jinja",
                "--reasoning-budget",
                "0",
                "--fit",
                "off",
                "--alias",
                "scarx-hybrid",
                "--api-key",
                self.native_token,
            ],
            "vlm.log",
        )
        self.wait(self.vlm, self.vlm_url + "/health")
        self.monitor.check()
        self.asset_signatures = self._asset_signatures()
        # Frozen ASR is activated only for an audio chunk. This is component
        # scheduling, not weight paging or reduced precision. A single VLM and
        # one audio chunk execute at a time under the aggregate RAM budget.

    def stop_asr(self):
        process = self.asr
        if process and process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
            self.store.event(
                "asr_yielded_memory",
                {
                    "pid": process.pid,
                    "precision": "FP32 unchanged",
                    "reason": "bounded scheduling before VLM execution",
                },
                "runtime",
            )
        self.asr = None

    def wait(self, process, url, timeout=120):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if process.poll() is not None:
                raise RuntimeError("Native worker exited; inspect worker log")
            self.monitor.check()
            try:
                with urlopen(url, timeout=1) as response:
                    if response.status < 400:
                        return
            except Exception:
                pass
            time.sleep(0.1)
        raise TimeoutError("Native worker readiness deadline")

    def generate(
        self,
        messages,
        max_tokens=160,
        background=False,
        tools=None,
        tool_choice=None,
        response_format=None,
    ):
        if not 1 <= max_tokens <= 4096:
            raise ValueError("Bounded output")
        body = {
            "model": "scarx-hybrid",
            "messages": messages,
            "max_tokens": max_tokens,
            "temperature": 0.0,
            "chat_template_kwargs": {"enable_thinking": False},
            "repeat_penalty": 1.05,
            "cache_prompt": True,
            "stream": background,
        }
        if tools:
            body["tools"] = tools
            if tool_choice is not None:
                body["tool_choice"] = tool_choice
        if response_format is not None:
            body["response_format"] = response_format
        started = time.monotonic()
        with self.lock:
            self.stop_asr()
            self.ensure_vlm()
            if background and self.cancel_idle.is_set():
                raise InterruptedError(
                    "Foreground request preempts background inference"
                )
            self.monitor.check()
            with urlopen(
                Request(
                    self.vlm_url + "/v1/chat/completions",
                    data=encode(body).encode(),
                    headers=self.headers(),
                ),
                timeout=120,
            ) as response:
                if background:
                    parts = []
                    usage = {}
                    received = 0
                    # Token stream permits cooperative preemption between tokens.
                    for line in response:
                        if self.cancel_idle.is_set():
                            raise InterruptedError(
                                "Foreground request preempted background inference"
                            )
                        received += len(line)
                        if received > 1_000_000:
                            raise ValueError("Model stream exceeds bound")
                        if not line.startswith(b"data: "):
                            continue
                        event = line[6:].strip()
                        if event == b"[DONE]":
                            break
                        item = json.loads(event)
                        usage = item.get("usage") or usage
                        for choice in item.get("choices", []):
                            parts.append(choice.get("delta", {}).get("content") or "")
                    result = {
                        "choices": [{"message": {"content": "".join(parts)}}],
                        "usage": usage,
                    }
                else:
                    raw = response.read(1_000_001)
                    if len(raw) > 1_000_000:
                        raise ValueError("Model response exceeds bound")
                    result = json.loads(raw)
            self.monitor.check()
        text = result["choices"][0]["message"].get("content") or ""
        elapsed = time.monotonic() - started
        audit = []
        for message in messages:
            row = dict(message)
            if isinstance(row.get("content"), list):
                row["content"] = [
                    (
                        {
                            "type": "image_url",
                            "image_sha256": hashlib.sha256(
                                part["image_url"]["url"].encode()
                            ).hexdigest(),
                            "encoded_bytes": len(part["image_url"]["url"]),
                        }
                        if part.get("type") == "image_url"
                        else part
                    )
                    for part in row["content"]
                ]
            audit.append(row)
        self.store.event(
            "vlm_answer",
            {
                "messages": audit,
                "answer": text,
                "elapsed_seconds": elapsed,
                "usage": result.get("usage"),
                "timings": result.get("timings"),
            },
            "vlm",
        )
        return {
            "text": text,
            "usage": result.get("usage", {}),
            "seconds": elapsed,
            "raw": result,
        }

    def stream(
        self,
        messages,
        max_tokens=512,
        tools=None,
        tool_choice=None,
        response_format=None,
    ):
        body = {
            "model": "scarx-hybrid",
            "messages": messages,
            "max_tokens": min(4096, max(1, int(max_tokens))),
            "temperature": 0.0,
            "stream": True,
            "stream_options": {"include_usage": True},
            "cache_prompt": True,
            "chat_template_kwargs": {"enable_thinking": False},
            "repeat_penalty": 1.05,
        }
        if tools:
            body["tools"] = tools
        if tool_choice is not None:
            body["tool_choice"] = tool_choice
        if response_format is not None:
            body["response_format"] = response_format
        with self.lock:
            self.stop_asr()
            self.ensure_vlm()
            self.monitor.check()

            with urlopen(
                Request(
                    self.vlm_url + "/v1/chat/completions",
                    data=encode(body).encode(),
                    headers=self.headers(),
                ),
                timeout=120,
            ) as response:
                received = 0
                for line in response:
                    received += len(line)
                    if received > 2_000_000:
                        raise ValueError("Native stream exceeds bound")
                    if not line.startswith(b"data: "):
                        continue
                    value = line[6:].strip()
                    if value == b"[DONE]":
                        break
                    yield json.loads(value)
            self.monitor.check()

    def summary_token_budget(self, messages):
        """Exact native tokenizer count; output fits the measured16K buffer."""
        with self.lock:
            self.ensure_vlm()

            def post(path, body):
                with urlopen(
                    Request(
                        self.vlm_url + path,
                        data=encode(body).encode(),
                        headers=self.headers(),
                    ),
                    timeout=20,
                ) as response:
                    raw = response.read(6_000_001)
                if len(raw) > 6_000_000:
                    raise ValueError("Summary tokenizer response bound exceeded")
                return json.loads(raw)

            prompt = post(
                "/apply-template",
                {
                    "messages": messages,
                    "chat_template_kwargs": {"enable_thinking": False},
                },
            )["prompt"]
            count = len(
                post("/tokenize", {"content": prompt, "parse_special": True})["tokens"]
            )
            room = self.config.context_tokens - count - 32
            if room < 128:
                raise ValueError(
                    "Summary input leaves insufficient output room in measured context"
                )
            budget = min(4096, room)
            self.store.event(
                "summary_output_budget",
                {
                    "input_tokens": count,
                    "output_tokens": budget,
                    "context_tokens": self.config.context_tokens,
                    "measurement": "native tokenizer; no fake64K",
                },
            )
            return budget

    def describe(self, image_path, background=False):
        data = Path(image_path).read_bytes()
        if len(data) > 2_000_000:
            raise ValueError("Image input exceeds bounded frame size")
        return self.generate(
            [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": "data:image/jpeg;base64,"
                                + base64.b64encode(data).decode()
                            },
                        },
                        {
                            "type": "text",
                            "text": "Describe the visible image briefly, including shapes, colors, objects, actions and readable text. Do not infer unseen events or speech.",
                        },
                    ],
                }
            ],
            max_tokens=64,
            background=background,
        )

    def transcribe(self, wav_path):
        import uuid

        source = Path(wav_path).resolve()
        if not source.is_file() or source.stat().st_size > 2_000_000:
            raise ValueError("Audio chunk exceeds bound or is unavailable")
        started = time.monotonic()
        work = self.directory / "work" / "asr"
        work.mkdir(parents=True, exist_ok=True)
        output = work / uuid.uuid4().hex
        command = [
            str(self.whisper_executable()),
            "-m",
            str(self.asr_model_path()),
            "-f",
            str(source),
            "-l",
            "auto",
            "-t",
            "2",
            *(
                ["-dev", str(self.config.gpu_device)]
                if self.config.execution_mode == "gpu"
                else ["-ng"]
            ),
            "-ojf",
            "-of",
            str(output),
        ]
        with self.lock, self.asr_lock:
            self.monitor.check()
            self.ensure_asr_storage()
            self.pause_vlm_for_audio()
            asr_log = self.directory / "asr.log"
            log_offset = asr_log.stat().st_size if asr_log.exists() else 0
            self.asr = self._spawn(command, "asr.log")
            try:
                if self.wait_asr(timeout=120):
                    raise RuntimeError("Native FP32 ASR failed; inspect asr.log")
                with asr_log.open("rb") as current_log:
                    current_log.seek(log_offset)
                    fresh_log = current_log.read(262145)
                if len(fresh_log) > 262144:
                    raise ValueError("ASR worker log exceeds bounded current-call evidence")
                execution = verify_execution_log(fresh_log.decode("utf-8", errors="replace"),
                                                 self.config.execution_mode, self.config.gpu_device)
                path = output.with_suffix(".json")
                if path.stat().st_size > 1_000_000:
                    raise ValueError("ASR result exceeds bound")
                result = json.loads(path.read_text(encoding="utf-8"))
                text = " ".join(
                    row.get("text", "").strip()
                    for row in result.get("transcription", [])
                ).strip()
                self.monitor.check()
            finally:
                self.stop_asr()
            self.store.event(
                "asr_result",
                {
                    "text": text,
                    "seconds": time.monotonic() - started,
                    "source": str(source),
                    "raw_result": str(path),
                    "precision": "FP32",
                    "ASR_identity": self.asr_profile().identity(),
                    "model_path": str(self.asr_model_path()),
                    "storage_verified": self.asr_storage_receipt is not None,
                    **execution,
                    "device": self.config.execution_mode,
                    "backend": "one owned whisper-cli per bounded chunk; no ASR HTTP service",
                },
                "asr",
            )
        return text

    def close(self):
        for process in (self.asr, self.vlm):
            if process and process.poll() is None:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
        for log in self.logs:
            log.close()
