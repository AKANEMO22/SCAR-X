param([switch]$Check)
$ErrorActionPreference = 'Stop'
$settingsPath = Join-Path $env:LOCALAPPDATA 'hermes\plugins\scarx-hybrid\dashboard\settings.json'
if (-not (Test-Path -LiteralPath $settingsPath)) { throw 'Existing SCAR-X Hybrid registration is required.' }
$settings = Get-Content -LiteralPath $settingsPath -Raw | ConvertFrom-Json
$python = [string]$settings.python
if (-not (Test-Path -LiteralPath $python)) { throw 'Registered runtime Python is missing.' }
$targetRoot = Split-Path -Parent ([string]$settings.entrypoint)
& $python (Join-Path $targetRoot 'scripts\hybrid_service.py') stop
if ($LASTEXITCODE -ne 0) { throw 'SCAR-X command failed. Keep the console details and backup; do not delete user data.' }
