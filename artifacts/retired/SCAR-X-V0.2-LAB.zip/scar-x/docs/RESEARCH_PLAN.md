# SCAR-X — Kế hoạch nghiên cứu chính

**Phiên bản tài liệu:** 1.1 — 2026-11-09. **Trạng thái:** người dùng đã phê duyệt Product-first và triển khai MVP V0.1. Lõi nghiên cứu vẫn PIVOT; không mở huấn luyện lớn.

**Phán quyết nghiên cứu: PIVOT cơ chế học; NO-GO cho tăng quy mô với các quy tắc hiện tại.** Gate nghiên cứu không còn là điều kiện chặn xây ứng dụng thử nghiệm. Có acceptance/demo sản phẩm mới, không được gọi là đã qua gate forgetting/representation.

Đây là **master plan duy nhất** của SCAR-X. [README](../README.md) là điểm vào; [STATUS](STATUS.md) là tóm tắt tiến độ; [kiến trúc](research/02_SCAR_X_ARCHITECTURE.md) là tài liệu kỹ thuật. Các protocol đã chạy trong [experiments](../experiments/) và báo cáo trong [runs](../runs/INDEX.md) là hồ sơ lịch sử bất biến, không phải các kế hoạch phát triển cạnh tranh.

**Quy trình hiện tại:** Build → Run → Interact → Learn → Test → Improve → Repeat. Mỗi vòng tạo một cải thiện dùng trực tiếp trong [ứng dụng local](../README.md); giữ bản chạy ổn gần nhất nếu rule mới chưa tốt. Nghiên cứu tiếp tục làm công cụ kiểm tra, không trì hoãn sản phẩm tới khi hoàn thiện kiến trúc.

**Kết quả tiếp theo ngày2026-11-09:** đã huấn luyện hai pilot nhỏ48hidden độc lập, không modelpretrained/BPTT. Languagewordgeneration chưa đạt (3/16testexact), visiondigits đạt89,17% diagnostic. V0.2LAB được mở opt-in để dạy/quan sát checkpoint thật, không thay V0.1 hoặc đổi phán quyếtresearch. Vision không phải screenshot/OCR/visualQA; supervisedlesson sửa `chào bạn` là trainingpoint, không heldoutproof. [README mục9](../README.md#9-v02-lab-ngôn-ngữ-và-thị-giác-đã-huấn-luyện) và [pilotV2](../runs/20261108T190315Z-language-vision-pilot-v2-6a889e/report.md) là evidence.

## Mục lục

1. [Project Vision](#1-project-vision)
2. [Current Status](#2-current-status)
3. [Existing Architecture](#3-existing-architecture)
4. [Proposed Extensions](#4-proposed-extensions)
5. [Conflict & Compatibility Matrix](#5-conflict--compatibility-matrix)
6. [Learning Lifecycle](#6-learning-lifecycle)
7. [Experiment Roadmap](#7-experiment-roadmap)
8. [Hardware & Resource Budget](#8-hardware--resource-budget)
9. [Learning & Memory Metrics](#9-learning--memory-metrics)
10. [Risks and Open Questions](#10-risks-and-open-questions)
11. [Implementation Checklist](#11-implementation-checklist)
12. [Decision Log](#12-decision-log)
13. [Change Log](#13-change-log)

## 1. Project Vision

SCAR-X nghiên cứu **kiến trúc neural có khả năng học thích nghi suốt quá trình hoạt động**: tích lũy kinh nghiệm, tạo representation hữu ích, hình thành kỹ năng, giữ kiến thức cũ và còn khả năng học điều mới. Representation là cách mạng biến tín hiệu đầu vào thành đặc trưng bên trong có ích cho nhiều tình huống.

Lõi chính là **Spiking Recurrent Neural Network** — mạng neuron phát xung có kết nối hồi quy — với LIF/ALIF và local synaptic learning. Synapse phải thay đổi trọng số thật; không dùng một LLM có sẵn kèm RAG để thay thế câu hỏi nghiên cứu neural. Kho trải nghiệm và công cụ xác minh hỗ trợ lõi; khả năng truy xuất dữ liệu không chứng minh lõi đã học kỹ năng.

Số tham số và độ dài context là biến kỹ thuật, không phải mục tiêu trung tâm. Mục tiêu 1M context đã ngừng làm tiêu chí kiến trúc; không xóa số đo cũ hoặc phủ nhận rằng context kỹ thuật vẫn tồn tại. Đích năng lực đa năng dài hạn chưa được chứng minh và không là lời hứa của vòng nghiên cứu hiện tại.

### Ràng buộc giữ nguyên

- CPU-only bắt buộc; CPU-first trong thiết kế. iGPU tùy chọn. GPU rời có thể tăng tốc nghiên cứu, nhưng kết quả trên GPU không thay cho phép đo CPU.
- Mục tiêu toàn phiên vận hành **≤2.000.000.000 byte RAM**, bao gồm học, củng cố, lưu checkpoint và rollback; dung lượng trên SSD phải báo riêng.
- Không backward qua toàn mạng hoặc BPTT trong nhánh chính. Sai số tại chính readout, dấu vết tại synapse và tín hiệu điều biến được phép. BPTT chỉ là đối chứng tách biệt.
- Không tăng từ mạng thử nghiệm 48 neuron lên model lớn, không huấn luyện ngôn ngữ 10M token, không tối ưu C++/iGPU trong Phase 2.2 đề xuất.
- Giữ nguyên tiêu chí đã đăng ký. Tiêu chí mới phải ghi trước thí nghiệm mới; không chấm lại kết quả cũ bằng tiêu chí có lợi hơn.
- Phê duyệt docs-only trước đây được thay bằng quyền triển khai MVP V0.1, UI, sửa tích hợp và test cần thiết. Không tự tải model/corpus lớn, gọi paid API, thay core bằng LLM hoặc mở rộng tài nguyên. Dạy tương tác thường ngày không cần chờ protocol nghiên cứu; benchmark khoa học vẫn phải đăng ký trước.

## 2. Current Status

### Hồ sơ thực nghiệm đã có

**Sản phẩm V0.1 hiện có:** web localhost Windows dùng PlasticCore48ALIF; dạy ví dụ có verifier, batch A/B, xem spike/weights/memory/history, save/restore learner+replay+RNG trong SQLite transaction và tài nguyên thực tế. [Acceptance run](../runs/20261108T175211Z-mvp-v01-acceptance-3d887d/report.md) kiểm trước/sau trên biến thể chưa train, process restart và restore. Demo này chưa chứng minh hidden representation hay solved lifelong learning; không chấm lại research gates.

| Giai đoạn | Bằng chứng | Kết luận trong phạm vi đã thử |
|---|---|---|
| Phase 2 | [Báo cáo 06](research/06_FEASIBILITY_VERDICT.md), [protocol](../experiments/phase2-v1.md) | Full và readout-only đều đạt 100% recall đơn giản; chưa phân biệt lợi ích hidden. Forgetting khoảng 20,8–23,9 điểm phần trăm, không đạt ngưỡng. |
| Audit Phase 2 | [Báo cáo 08](research/08_PHASE21_RESULTS.md), [raw audit](../runs/20261108T162931Z-phase21-v1-f3fa83/phase2_audit.json) | Ở task đầu, thay lại head cũ cứu accuracy rõ hơn thay hidden cũ; replay thiếu 15–17/80 nhóm context–nhãn. Đây là can thiệp trên task đầu, không phải phân rã mọi nguồn quên. |
| Phase 2.1 | [Kết quả](research/08_PHASE21_RESULTS.md), [protocol](../experiments/phase21-v1.md), [bổ sung lifelong](../experiments/phase21-lifelong-amendment.md) | 303 trial mới; 3 seed phát triển, 8 seed xác nhận và 8 seed mới cho strict binding audit. Các condition ghép cặp không được tính như seed độc lập mới. |
| Representation | [Strict binding audit](../runs/20261108T170757Z-phase21-binding-audit-v1-a64369/report.md) | Order có probe gain trung bình khoảng 1,81 điểm, chưa đạt ngưỡng; strict binding accuracy khoảng 50,2%. Chưa chứng minh hidden học representation hữu ích theo gate. |
| Stream không task boundary | [Kết quả stream](../runs/20261108T163521Z-phase21-lifelong-v1-48ee0f/report.md) | Metaplasticity giảm số đo forgetting nhưng accuracy gần 50%; mọi condition thất bại ở gate chất lượng + retention. |
| Tái lập và tài nguyên | [Kiểm tái lập](../runs/20261108T170909Z-phase21-reproduction-efdb4a/report.md), [catalog](../artifacts/phase21-summary.json) | Continuation và lịch cập nhật đã kiểm; RAM quan sát trong trần ở workload nhỏ. Chưa có giới hạn cứng OS hoặc chứng nhận vận hành lâu dài. |

Không so mức forgetting Phase 2 và Phase 2.1 trực tiếp như một tiến bộ: forward, độ dài episode và thiết kế bài thử đã thay đổi. Bài binding ban đầu có shortcut bag-of-values; kết quả đó giữ nguyên nhưng không được dùng chứng minh hiểu quan hệ. Xem [audit phép đo](decisions/0003-phase21-evaluation-audit.md).

### Trạng thái khả năng

- **Đã triển khai:** ALIF, recurrent synapses, readout local, STDP/score eligibility, importance heuristic, stable anchors, replay giới hạn, checkpoint của từng lõi, episodic text store và logging.
- **Đã kiểm trong bài nhỏ:** trọng số thay đổi, lưu/khôi phục và tiếp tục cập nhật tái lập; liên kết đơn giản học được ở cấp hệ thống, có đóng góp của readout.
- **Đã thất bại ở cấu hình/ngân sách đã thử:** gate representation và gate giữ kỹ năng. Điều này không bác bỏ mọi SNN hoặc mọi local rule.
- **Chưa chứng minh:** tích lũy semantic/procedural knowledge, generalization kỹ năng, forward transfer bền vững, plasticity sau 50/100 giai đoạn, khả năng ngôn ngữ/suy luận đa năng.
- **Đã tích hợp trong MVP có cấu trúc:** lesson từ tác vụ có rule kiểm nhãn → local update → episodic record → atomic snapshot learner/replay/RNG → restore. Raw text → bài học neural và phiên offline tự động/general Experience-to-Skill vẫn chưa có. Không gọi demo phân loại tín hiệu là chu trình tri thức tổng quát hoàn chỉnh.

## 3. Existing Architecture

### 3.1 Topology thực tế

Lõi được tổ chức thành **một quần thể recurrent**, không có stack nhiều tầng hidden. Gọi D là số kênh đầu vào, H số neuron, K số kết nối recurrent đi vào mỗi neuron, O số lớp đầu ra và R số hàng được học đồng thời.

| Thành phần | Tổ chức đã có | Mã nguồn |
|---|---|---|
| Input → hidden | Ma trận dense `W_in[H,D]`; mỗi neuron nhận mọi kênh đầu vào | [core.py](../src/scarx/neural/core.py) |
| Hidden → hidden | `indices[H,K]` chọn K neuron nguồn khác nhau trong từng hàng, cố định theo seed; trọng số `W_rec[H,K]` | [khởi tạo topology](../src/scarx/neural/core.py#L66) |
| Neuron | Điện thế, rò, spike, thích nghi ngưỡng; Phase 2.1 dùng spike Bernoulli | [plasticity.py](../src/scarx/neural/plasticity.py) |
| Hidden → readout | Ma trận dense `W_out[O,H]` và bias; đọc trace spike đã làm mượt | [readout](../src/scarx/neural/core.py#L125) |
| Plastic block | R hàng input/recurrent active mỗi episode; luân phiên giữa episode, không đổi topology | [reset state](../src/scarx/neural/core.py#L80) |
| Stable/importance | Bản sao stable weights; Phase 2.1 có importance cho input, recurrence, readout và bias | [local update](../src/scarx/neural/plasticity.py#L65) |

**Cấu hình nghiên cứu hiện tại:** H=48, K=8, R=12; representation/stream D=8, O=2; stress 20 context D=24, O=4. `Config` mặc định và byte demo có cấu hình khác, không đại diện cho gate Phase 2.1. Recurrence có thể gồm self-connection; không có bảo đảm Dale's law, chia excitatory/inhibitory, synapse sinh hóa hay mô phỏng đầy đủ não.

Code hiện dùng ALIF; dạng LIF không thích nghi có thể biểu diễn bằng `adaptation_strength=0`, chưa có một module LIF riêng được đánh giá như phương pháp độc lập trong các kết quả hiện tại.

### 3.2 Truyền tín hiệu

Với spike cũ z và input x:

`current[j] = W_in[j]·x + Σ_k W_rec[j,k] z[indices[j,k]]`

`v = 0,85 v + current; threshold_adapted = 0,65 + 0,08 a`

Phase 2 phát xung khi v vượt ngưỡng. Phase 2.1 lấy xác suất `sigmoid((v-threshold_adapted)/0,4)` rồi lấy mẫu Bernoulli. Sau đó trừ điện thế reset theo spike, cập nhật adaptation `a = 0,95 a + z`, và feature `f = 0,92 f + 0,08 z`.

`p = softmax(W_out f + bias)` tạo đầu ra. Readout hiện làm phân lớp trong benchmark; không phải một bộ suy luận ngôn ngữ. `forward(sequence)` reset working state trước mỗi episode, giữ weights; do đó hệ hiện học tuần tự theo trải nghiệm có đoạn, chưa phải một dòng neuron state không bao giờ reset. Online learning không bắt buộc sửa trọng số sau mọi token; việc thay chính sách reset là câu hỏi riêng cần kiểm chứng.

### 3.3 Học và credit assignment

Credit assignment là xác định synapse nào nên được thưởng/phạt cho kết quả sau cùng.

- **Readout:** sai số `one_hot(target)-p` nhân feature cục bộ để cập nhật synapse đi vào đầu ra. Không truyền vector sai số qua `W_out` về hidden.
- **Phase 2 hidden:** trace STDP từ hoạt động trước/sau synapse, nhân scalar advantage theo reward hoặc `p[target]` so với EMA baseline.
- **Phase 2.1 hidden:** rule STDP hoặc score eligibility; rule score dùng dấu vết input/recurrence đã lọc và residual `(spike-probability)/0,4` tại neuron, tích lũy trong đoạn. Cuối đoạn nhân scalar advantage của `-loss` hoặc reward được cung cấp. Mọi neuron active nhận cùng scalar; chưa có credit hữu ích riêng cho từng neuron.
- **Metaplasticity:** giảm độ lớn học theo importance và kéo weights về stable anchor. Importance hiện tích lũy độ lớn tín hiệu cục bộ, không đo đóng góp nhân quả vào kỹ năng. Clipping, block rotation và trace xấp xỉ khiến rule không được coi là một gradient toàn mạng chính xác.
- **Nhiều thang thời gian:** weights cập nhật mỗi trải nghiệm; stable anchor EMA theo chặng hoặc mỗi 64 update; một số condition giảm importance mỗi 32 update. Stable anchor là bản sao dùng regularization, chưa là một memory system đã tự học tri thức bền vững.

Không có backward toàn mạng trong [neural](../src/scarx/neural/) hoặc [learning](../src/scarx/learning/). [controls.py](../src/scarx/evaluation/controls.py) có BPTT riêng. SI ở readout chỉ là control đầu ra, không được quảng bá như tái lập whole-network Synaptic Intelligence.

### 3.4 Memory và controller thực tế

```mermaid
flowchart LR
  X[Chuỗi tín hiệu] --> N[ALIF recurrent]
  N --> F[Trace spike]
  F --> Y[Readout]
  T[Nhãn hoặc reward của bài thử] --> L[Local update cuối đoạn]
  Y --> L
  L --> N
  B[Replay buffer số] --> L
  L --> S[Stable anchor và importance]
  E[EpisodeStore SQLite] --> Q[Tìm kiếm văn bản riêng]
  C[Controller cũ] --> V[Development guard và rollback SpikingCore]
```

Kho SQLite và replay số là hai thành phần khác nhau. [EpisodeStore](../src/scarx/memory/store.py) lưu raw text, nguồn, hash, thời gian, loại và cờ `verified`; tìm kiếm FTS5. [ReplayBuffer](../src/scarx/learning/replay.py) giữ chuỗi số và nhãn với capacity cố định. Chưa có pipeline tự động chuyển raw text thành một bài học đúng cho neural core. [TextAgent](../src/scarx/interfaces/text.py) không dùng retrieval khi generate; byte demo chưa được huấn luyện ngôn ngữ.

[LearningController](../src/scarx/learning/controller.py) nay chọn loader theo loại lõi, đọc lại được `plasticity-v1`; thuật toán neural không đổi. [LifelongLearner](../src/scarx/learning/lifelong.py) có bundle save atomic và vẫn đọc legacy hai file. [Workbench](../src/scarx/app/state.py) đóng gói learner/replay/orchestration RNG/counters và commit trong cùng SQLite transaction với experience/history/active pointer. Đợt lỗi khôi phục object gốc; restart lấy generation đã commit. Kiểm thử đã bao gồm commit fault, process interruption và state continuation. Transaction này phục vụ hai tác vụ MVP; không đồng nghĩa đã có verifier dữ kiện tự do hoặc consolidation tự động.

Prediction của MVP lấy neural softmax trung bình4 stochastic passes; expected label là kết quả verifier riêng. Memory search không tham gia trả lời. Giao diện nhập tín hiệu, xem trước/sau và history không giả lập chatbot ngôn ngữ tự nhiên.

### 3.5 Vì sao chưa thể gọi là AI đa năng?

Mạng còn nhỏ, khởi tạo ngẫu nhiên, representation chưa đủ; reward scalar chưa phân công credit tốt. Readout có thể học liên kết nhưng bị interference. Nhiệm vụ mới chưa tạo generalization đáng tin. Chưa có học ngôn ngữ, bộ dữ liệu tương ứng hoặc đánh giá suy luận đa năng. Nối thêm memory không tự sửa các giới hạn đó. Tính giống sinh học của ALIF và local rule không phải bằng chứng năng lực hoặc tính mới.

## 4. Proposed Extensions

Tất cả nội dung mới trong mục này là **đề xuất nghiên cứu**, không phải tính năng đã hoàn thành. Không đề xuất thay core hoặc dựng kiến trúc khác trong lần cập nhật docs.

### 4.1 Ưu tiên nguyên nhân gốc

1. Kiểm chứng hidden tạo feature mới có ích, độc lập với readout.
2. Cải thiện credit assignment trong phạm vi tín hiệu local/điều biến đã cho phép; công bố đường đi mọi tín hiệu học.
3. Giữ ánh xạ readout cũ khi học ánh xạ mới; không coi đóng băng toàn bộ mạng là giải pháp học liên tục.
4. Đo importance theo mức hữu ích đối với nhiệm vụ và plasticity, thay vì mặc định hoạt động lớn là quan trọng.
5. Chỉ đánh giá replay/consolidation như thành phần tạo kỹ năng khi bốn điểm trên có phép đo phân biệt được.

Chưa chọn một local rule mới để triển khai. Các ứng viên cần được mô tả toán học, chỉ rõ state phụ và tín hiệu không-local, rồi duyệt trước khi chạy. Bộ khung hiện tại ghép các ý tưởng đã có; tính mới tiềm năng phải nằm ở cơ chế có lợi thế đo được, không ở tên gọi “lifelong”, “sleep” hoặc việc gộp module.

### 4.2 Experience-to-Skill và phân công trách nhiệm

| Mục tiêu | Neural core phải làm gì | Memory hỗ trợ gì | Learning controller phải làm gì | Hiện trạng |
|---|---|---|---|---|
| Ghi một trải nghiệm | Mã hóa tín hiệu thành state tạm | Giữ bản gốc và nguồn | Liên kết input, hành động, kết quả | Có thành phần riêng, chưa tích hợp lifecycle |
| Học đúng/sai | Cập nhật synapse có eligibility | Giữ bằng chứng/phản hồi | Xác minh nhãn, chọn reward, quyết định có học | Update có; xác minh tự động chưa có |
| Liên kết trải nghiệm | Học feature/quan hệ chia sẻ | Nhóm hoặc truy xuất mẫu liên quan | Chọn mẫu không rò rỉ test | Chưa chứng minh representation/transfer |
| Đúc kết quy luật | Weights hỗ trợ xử lý tổ hợp chưa gặp | Cung cấp ví dụ, không thay neural rule | Đo generalization với retrieval tắt | Mục tiêu nghiên cứu |
| Củng cố | Giữ kỹ năng và tiếp tục thích nghi | Bounded replay và nguồn xác minh | Lập phiên, budget, guard, commit/rollback | Replay/anchors có; phiên offline hoàn chỉnh chưa có |
| Áp dụng lâu dài | State reset nhưng weights vẫn giải đúng trường hợp mới | Tra cứu bằng chứng khi tác vụ cần | Phân biệt kết quả neural và kết quả có retrieval | Persistence có; skill recall/generalization chưa đạt |

Ví dụ “học quy luật sửa lỗi lập trình” là minh họa đích dài hạn. Vòng tới dùng tác vụ quan hệ nhân tạo có đáp án kiểm được, chưa hứa chuyển trực tiếp sang viết code hoặc hiểu văn bản.

### 4.3 Các lớp trí nhớ

| Loại | Định nghĩa thao tác | Trạng thái |
|---|---|---|
| Working memory | Điện thế, adaptation và traces trong episode | Đã có, hữu hạn và thường reset |
| Episodic memory | Bản gốc trải nghiệm, kết quả và nguồn | Text store và replay số có riêng; chưa hợp nhất |
| Semantic memory | Quy luật/khái niệm dùng được trên ví dụ chưa gặp | Chưa chứng minh; không đồng nhất với mục trong SQLite |
| Procedural memory | Kỹ năng thực thi được sau reset/restart và đổi tình huống | Chưa chứng minh; không đồng nhất với tập câu trả lời đã lưu |

Một kỹ năng có thể phân bố trong cùng quần thể neuron; chưa cần bốn mạng neural riêng. Tách nhãn memory để thiết kế phép đo, không tự tăng module hoặc dung lượng.

### 4.4 Offline consolidation có giới hạn

Phiên đề xuất: chọn trải nghiệm có bằng chứng → encode thành bài học → snapshot toàn trạng thái → local updates/replay → verify bằng guard phát triển → đo plasticity → commit hoặc rollback. Không dùng final test để rollback hay chọn rule.

MVP cho phép local teaching và replay thủ công có giới hạn, không yêu cầu research forgetting gate để dùng thử. Phiên offline Experience-to-Skill riêng và chạy tự động khi máy rảnh vẫn là bước sau: cần budget RAM/CPU/thời gian, hủy/tạm dừng được, không cập nhật giữa lượt phục vụ. Chưa xây scheduler hoặc mô phỏng giấc ngủ hoàn chỉnh.

Phát hiện mâu thuẫn không bảo đảm biết dữ kiện nào đúng. Phải giữ nguồn, thời điểm, tình trạng bằng chứng và khả năng có thay đổi thực tế. Không ép model giữ hai nhãn trái nhau cho cùng input không có dấu hiệu phân biệt; không tự dùng output chưa kiểm của model làm nhãn đúng.

## 5. Conflict & Compatibility Matrix

“Đã xử lý” ở đây có thể là quyết định/phân loại trong docs; không có nghĩa lỗi code đã được sửa.

| Vấn đề | Vị trí | Mức độ / ảnh hưởng | Quyết định hoặc đề xuất | Trạng thái |
|---|---|---|---|---|
| 1M context và lifelong | [ADR0002](decisions/0002-lifelong-adaptive-intelligence.md), [thiết kế cũ](research/05_EXPERIMENT_DESIGN.md) | Vừa; backlog cũ dễ hiểu nhầm | Không còn gate context; giữ protocol/run như lịch sử | Đã đồng bộ docs |
| Cập nhật theo đoạn và online | [core.forward](../src/scarx/neural/core.py#L131) | Vừa; reset mỗi episode khác stream state liên tục | Giữ học theo trải nghiệm; chưa đổi reset policy | Đã làm rõ, không đổi code |
| Học nhanh và retention | [plasticity._update](../src/scarx/neural/plasticity.py#L65) | Cao; có thể ổn định một mạng không học | Đo acquisition, hidden gain, retention và plasticity cùng nhau | Câu hỏi mở |
| SSD retrieval và kiến thức neural | [store.py](../src/scarx/memory/store.py), [text.py](../src/scarx/interfaces/text.py) | Cao nếu gán nhầm thành quả | Retrieval-off là điều kiện đo kỹ năng neural; semantic/procedural chưa có bằng chứng | Đã phân loại |
| Consolidation mới và replay/EMA cũ | [lifelong.py](../src/scarx/learning/lifelong.py) | Cao; periodic EMA chưa là offline skill learning | Tái sử dụng thành phần cũ, thêm điều phối/verification có kiểm chứng sau duyệt | Chưa triển khai |
| Gradient và local learning | [neural](../src/scarx/neural/), [controls](../src/scarx/evaluation/controls.py) | Không xung đột nếu tách đúng | Không backward toàn mạng trong core; kiểm toán mọi ứng viên | Giữ ràng buộc |
| RAM khi củng cố và rollback | [resources.py](../src/scarx/runtime/resources.py), [Windows limit](../src/scarx/runtime/limits.py) | Sampling không là hard cap | MVP áp per-processcommit2GB khi WindowsJob khả dụng, kiểmbatch/headroom; vẫn monitorRSS | Đã kiểm MVP; idleconsolidation tổng quát chưa mở |
| CPU-first và GPU nghiên cứu | [ADR0001](decisions/0001-research-boundaries.md) | Tương thích | CPU nghiệm thu; GPU nghiên cứu tùy chọn, đối chứng tách process | Giữ nguyên |
| Mở rộng và NO-GO | [06](research/06_FEASIBILITY_VERDICT.md), [08](research/08_PHASE21_RESULTS.md) | Cao nếu bỏ gate | Không tăng quy mô hoặc huấn luyện ngôn ngữ | Giữ nguyên |
| Checkpoint lõi mới và rollback API | [controller.rollback](../src/scarx/learning/controller.py), [Workbench](../src/scarx/app/state.py) | Gap cao trong audit1.0 | Đã thêm loader đúng loại và transaction learner/replay/RNG cho MVP, legacy data không sửa | Đã sửa/kiểm trong MVP; broader recovery UI còn hạn chế |
| Cờ verified và bằng chứng đúng | [MVP tasks](../src/scarx/app/tasks.py), [store](../src/scarx/memory/store.py) | Assertion không phải verifier | MVP kiểm nhãn bằng builtin-rule-v1; không tin riêng checkbox | Đã có verifier tác vụ; dữ kiện tự do chưa hỗ trợ |
| Kế hoạch phân tán | [README](../README.md), [PROJECT_MAP](PROJECT_MAP.md) | Vừa; nhiều trang có thể thành nguồn chỉ đạo khác nhau | File này là master; protocol bất biến chỉ ghi thí nghiệm đã đăng ký | Đã xử lý docs |
| Chưa có Git | [đề xuất quản lý phiên bản ở mục 8](#83-quản-lý-phiên-bản-và-dữ-liệu) | Vừa; không xác định được “uncommitted” | Đề xuất Git local, không khởi tạo/di chuyển trong lần này | Chờ duyệt triển khai riêng |

Không phát hiện xung đột mới buộc bỏ mục tiêu cốt lõi. Chính sách thu hồi kiến thức thật, dữ liệu riêng tư và scheduler là vấn đề mở trước triển khai thực tế; vòng synthetic không cần tự quyết những chính sách đó.

## 6. Learning Lifecycle

```mermaid
flowchart TD
  A[Observe: trải nghiệm và nguồn] --> B[Encode: tín hiệu hữu hạn]
  B --> C[Act: neural core và readout]
  C --> D[Feedback: kết quả và bằng chứng]
  D --> E{Nhãn đủ căn cứ?}
  E -->|Chưa| U[Chỉ lưu trải nghiệm chưa xác minh]
  E -->|Có| F[Snapshot rồi Local Update]
  F --> G[Verify trên development guard]
  G -->|Suy giảm hoặc lỗi| R[Rollback toàn trạng thái]
  G -->|Đạt| H[Commit bản học]
  H --> I[Consolidate có budget]
  I --> J[Verify retention và plasticity]
  J --> K[Recall và generalization test]
```

Đây là lifecycle đích, chưa được nối đầy đủ trong code. Các bước cụ thể:

1. **Observe:** lưu input, nguồn và kết quả gốc. SQLite có một phần metadata này; chưa tự biến text thành skill.
2. **Encode:** biến bài đã xác minh thành chuỗi số; giới hạn kích thước. Giữ hash/nguồn để truy vết, không nhét target vào kênh input.
3. **Act:** core tích lũy state, readout tạo đầu ra; weights không đổi giữa một lượt phục vụ.
4. **Feedback:** tách bằng chứng, nhãn và confidence. Với synthetic dùng quy luật kiểm được; với code tương lai dùng test phù hợp, không coi một unit test đơn lẻ chứng minh mọi hành vi đúng.
5. **Local Update:** chỉ sau đoạn và sau snapshot; synapse active thay đổi bằng rule đã duyệt. Trải nghiệm không đủ căn cứ không mặc định đi vào supervised replay.
6. **Verify:** guard phát triển tách khỏi train/test; kiểm old skills và khả năng học mới. Rollback giữ cả RNG, importance, replay và counters, không chỉ weights.
7. **Consolidate:** session riêng, bounded replay/local update; không nhất thiết được chạy nếu root-mechanism gate chưa đạt. Snapshot trước session và commit sau kiểm tra.
8. **Recall:** đo nhớ chính xác bằng `get(id)` ở kho dữ liệu; đo kỹ năng neural sau reset/restart và tắt retrieval. Công bố cả hai khi dùng cùng hệ thống.

Nếu guard từ chối hầu hết update, hệ có thể ổn định nhưng không học. Báo acceptance rate và new-skill gain; không dùng rollback để che forgetting trong benchmark thuật toán.

## 7. Experiment Roadmap

### 7.1 Phần đã hoàn tất và phạm vi mới

Phase2/2.1 giữ làm nền, không chạy lại để thay điểm. Từ phê duyệt Product-first, **mốc sản phẩm được ưu tiên**:

| Mốc | Cải thiện dùng trực tiếp | Trạng thái |
|---|---|---|
| V0.1 | Web local, dự đoán/dạy core thật, verifier tác vụ, before/after, A→B, SQLite/checkpoint/restore/restart, RAM/CPU | Đã triển khai; xem README/acceptance |
| V0.2 | Tác vụ/nhãn người dùng định nghĩa với verifier phù hợp, import/recovery và hướng dẫn dễ dùng hơn | Đề xuất vòng tiếp theo |
| V0.3 | Theo dõi nhiều kỹ năng lâu hơn, so bản rule trong UI, giữ model đang hoạt động khi thử bản mới | Đề xuất |
| V0.4+ | Rule/localrepresentation cải thiện có đối chứng trong sản phẩm; offline consolidation có ích nếu chứng minh được | Nghiên cứu kèm vòng build, không là điều kiện để có app |

**Steering Hermes/vision/actions:** người dùng chọn SCAR-X làm modelbackend OpenAI-compatible như cách cấu hình Qwen, không MCP; framework Python/NumPy/HTTPstdlib. Backend structuredJSON và streaming đã có, sampling tự chọn4hoặc16passes nhưng chưa phải learnedreasoning. Visionencoder, computer/toolpolicy và reasoning vẫn là năng lực cần phát triển; không khai báo đã có, không proxy Qwen để che. [capabilities.json](../capabilities.json) ghi trạng thái thật; [README mục8](../README.md#8-gói-thử-và-vai-trò-hermes) hướng dẫn kết nối.

Các P0–P5 dưới đây tiếp tục là **roadmap khoa học/engineering**, không là chuỗi gate chặn phát hành giao diện. MVP đã khép phần P0 cần thiết cho tác vụ có cấu trúc; không tự tuyên bố hoàn thành toàn bộ P0/P1–P5. Tối ưu replay không thay các vấn đề representation/credit/readout gốc. Thử tương tác và test sản phẩm được phép trong scope MVP; formal benchmark phải có protocol đã khóa.

### 7.2 Quy ước chung trước bất kỳ lần chạy mới nào

- Giữ H=48, K=8, R=12 và budget đầu vào/đầu ra tương đương đối chứng; mọi thay đổi topology cần đề xuất riêng.
- Dùng seed phát triển và tối thiểu 8 seed xác nhận **mới**, không dùng lại test đã xem để tune. Seed cụ thể, split, hash generator, số update, CPU time và endpoints phải khóa trong protocol trước lần chạy đầu.
- Test hidden bằng probe head mới với cùng thuật toán/budget; test hệ bằng readout triển khai thật. Không dùng ridge probe như thuật toán vận hành nếu chưa nói rõ.
- Tách attribution: initial/frozen hidden, readout-only, full local, modulation sai/ngẫu nhiên, không replay, không retrieval; dùng ablation một biến mỗi lần.
- Có control giải được bài để kiểm task validity; rule-based oracle chỉ kiểm dữ liệu, không tính là năng lực neural. BPTT chỉ đối chứng; muốn so thuật toán phải khớp forward/stochasticity hoặc công bố khác biệt.
- So cùng số update và một phép so cùng thời gian CPU; buffer bytes/tổng allocation đều báo. Không gọi cùng số mẫu là cùng compute. Không tăng budget sau khi mở final test.
- CI95% theo seed; contrast chính và hiệu chỉnh nhiều kiểm định đăng ký trước. Không lấy 303 trial ghép cặp như 303 seed độc lập.
- Mean forgetting ≤3 điểm phần trăm, worst ≤5 trên **mọi seed xác nhận**, cùng yêu cầu acquisition/final ≥65% đã dùng trong Phase 2.1. Không chấp nhận chance-level model dù không quên.
- Representation giữ tiêu chí cận dưới CI95% gain ≥5 điểm trên ít nhất 2/3 bài có hiệu lực, end-to-end ≥65%, lợi ích so readout-only dương và kiểm định đã hiệu chỉnh đạt. Bộ bài thay thế shortcut phải đăng ký trước; không chấm lại run cũ.
- Mỗi lần đo giới hạn 3 giờ, dừng khi vượt RAM, có NaN, lỗi persistence, rò rỉ test hoặc vi phạm signal locality. Tối đa hai vòng điều chỉnh đã đăng ký cho cùng giả thuyết; thiếu lợi ích đáng tin thì NO-GO cho rule đó, không tự mở tìm kiếm vô hạn.

### P0 — Khép an toàn kỹ thuật trước consolidation tự động

- **Mục tiêu / giả thuyết:** kiểm chứng transaction có thể phục hồi learner hoàn chỉnh trong budget; chưa nghiên cứu hiệu quả học.
- **Code liên quan:** [controller](../src/scarx/learning/controller.py), [PlasticCore persistence](../src/scarx/neural/plasticity.py), [LifelongLearner](../src/scarx/learning/lifelong.py), [replay](../src/scarx/learning/replay.py), [resource monitor](../src/scarx/runtime/resources.py), [EpisodeStore](../src/scarx/memory/store.py).
- **Dữ liệu:** fixtures nhỏ, checkpoint hai định dạng, nhãn có/không có evidence; lỗi có chủ đích khi ghi/tải/update.
- **Baseline:** tiếp tục chạy không bị ngắt và controller `SpikingCore` cũ; file lỗi phải bị từ chối.
- **Cách đo:** so weights/state/importance/counters/anchors/RNG/replay trước và sau resume; so chuỗi dự đoán và cập nhật tiếp theo; peak RAM khi save/load/rollback.
- **Pass/fail:** không trộn định dạng; rollback một transaction phục hồi toàn bộ phiên bản nhất quán; interrupted save không thay checkpoint đã commit; mọi đường lỗi đã đăng ký được kiểm; không dùng verified flag thay evidence; peak ≤2 GB và giới hạn batch/cấp phát có kiểm tra. Sampling chưa đủ để gọi là hard cap.
- **GO/PIVOT/NO-GO:** GO kỹ thuật mới cho phép nghiên cứu session consolidation; fail thì sửa persistence/budget, không tự động hóa. Không coi pass kỹ thuật là neural-learning GO.
- **Rủi ro / phụ thuộc:** snapshot nhiều file có thể lệch thế hệ, buffer/RNG có thể bị bỏ sót; snapshot chính cần bao gồm cả controller/verifier state phát sinh. Bắt đầu chỉ sau người dùng duyệt Phase 2.2. Đề xuất Git ở mục 8 cần duyệt riêng nếu chưa nằm trong phê duyệt triển khai.

### P1 — Representation và credit assignment

- **Mục tiêu / giả thuyết:** local update hidden tạo feature khái quát hóa tốt hơn initial hidden, không chỉ cho readout học lại; trace/reward cung cấp credit đúng thời điểm.
- **Code liên quan:** [core](../src/scarx/neural/core.py), [plasticity](../src/scarx/neural/plasticity.py), [tasks21](../src/scarx/evaluation/tasks21.py), [strict binding](../src/scarx/evaluation/binding_audit21.py), [controls](../src/scarx/evaluation/controls.py).
- **Dữ liệu:** thứ tự có cùng bag-of-events, binding không shortcut và bài quan hệ thứ ba được kiểm hiệu lực; tổ hợp/độ trễ/biểu diễn giữ kín. Không dùng nhiễu mới của cùng mẫu làm bằng chứng duy nhất cho kỹ năng mới.
- **Baseline:** frozen/initial hidden + cùng probe head, readout-only, full local hiện tại, scalar modulation đảo/ngẫu nhiên; control kiểm task learnability.
- **Cách đo:** refit head sau freeze hidden, trực tiếp end-to-end, transfer sang tổ hợp giữ kín; lesion temporal state, input/recurrent synapse reset riêng. Giữ common random numbers khi hợp lý, không cho test ảnh hưởng hidden.
- **Pass/fail:** gate representation ở mục 7.2; local signal audit không phát hiện backward toàn mạng. Nếu control cũng không học được hoặc bài có shortcut, đánh dấu thí nghiệm không đủ khả năng phân biệt, không kết luận rule bất khả thi.
- **GO/PIVOT/NO-GO:** đạt mới thử tích lũy skill; chỉ có weight drift/recall thì PIVOT rule hoặc thiết kế bài; hai vòng hợp lệ không có ích thì NO-GO cho rule đã thử.
- **Rủi ro / phụ thuộc:** reward scalar ít thông tin, trace dài nhiễu, feature không tách được quan hệ. Sau baseline/integrity của P0; không đợi tối ưu replay mới kiểm P1.

### P2 — Readout stability và importance theo mức hữu ích

- **Mục tiêu / giả thuyết:** bảo vệ kết nối thực sự hỗ trợ old skills giảm interference mà vẫn học được nhiệm vụ mới; tách drift ở head khỏi drift hidden.
- **Code liên quan:** [plasticity._update](../src/scarx/neural/plasticity.py#L65), [lifelong](../src/scarx/learning/lifelong.py), [audit21](../src/scarx/evaluation/audit21.py), [phase21 evaluator](../src/scarx/evaluation/phase21.py).
- **Dữ liệu:** nhiều context có quy luật quan sát được; stream không task ID, labels sạch trước rồi noise có kiểm soát. Phân biệt thay đổi thực tế với nhãn mâu thuẫn không thể phân giải.
- **Baseline:** head thường, importance theo magnitude hiện tại, periodic EMA, SI-readout adaptation, hidden frozen; replay giữ bằng nhau để không gán lợi ích của replay cho synapse rule.
- **Cách đo:** accuracy matrix, acquisition, final, max-to-final forgetting, signed BWT; đổi head/hidden snapshot riêng; thử bỏ protection và importance decay; ảnh hưởng của bảo vệ synapse lên học mới.
- **Pass/fail:** giữ gate mean ≤3/worst ≤5 điểm, acquisition/final đủ chất lượng. Muốn gọi cải thiện tương đối: cận dưới CI95% giảm forgetting ≥5 điểm và acquisition không kém reference quá3 điểm, cả equal-update và equal-time. Không lấy giảm variance hoặc giảm learning làm thành công.
- **GO/PIVOT/NO-GO:** đạt joint gate mới nối với P1; giữ được cũ nhưng không học mới thì PIVOT protection; không tạo lợi ích sau hai vòng hợp lệ thì NO-GO cho importance rule.
- **Rủi ro / phụ thuộc:** magnitude không phải usefulness, nhãn sai bị củng cố, bảo vệ quá mạnh đóng băng mạng. Sau P0; có thể thiết kế song song P1 nhưng không tuyên bố chung trước khi cả hai đạt.

### P3 — Chuyển nhiều trải nghiệm thành kỹ năng

- **Mục tiêu / giả thuyết:** trải nghiệm liên quan cải thiện khả năng áp dụng quy luật vào trường hợp giữ kín; lợi ích nằm trong neural weights.
- **Code liên quan:** [core/learning](../src/scarx/learning/), [EpisodeStore](../src/scarx/memory/store.py), [task generators](../src/scarx/evaluation/tasks21.py); bridge experience → lesson là phần đề xuất, chưa có file triển khai mới.
- **Dữ liệu:** họ tác vụ quan hệ chung một latent rule; tách exact episodes, tình huống gần, tổ hợp mới và domain biểu diễn mới. Trường hợp mới phải chứa đủ thông tin để giải, không dùng nhãn ngẫu nhiên độc lập rồi đòi suy ra quy luật.
- **Baseline:** no-learning, readout-only, same-budget repeat-new-data, bounded replay; có/không retrieval báo riêng. Dùng hidden reset/head refit để kiểm attribution.
- **Cách đo:** exact recall khác skill generalization, forward transfer và tiết kiệm số update để học kỹ năng liên quan. Reset state/restart, tắt retrieval khi chấm neural skill.
- **Pass/fail:** gate representation/quality và retention giữ nguyên; endpoint mới forward transfer hoặc generalization gain có cận dưới CI95% ≥5 điểm sẽ được đăng ký trước protocol mới, không áp hồi tố. Lợi ích phải tồn tại khi retrieval tắt, vượt readout-only theo contrast đã khóa.
- **GO/PIVOT/NO-GO:** qua thì cho nghiên cứu offline có đối chứng; chỉ cải thiện retrieval thì kết luận hệ memory có ích nhưng neural hypothesis chưa đạt; không vượt baseline thì PIVOT.
- **Rủi ro / phụ thuộc:** leakage, memorization, grouping bằng task ID bí mật, tự chấm nhãn sai. Phụ thuộc P1 và P2, cùng P0 đủ cho transactional update.

### P4 — Offline consolidation có đối chứng

- **Mục tiêu / giả thuyết:** phiên củng cố tạo retention/transfer thêm so với cùng compute đã dành cho local training; không thay P1–P3 bằng replay nhiều hơn.
- **Code liên quan:** [replay](../src/scarx/learning/replay.py), [controller](../src/scarx/learning/controller.py), [lifelong](../src/scarx/learning/lifelong.py), [store](../src/scarx/memory/store.py), [resources](../src/scarx/runtime/resources.py). Session controller và verifier là đề xuất mở rộng, không phải tính năng đã có.
- **Dữ liệu:** trải nghiệm có bằng chứng, tập nhãn sai/không rõ/mâu thuẫn để kiểm verifier; nguồn chất lượng không hoàn hảo, không oracle ẩn cho learner.
- **Baseline:** không session; cùng số update từ dữ liệu mới; replay thường; replay + protection. So equal-update và equal-time, cùng tổng buffer bytes; retrieval-off trong skill test.
- **Cách đo:** trước/sau consolidation về old skills, transfer, acquisition mới; tỷ lệ chọn mẫu đúng/sai, accepted updates, thời gian/điện năng chỉ khi đo được, peak RAM toàn transaction.
- **Pass/fail:** giữ gate retention/quality; gain skill/transfer mới cận dưới CI95% ≥5 điểm so với matched baseline là endpoint đề xuất phải đăng ký trước. Nếu không có gain thêm hoặc chỉ do thêm compute, không công nhận lợi ích consolidation đặc thù. Mọi lỗi budget/verification/persistence là fail kỹ thuật.
- **GO/PIVOT/NO-GO:** phiên thủ công đạt mới cân nhắc tự động khi rảnh với phê duyệt triển khai riêng; rollback liên tục hoặc protection chặn học thì PIVOT; không có lợi ích vượt baseline thì NO-GO cho session rule.
- **Rủi ro / phụ thuộc:** replay nhãn sai, confirmation loop, commit snapshot lệch, tranh CPU với công việc người dùng. P0 bắt buộc; P1–P3 phải có bằng chứng trước đánh giá claim Experience-to-Skill.

### P5 — Độ bền và capacity sau 20 → 50 → 100 giai đoạn

- **Mục tiêu / giả thuyết:** cơ chế giữ kỹ năng và plasticity trên stream dài hơn trong capacity cố định; không chỉ đạt một cửa sổ thuận lợi.
- **Code liên quan:** [lifelong evaluator](../src/scarx/evaluation/lifelong21.py), [replay](../src/scarx/learning/replay.py), [plasticity](../src/scarx/neural/plasticity.py), [resources](../src/scarx/runtime/resources.py).
- **Dữ liệu:** stream tái xuất hiện kỹ năng, drift dần, trải nghiệm hữu ích/nhiễu và probe nhiệm vụ liên quan mới. Evaluator biết thời điểm để đo; learner không nhận task boundary/ID bí mật.
- **Baseline:** fresh network cùng training budget cho mỗi probe, recurrent readout-only, local rule cũ và đối chứng continual learning đã kiểm khả năng tái lập. Phương pháp yêu cầu global backward chỉ nằm nhánh control.
- **Cách đo:** retention, signed transfer, sample-to-threshold, plasticity reserve và occupancy/importance/feature diversity, buffer/disk growth; can thiệp có/không selective forgetting với budget bằng nhau.
- **Pass/fail:** qua20 mới tới50, qua50 mới tới100; mean ≤3/worst ≤5 điểm từng seed, chất lượng ≥65%, không tăng capacity/RAM. Plasticity reserve mới: samples/updates để đạt ngưỡng không quá1,25 lần fresh baseline, chỉ dùng tỷ lệ khi fresh thực sự đạt ngưỡng; khóa trước lần chạy mới. Censored probes không được đổi thành pass.
- **GO/PIVOT/NO-GO:** pass cho nghiên cứu lâu hơn, không tự mở language/model lớn; fail do capacity thì nghiên cứu selective forgetting đã công bố trade-off, không xóa task khó khỏi metric; không còn học mới thì PIVOT cơ chế.
- **Rủi ro / phụ thuộc:** capacity hữu hạn, trade-off stability/plasticity và bài probe xung đột. Sau P1–P4 đạt các điều kiện tương ứng; 20/50/100 là độ dài thí nghiệm, không bảo đảm học vô hạn.

## 8. Hardware & Resource Budget

### 8.1 Thiết bị và số liệu đã đo

Thiết bị đã audit: i5-13500HX, khoảng32 GB RAM, Intel UHD, RTX4050 Laptop6 GB. Sử dụng thiết bị nghiên cứu mạnh hơn không thay đổi trần vận hành 2 GB.

| Run lịch sử | Peak RSS | Peak commit | Phạm vi |
|---|---:|---:|---|
| [Phase 2.1 chính](../runs/20261108T162931Z-phase21-v1-f3fa83/result.json) | 47,66 MB | 66,33 MB | Mạng nhỏ, NumPy CPU, có lịch thread của run |
| [Lifelong stream](../runs/20261108T163521Z-phase21-lifelong-v1-48ee0f/result.json) | 45,59 MB | 64,94 MB | 7 condition, không iGPU |
| [Strict binding](../runs/20261108T170757Z-phase21-binding-audit-v1-a64369/result.json) | 42,78 MB | 61,67 MB | Audit task ở mạng nhỏ |
| [BPTT control](../runs/20261108T170812Z-phase21-bptt-control-v1-2d0010/result.json) | 630,18 MB | 1.050,95 MB | Process control riêng, có PyTorch |

RSS là trang đang resident; commit là bộ nhớ đã cam kết. Không cộng chúng như hai vùng độc lập. Số đo khác môi trường thư viện/thread có thể khác nhiều; không chứng nhận mọi workload dưới2 GB. Sampling có thể bỏ sót đỉnh ngắn; không suy ra bytes đã swap từ pagefile-commit.

### 8.2 Ước tính thành phần và budget đề xuất

Ước tính dưới đây từ kích thước tensor, **không phải benchmark mới**. Với D=8,H=48,K=8,R=12,O=2, float32/int32:

- Current weights+bias:866 float =3.464 byte; stable copy cùng kích thước.
- Importance:3.464 byte; recurrent indices1.536 byte; active rows48 byte.
- Voltage/adaptation/spikes/post/features, pre/voltage traces và eligibility: khoảng2.176 byte. Tổng arrays `PlasticCore` khoảng14.152 byte, chưa tính object/allocator/runtime.
- Eligibility active riêng: R(D+K)×4 =768 byte. Không nhầm state phụ này với tổng memory model.
- Replay128×12×8 float cùng label/context:50.176 byte; stress D=24 dùng148.480 byte.
- SI readout work/omega/anchor:1.176 byte trong cấu hình binary này. Byte demo hoặc dimensions khác phải tính lại.
- SQLite page cache đã đặt8 MiB; file SSD, FTS index và RAM cache phải báo riêng. Chưa có semantic/procedural bank neural riêng đã được xác nhận.

Budget dưới đây là **trần thiết kế đề xuất** cho prototype, không cấp phát sẵn và không là lý do tăng model:

| Nhóm | Budget byte |
|---|---:|
| Core/state/weights/eligibility/importance | 16.000.000 |
| Replay trong RAM | 16.000.000 |
| Fixtures và batch đánh giá | 64.000.000 |
| Episodic cache và đọc dữ liệu | 32.000.000 |
| Buffer consolidation | 32.000.000 |
| Bản sao thêm để snapshot/load/rollback | 64.000.000 |
| Runtime, thư viện, logging, tiến trình phụ trong cùng job | 1.024.000.000 |
| Dự phòng cho đỉnh cấp phát | 752.000.000 |
| **Tổng** | **2.000.000.000** |

Không chạy main và heavy control đồng thời để né số đo tổng. Protocol phải giới hạn CPU threads, số update và thời gian; một run tối đa3h. Phiên offline đầu đề xuất tối đa30s CPU wall time/128 replay experiences, cùng ngân sách cho control, chỉ thực hiện sau duyệt; nếu pilot không đủ ngân sách thì đăng ký protocol khác trước test, không tự kéo dài.

Trước session cần tính bản sao/batch/serializer và rollbackheadroom. MVP kiểm batch/cấp phát, timeout và monitor; WindowsJob áp cap committedmemory của process2GB khi attach thành công, không đổi pagefile/policy toàn máy. Shared pages/RSS và trường hợp Job không khả dụng vẫn được báo riêng; không gọi đó là cap toàn bộ browser/OS. Budget cho automaticconsolidation tổng quát và hủy phiên vẫn phải kiểm trước tự động hóa.

### 8.3 Quản lý phiên bản và dữ liệu

Hiện chưa có Git trong project. **Đề xuất, chưa thực hiện:** khởi tạo Git local ngay tại thư mục SCAR-X, không di chuyển/đổi cấu trúc; baseline commit sau kiểm danh sách tệp. Theo dõi code/docs/configs/protocol/tests; không tự add dữ liệu `local/`, binary build, credentials hoặc checkpoint/database lớn. Review ignore trước lần add đầu, không dùng blanket add mà chưa kiểm.

Run ID, manifest, hashes và source snapshot tiếp tục là nguồn provenance của kết quả; một commit không thay thế dữ liệu raw. Nếu cần chuyển binary ra artifact store phải đề xuất riêng, không di chuyển run cũ trong lần này. Chưa có remote/push. Nếu chưa dùng Git, tiếp tục snapshot có checksum và nhãn phiên bản, không giả định biết “uncommitted changes”. Cần duyệt thao tác Git riêng trước khi thực hiện.

Dữ liệu gốc không tự xóa/ghi đè khi selective forgetting neural. Policy retention của SSD và dữ liệu cá nhân còn mở; fixtures synthetic không mở rộng tự động. Budget replay hữu hạn không đồng nghĩa giữ nguyên vô hạn trải nghiệm trong RAM hoặc SSD.

## 9. Learning & Memory Metrics

Không dùng một điểm tổng hợp thay toàn bộ bảng đo. [Metric specification](research/04_ACI_CEI_METRICS.md) định nghĩa chi tiết; ACI/CEI cũ chỉ còn là thảo luận lịch sử, chưa có điểm được công bố.

| Chỉ số | Định nghĩa/cách đo | Tránh diễn giải sai |
|---|---|---|
| Learning speed | Mẫu, update và CPU seconds tới ngưỡng chất lượng, kèm learning curve | Trường hợp không tới ngưỡng phải báo censored/fail, không ghi thời gian0 |
| Retention/forgetting | Max accuracy sau khi kỹ năng đã học trừ accuracy cuối; báo mean/worst từng seed | Đóng băng hoặc không học không được tính thắng |
| Backward transfer | Accuracy cuối kỹ năng cũ trừ accuracy ngay sau lúc học nó; có dấu | Không trộn signed BWT với max-to-final forgetting |
| Forward transfer | So chưa học/học ít task mới với fresh baseline trên cùng task/budget | Chỉ có cùng ví dụ không chứng minh chuyển giao |
| Generalization | Hiệu năng trên tổ hợp/quy luật ứng dụng giữ kín, phân biệt gần/xa | Test noise mới và literal retrieval chưa đủ |
| Hidden contribution | Learned hidden → probe head mới, so initial/frozen/readout-only và modulation control | Weight drift, spike activity hoặc head cũ giỏi không đủ |
| Plasticity reserve | Khả năng học task mới sau tuổi stream; samples-to-threshold so fresh; feature rank chỉ phụ trợ | Một probe đảo nhãn hoặc variance giảm không chứng minh giữ plasticity |
| Memory reconstruction | Exact bytes/source/hash ở episodic; chi tiết hoặc quan hệ được neural recall đúng khi retrieval tắt | Không gộp exact SSD retrieval vào neural memory score |
| Learning efficiency | Correct novel/retained skills dưới cùng update/time/RAM; CPU time, peak memory và data/I/O báo riêng | Không suy joule từ FLOPs; chỉ báo energy khi đo được |
| Verification/selection | Precision của nhãn được chấp nhận, noise retained, false rejection và acceptance rate | `verified=true` không phải phép đo chân lý |
| Consolidation benefit | Chênh lệch trước/sau session so matched extra-training/replay controls | Thêm compute hay chỉ nhớ mẫu cũ chưa chứng minh skill consolidation |

Guard phát triển và final test tách riêng. Cửa sổ đánh giá có thể do evaluator biết, không phát task IDs cho learner. Benchmark dùng raw updates để thấy thuật toán quên; đường vận hành có rollback phải báo cả việc từ chối học.

## 10. Risks and Open Questions

1. **Capacity:** hữu hạn synapse/state không giữ chính xác vô hạn ánh xạ độc lập; giữ kỹ năng cũ và thay kiến thức lỗi thời cần trade-off được công bố.
2. **Credit assignment:** scalar reward yếu/nhiễu; trace quá dài tăng variance, quá ngắn mất liên hệ nhân quả. Không âm thầm thêm global feedback rồi vẫn gọi thuần local.
3. **Representation:** core có thể không tạo đủ feature cho quan hệ; readout/probe giỏi không đảm bảo hidden học mới. Chưa biết rule nào vượt baseline trong budget.
4. **Readout interference:** head dùng chung bị cập nhật mới kéo lệch; head riêng theo task có thể che vấn đề và đòi task ID. Không tự thêm head không giới hạn.
5. **Metaplasticity:** bảo vệ activity lớn có thể bảo vệ nhiễu; importance chỉ tăng có thể mất plasticity; decay có thể làm quên. Cần usefulness ablation.
6. **Consolidation:** có thể chỉ ôn tập hoặc tăng compute, chưa tạo generalization. Session tự động trước verification/rollback là chưa đủ điều kiện.
7. **Data quality:** feedback có thể sai, có thay đổi thật hoặc mâu thuẫn; confidence không thay evidence. Learning không giám sát cấu trúc dữ liệu khác việc chấp nhận dữ kiện là đúng.
8. **Task validity:** shortcut, bài quá dễ/quá khó, rò rỉ target, chấm nhiều lần chọn đỉnh và ít seed làm sai kết luận.
9. **Reproducibility:** RNG/buffer/controller state hoặc snapshot nhiều file lệch phiên bản có thể phá rollback; chưa có Git và chưa có transaction tích hợp cho lõi mới.
10. **Resource:** sampling không là hard cap; snapshot/serializer/SQLite/process con có thể tăng peak. Không dùng SSD paging trọng số để tạo số RAM thấp giả tạo.
11. **Novelty và baseline:** SNN + replay + EMA chưa là kiến trúc mới. Chưa tái lập MESU/BNN metaplasticity/Continual Backprop đầy đủ trong cùng benchmark; không khẳng định vượt phương pháp chưa chạy.
12. **Biological analogy:** ALIF, reward và stable weights chỉ mô hình hóa một số ý tưởng; không bảo đảm giống não hoặc thông minh như người.

Xem [landscape](research/01_RESEARCH_LANDSCAPE.md), [critical review](research/03_CRITICAL_REVIEW.md) và [lifelong limits](research/07_LIFELONG_LIMITS.md). Các paper là cơ sở đặt giả thuyết, không thay bằng chứng SCAR-X. Nếu phát hiện conflict làm đổi tín hiệu học cho phép, budget, mục tiêu hoặc ngưỡng, dừng và hỏi người dùng trước.

## 11. Implementation Checklist

Checklist research chưa tích không chặn việc dùng MVP. Việc phát triển sản phẩm trong scope người dùng phê duyệt được tiếp tục; thay đổi ngoài scope/ràng buộc phải trình bày trước.

- [x] Đối chiếu audit, code, Phase 2/2.1 và quyết định lịch sử; chỉ định master plan duy nhất.
- [x] Đưa representation, credit assignment và readout stability lên trước optimization replay/consolidation.
- [x] Phân biệt kiến trúc đã có, giả thuyết, memory phụ trợ và các điều kiện nghiệm thu.
- [x] Người dùng duyệt Product-first/MVP V0.1, code/UI/sửa tích hợp và acceptance tests.
- [x] MVP dùng PlasticCore thật, dạy A/B, lưu/resume/restore full session, feedback verifier tác vụ, resource display và Windows process cap khi khả dụng.
- [ ] Protocol nghiên cứu mới cho các claim Phase2.2, tách khỏi thao tác dạy tương tác sản phẩm.
- [ ] **P0:** loader/transaction đúng định dạng, snapshot toàn state và replay/RNG, fault injection, giới hạn RAM, verification evidence; nghiệm thu trước automatic consolidation.
- [ ] **P1:** kiểm task validity, data split/seed mới, local signal audit, hidden/probe/readout/modulation ablation; đạt representation gate mới công nhận học hidden hữu ích.
- [ ] **P2:** can thiệp readout/hidden, usefulness importance, new-learning-vs-retention; đạt joint gate thay vì chỉ giảm forgetting.
- [ ] **P3:** giữ kín tình huống áp dụng quy luật, tắt retrieval/reset/restart; kiểm transfer vượt matched baseline.
- [ ] **P4:** phiên offline thủ công có snapshot, budget, verifier/guard và rollback; kiểm benefit ngoài thêm compute.
- [ ] **P5:** độ dài20 rồi50 rồi100 với capacity cố định, plasticity reserve so fresh và tiêu chí dừng đã khóa.
- [ ] Duyệt riêng nếu muốn Git local, chạy nền khi rảnh, quản lý dữ liệu thật hoặc tăng quy mô. Không tự làm các bước đó từ phê duyệt docs.

## 12. Decision Log

| Quyết định | Căn cứ | Hệ quả |
|---|---|---|
| Giữ SNN/local learning/CPU/2 GB | Chỉ đạo người dùng và [ADR0001](decisions/0001-research-boundaries.md) | Memory hoặc LLM không thay lõi nghiên cứu |
| Bỏ context length làm mục tiêu | [ADR0002](decisions/0002-lifelong-adaptive-intelligence.md) | Run context cũ giữ như lịch sử |
| Không dùng binding shortcut làm thành công | [ADR0003](decisions/0003-phase21-evaluation-audit.md) | Strict binding mới, kết quả cũ không sửa |
| PIVOT_NO_SCALE | [06](research/06_FEASIBILITY_VERDICT.md), [08](research/08_PHASE21_RESULTS.md) | Chưa tăng tham số hoặc mở language training |
| Master plan tại file này | Người dùng phê duyệt cập nhật docs ngày2026-11-09 | Protocol bất biến không thành nguồn roadmap cạnh tranh |
| Ưu tiên nguyên nhân gốc | Chỉ đạo bổ sung sau audit | P1/P2 không bị thay bằng replay/consolidation-only |
| Checkpoint/verifier/RAM là prerequisite | Audit tích hợp và yêu cầu người dùng | Chưa triển khai automatic consolidation |
| Docs-only trước đây | [ADR0004](decisions/0004-master-plan-and-phase22-docs.md) | Là phạm vi lịch sử, không sửa lại ADR |
| Product-first/MVP đã được duyệt | [ADR0005](decisions/0005-product-first-mvp.md) | Build app ngay bằng core hiện có, không dùng researchgate để chặn MVP; không tăng quy mô |

## 13. Change Log

### 1.1 — 2026-11-09 — Product-first

- Thay workflow bằng Build/Run/Interact/Learn/Test/Improve; V0.1 local app được phê duyệt và triển khai.
- Cho phép bản thử nghiệm yếu dù researchgate fail; giữ nguyên kết quả và threshold lịch sử, không gọi sản phẩm là solvedcontinuallearning.
- Sửa integration/persistence cho MVP, verifier builtinrule, resource cap/monitor; không thay ALIF/localrule/topology.
- README là hướng dẫn vận hành duy nhất; master giữ roadmap; ADR0005 ghi scope mới. Git/scheduler/model lớn vẫn chưa được thực hiện.

### 1.0 — 2026-11-09

- **Thêm:** master plan13 mục; phân tích topology/signal paths, phân công Experience-to-Skill, conflict matrix, lifecycle, roadmap Phase2.2 có dependency/gates, resource budget và checklist.
- **Cập nhật:** tài liệu kiến trúc để có cả Phase2 và2.1; metrics và experiment-design để dẫn về master, thêm attribution/transfer/plasticity và đánh dấu phạm vi lịch sử.
- **Đồng bộ:** README, PROJECT_MAP, STATUS; thêm ADR0004 để ghi phạm vi phê duyệt.
- **Giữ nguyên:** source code, thuật toán, tests, scripts, configs, protocol, run data, báo cáo kết quả06/08 và quyết định0001–0003; không phát sinh số benchmark.
- **Deprecated với vai trò mục tiêu hiện hành:** 1M context/length ladder và số tham số làm thước đo trung tâm. Không xóa dữ liệu, không gọi giới hạn context kỹ thuật là không còn tồn tại.
- **Chưa được duyệt triển khai:** mọi stage P0–P5, thuật toán/topology mới, scheduler, Git init/push hoặc dịch chuyển cấu trúc dự án. Mọi thay đổi phát hiện conflict nghiêm trọng mới phải hỏi trước.
