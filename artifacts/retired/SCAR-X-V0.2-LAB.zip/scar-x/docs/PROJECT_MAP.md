# Bản đồ dự án SCAR-X

Điểm vào: [README](../README.md) → [RESEARCH_PLAN — master plan duy nhất](RESEARCH_PLAN.md) → [trạng thái](STATUS.md) → [kết quả Phase 2.1](research/08_PHASE21_RESULTS.md). [Phase 2](research/06_FEASIBILITY_VERDICT.md) là hồ sơ lịch sử.

**Sản phẩm hiện tại:** [run_app.py](../run_app.py) → [app/server.py](../src/scarx/app/server.py) → [app/state.py](../src/scarx/app/state.py) → PlasticCore/LifelongLearner. Frontend ở [app/web](../src/scarx/app/web/); data-dir mặc định `local/mvp`. [ADR0005](decisions/0005-product-first-mvp.md) thay scope docs-only bằng Product-firstMVP; research gates không chặn bản thử nghiệm.

**V0.2LAB:** [neural/language.py](../src/scarx/neural/language.py) là autoregressiveALIF; [app/pilots.py](../src/scarx/app/pilots.py) điều phối checkpoint/teaching/ảnh; [pilot-release.json](../artifacts/pilot-release.json) trỏ trọng số phát hành. [README mục9](../README.md#9-v02-lab-ngôn-ngữ-và-thị-giác-đã-huấn-luyện) hướng dẫn trạng thái experimental. Languagequalitygatefalse, digits-onlyvision; không thay coreV0.1 hoặc thêmLLMproxy.

Roadmap/vision/gate nằm trong master. Architecture/metrics/design là tham chiếu; protocol nghiên cứu đã chạy không sửa thành roadmap cạnh tranh. Formal Phase2.2 còn là đề xuất, nhưng Product-firstMVP/code/UI và acceptance checks đã được phê duyệt; gate nghiên cứu không chặn tương tác/dạy thử.

| Thư mục | Nội dung | Quy tắc |
|---|---|---|
| `src/scarx/neural/` | ALIF, STDP, checkpoint | Không backprop; không truy xuất dữ liệu |
| `src/scarx/learning/` | Cập nhật có kiểm tra, replay, rollback | Phân biệt huấn luyện và đánh giá |
| `src/scarx/memory/` | SQLite, nguồn, truy xuất | Dữ liệu gốc trên đĩa, cache giới hạn |
| `src/scarx/runtime/` | C++ bridge, RAM monitor | Tách số đo khỏi ước tính |
| `src/scarx/evaluation/` | Bài thử, baseline, thống kê, báo cáo | Control backprop chỉ nằm ở đây |
| `src/scarx/interfaces/` | API văn bản, CLI | Không tự gọi cloud |
| `src/scarx/app/` | MVP localhost, task encoder, transaction và web UI | Prediction neural, rule verifier và memory phải phân biệt |
| `native/` | Mã C++ và cách build | Binary sinh ra nằm trong build/ |
| `configs/` | Cấu hình tái lập | Có version; lưu bản sao trong mỗi run |
| `experiments/` | Protocol đăng ký trước | Tên cố định, không sửa sau khi chạy |
| `data/fixtures/` | Dữ liệu nhỏ dùng kiểm thử | Có nguồn gốc; không chứa bí mật |
| `runs/<run-id>/` | Kết quả, log, metadata từng lần chạy | Không ghi đè; tra bằng runs/INDEX.md |
| `artifacts/` | Checkpoint và hồ sơ nguồn gốc | Tách model khỏi mã nguồn |
| `docs/RESEARCH_PLAN.md` | Kế hoạch nghiên cứu chính duy nhất | Tách đã triển khai/đề xuất; cập nhật theo phê duyệt |
| `docs/research/` | Kiến trúc, metrics và báo cáo nghiên cứu | Kết quả dẫn đến run; không sửa số liệu lịch sử |
| `docs/decisions/` | Nhật ký quyết định thiết kế | Có lý do và phương án bị loại |
| `tests/` | Kiểm thử hành vi, persistence, parity | Không thay cho benchmark năng lực |
| `scripts/` | Build, tái lập, thống kê | Chạy từ project root |
| `local/` | Dữ liệu cá nhân, cache thử nghiệm | Git-ignore; không tự công bố |

## Tìm nhanh

```powershell
rg --files src tests docs configs experiments
rg "elig_rec|modulation" src/scarx/neural
rg "gate|forgetting" runs --glob '*.json'
rg "NO-GO|PIVOT|GO" docs/research
```

Tên run: thời gian UTC + protocol + hậu tố ngẫu nhiên. `result.json` là dữ liệu máy đọc; `report.md` là tóm tắt cho người. `manifest.json` ghi seed, cấu hình, phiên bản môi trường, hash mã nguồn. Không dùng tên như `final2`, `new`, `test_latest` làm nguồn kết quả chính thức.

## Tìm cơ chế Phase 2.1

- `src/scarx/neural/plasticity.py`: stochastic ALIF, eligibility và importance, checkpoint/RNG.
- `src/scarx/learning/lifelong.py`: consolidation theo đồng hồ cập nhật, SI control tại readout.
- `src/scarx/learning/replay.py`: replay buffer có capacity cố định và RNG lưu được.
- `src/scarx/evaluation/phase21.py`: development selection, confirmation, thống kê.
- `src/scarx/evaluation/lifelong21.py`: stream không task ID, phản hồi nhiễu, selective learning.
- `artifacts/phase21-summary.json`: đường dẫn chính xác tới các run được trích trong báo cáo; các file hình nằm tại `artifacts/phase21-figures/`.

## Điểm mở và Phase 2.2 đề xuất

- [P0 kỹ thuật](RESEARCH_PLAN.md#p0--khép-an-toàn-kỹ-thuật-trước-consolidation-tự-động): `plasticity-v1`, whole-learner/replay rollback, evidence verification và peak RAM.
- [P1 representation/credit](RESEARCH_PLAN.md#p1--representation-và-credit-assignment) và [P2 readout/importance](RESEARCH_PLAN.md#p2--readout-stability-và-importance-theo-mức-hữu-ích) là ưu tiên nguyên nhân gốc.
- [P3–P5](RESEARCH_PLAN.md#p3--chuyển-nhiều-trải-nghiệm-thành-kỹ-năng): transfer, offline consolidation và tuổi stream; mở theo dependency/gate.
- [ADR0004](decisions/0004-master-plan-and-phase22-docs.md) ghi phạm vi docs-only. Không có Git local được khởi tạo, không di chuyển cấu trúc từ cập nhật này.
