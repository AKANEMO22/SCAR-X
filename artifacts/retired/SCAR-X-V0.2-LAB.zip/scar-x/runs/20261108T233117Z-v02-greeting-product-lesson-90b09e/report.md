# Explicit greeting product lesson

{
  "before": {
    "text": "Chào bạn, tôi là scar-x, tôi là scar-x.",
    "tokens": [
      "chào",
      "bạn",
      ",",
      "tôi",
      "là",
      "scar-x",
      ",",
      "tôi",
      "là",
      "scar-x",
      "."
    ],
    "stopped": true,
    "mean_probability": 0.6808284955720106,
    "source": "autoregressive learned ALIF readout; no answer retrieval",
    "scope": "small-vocabulary conversational pilot"
  },
  "after": {
    "text": "Chào bạn, tôi là scar-x.",
    "tokens": [
      "chào",
      "bạn",
      ",",
      "tôi",
      "là",
      "scar-x",
      "."
    ],
    "stopped": true,
    "mean_probability": 0.7894630804657936,
    "source": "autoregressive learned ALIF readout; no answer retrieval",
    "scope": "small-vocabulary conversational pilot"
  },
  "weights_changed": true,
  "restart_equal": true,
  "training_point_only": true,
  "quality_gate_passed": false,
  "checkpoint": "artifacts/pilots/20261108T233117Z-v02-greeting-product-lesson-90b09e/language"
}

This is a directly trained example, not an unseen-prompt/general-chat result.
