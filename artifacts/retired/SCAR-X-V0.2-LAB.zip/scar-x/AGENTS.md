# SCAR-X working rules

- Load ponytail rules/tools/context first when available. Record unavailability honestly.
- Keep all SCAR-X changes inside this project; the parent contains unrelated font work.
- Start at README.md, then docs/PROJECT_MAP.md and docs/STATUS.md.
- Production neural code in src/scarx/neural must not import torch/autograd or use backward gradients.
- Backprop controls live only in src/scarx/evaluation/controls.py and run as separate experiments.
- Register protocol and seeds before formal research benchmarks; never select a winner on final test data. Product-first MVP development and normal interactive teaching are authorized without research gates; record acceptance scenarios and limits honestly.
- Results go under runs/<unique-run-id>; do not rewrite previous run results.
- Trained checkpoints go in artifacts/, source fixtures in data/fixtures, user data in local/.
- Update docs/STATUS.md after a milestone; report failures and unmeasured claims.
- Do not expand to language pretraining or bigger models when the preceding gate has failed.
- Product entrypoint: run_app.py and README.md. Master plan: docs/RESEARCH_PLAN.md. Preserve historical research protocols/results; research gates do not block building a weak but real local MVP.
- Run pytest and CPU/native parity tests for neural/runtime changes.

