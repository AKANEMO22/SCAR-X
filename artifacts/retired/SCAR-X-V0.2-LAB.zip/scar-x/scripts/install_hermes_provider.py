"""Add a named local provider without replacing Hermes' current Qwen model.

Never print secrets or reserialize unrelated settings. A private byte-for-byte
backup is saved beside Hermes' own backups before an atomic config replacement.
"""
import argparse
from datetime import datetime,timezone
import json
import os
from pathlib import Path
import tempfile
import yaml

root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--config',type=Path,default=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.local')))/'hermes/config.yaml')
args=parser.parse_args(); path=args.config
snippet=(root/'integrations/hermes/provider.yaml').read_text(encoding='utf-8')
addition=yaml.safe_load(snippet)['providers']
original=path.read_bytes(); text=original.decode('utf-8-sig'); config=yaml.safe_load(text) or {}
if not isinstance(config,dict): raise SystemExit('Hermes config is not a mapping; no changes made.')
existing=config.get('providers')
if isinstance(existing,dict) and existing.get('scarx-local')==addition['scarx-local']:
    print(json.dumps({'already_configured':True,'provider':'scarx-local','current_model_unchanged':True})); raise SystemExit(0)
if 'providers' in config:
    raise SystemExit('Existing providers block: merge integrations/hermes/provider.yaml manually. No settings were overwritten.')
updated=text.rstrip()+'\n\n# SCAR-X named local backend; existing Qwen remains selected.\n'+snippet+'\n'
parsed=yaml.safe_load(updated)
assert {k:v for k,v in parsed.items() if k!='providers'}==config
assert parsed['providers']==addition
if path.read_bytes()!=original: raise SystemExit('Hermes config changed during preparation; no changes made.')
backup_dir=path.parent/'backups'; backup_dir.mkdir(exist_ok=True)
backup=backup_dir/('config-before-scarx-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.yaml')
backup.write_bytes(original)
encoding='utf-8-sig' if original.startswith(b'\xef\xbb\xbf') else 'utf-8'
fd,tmp=tempfile.mkstemp(dir=path.parent,suffix='.scarx.tmp')
try:
    with os.fdopen(fd,'wb') as stream:
        stream.write(updated.encode(encoding)); stream.flush(); os.fsync(stream.fileno())
    if path.read_bytes()!=original: raise RuntimeError('Hermes config changed before commit; no replacement performed.')
    os.replace(tmp,path)
finally:
    if os.path.exists(tmp): os.unlink(tmp)
assert yaml.safe_load(path.read_text(encoding='utf-8-sig'))==parsed
print(json.dumps({'installed_provider':'scarx-local','api':'http://127.0.0.1:8765/v1','model':'scarx-signal-v0.1',
                  'current_model_unchanged':parsed.get('model')==config.get('model'),'backup':str(backup)},indent=2))
