"""Add explicit experimental model entries; do not select them automatically."""
from pathlib import Path
from datetime import datetime,timezone
import copy
import json
import os
import tempfile
import yaml

root=Path(__file__).resolve().parents[1]
path=Path(os.environ['LOCALAPPDATA'])/'hermes/config.yaml'
original=path.read_bytes();text=original.decode('utf-8-sig');current=yaml.safe_load(text)
expected=copy.deepcopy(current)
if not isinstance(expected.get('providers'),dict) or 'scarx-local' not in expected['providers']:
    raise SystemExit('Install the SCAR-X named provider first; no settings changed.')
snippet=yaml.safe_load((root/'integrations/hermes/provider.yaml').read_text(encoding='utf-8'))
entry=expected['providers']['scarx-local'];entry.setdefault('models',{}).update(snippet['providers']['scarx-local']['models'])
assert {k:v for k,v in expected.items() if k!='providers'}=={k:v for k,v in current.items() if k!='providers'}
document=yaml.compose(text);pairs=document.value
index=next(i for i,(key,_) in enumerate(pairs) if key.value=='providers')
start=text.rfind('\n',0,pairs[index][0].start_mark.index)+1
end=text.rfind('\n',0,pairs[index+1][0].start_mark.index)+1 if index+1<len(pairs) else len(text)
block=yaml.safe_dump({'providers':expected['providers']},sort_keys=False,allow_unicode=True)
updated=text[:start]+block+'\n'+text[end:]
assert yaml.safe_load(updated)==expected
if expected==current:
    print(json.dumps({'already_configured':True,'models':list(entry['models']),'selected_model_unchanged':True}));raise SystemExit(0)
backup=path.parent/'backups'/('config-before-scarx-pilots-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.yaml')
backup.parent.mkdir(exist_ok=True);backup.write_bytes(original)
fd,tmp=tempfile.mkstemp(dir=path.parent,suffix='.scarx.tmp')
try:
    with os.fdopen(fd,'wb') as stream:stream.write(updated.encode('utf-8'));stream.flush();os.fsync(stream.fileno())
    if path.read_bytes()!=original:raise RuntimeError('Config changed concurrently; no replacement performed')
    os.replace(tmp,path)
finally:
    if os.path.exists(tmp):os.unlink(tmp)
print(json.dumps({'models_added':['scarx-language-lab-v0.2','scarx-digits-lab-v0.2'],'selected_model_unchanged':True,
                  'llamacpp_autostart_enabled':(expected.get('local_runtime') or {}).get('enabled'),'backup':str(backup)},indent=2))
