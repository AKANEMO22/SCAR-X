# SCAR-X · Neural Workbench V0.1

Ứng dụng AI thử nghiệm chạy **local trên Windows**, dùng lõi ALIF recurrent và local synaptic learning thật. Bạn có thể đưa tín hiệu, dạy nhãn, quan sát synapse thay đổi, thử học A rồi B và quay lại checkpoint.

**Chưa phải chatbot hiểu ngôn ngữ tự nhiên.** V0.1 học hai tác vụ tín hiệu có cấu trúc; không gọi cloud/API trả phí, không dùng LLM pretrained. Research forgetting/representation gate vẫn chưa đạt.

## 1. Cài và chạy

Cần Python3.11+ (64-bit). Mở PowerShell:

```powershell
cd 'C:\Users\hachimi\Downloads\model agent\scar-x'
python -m pip install -e .
python run_app.py
```

Mở **[http://127.0.0.1:8765](http://127.0.0.1:8765)**. Giữ terminal chạy, `Ctrl+C` để dừng. Không cần compiler, Node.js, PyTorch hoặc tải model cho ứng dụng. Dependencies runtime chỉ có NumPy và psutil. Launcher đặt thư viện số dùng một thread trước khi import.

Nếu phiên được Codex mở sẵn ở nền, có thể dừng bằng `powershell -File .\Stop-SCARX.ps1`; script xác minh process thuộc checkout này trước khi dừng. Nếu policy không cho script, mở terminal của phiên đó và `Ctrl+C`, hoặc dừng đúng process SCAR-X bằng TaskManager. Dữ liệu đã commit vẫn giữ.

Cũng có thể chạy `.\Start-SCARX.ps1` nếu policy hiện tại cho phép script local. Nếu không, dùng lệnh Python phía trên; không cần đổi execution policy toàn máy.

Tùy chọn port hoặc thư mục dữ liệu riêng:

```powershell
python run_app.py --port 8766 --data-dir local/my-session
```

Đường dẫn tương đối được tính từ project. Nếu port đang được dùng, dừng phiên SCAR-X cũ hoặc chọn port khác; không tự thay thế process của ứng dụng khác. Phiên mới chỉ khởi tạo khi data-dir chưa có state, không ghi đè model cũ.

Mỗi data-dir chỉ cho một process ghi để tránh hai cửa sổ học đè lên state của nhau. Có thể mở nhiều browser tab của cùng server. Muốn hai server độc lập phải dùng hai data-dir khác nhau; OS lock tự nhả khi process dừng.

## 2. Dạy một ví dụ

Ở **Thử & dạy**:

1. Chọn tác vụ A hoặc B và tín hiệu0–3.
2. Bấm **Cho SCAR-X dự đoán**. Nhãn và xác suất lấy từ `PlasticCore`; nhãn đối chiếu theo quy tắc được ghi riêng.
3. Chọn nhãn đúng, xác nhận và bấm **Dạy ví dụ này**. Server kiểm nhãn theo rule đã công bố, không chỉ tin checkbox.
4. Xem điểm A/B trước/sau và `ΔW input/recurrent/readout`. Thử lại hoặc bấm **Biến thể mới** để đổi noise seed.

TaskA:0/1→0,2/3→1. TaskB:0/2→0,1/3→1. Có task cue quan sát được trong input; target không được đưa vào encoder. Không thể dạy câu hỏi tự do hoặc tự đặt một quy tắc khác trong V0.1. Nhãn trái quy tắc sẽ bị từ chối trước update.

Một ví dụ được lặp32update, nên có thể gây overfit hoặc làm suy giảm nhãn khác. Trọng số hidden thay đổi **chưa chứng minh** hidden học representation tốt hơn; readout cũng học. Các giới hạn này được hiển thị trong ứng dụng.

## 3. Demo học A → B và biến thể chưa học

Ở **Học A → B**, bấm **Chạy chuỗi A → B**. Ứng dụng kiểm tra baseline, dạyA hai đợt rồi dạyB hai đợt. Mỗi đợt64ví dụ,4vòng; có thể bật/tắt ôn tối đa32trải nghiệm cũ. Bạn cũng có thể bấm từng nút dạy/kiểm tra riêng.

Bảng giữ điểm từng mốc để thấy A có giảm sau B hay không. Bộ chấm128mẫu/task không được đưa vào training. Cột **Đã thấy chính xác trong training** kiểm tra membership của mẫu cụ thể;0không có nghĩa là khái niệm mới, vì đây chỉ là biến thể cường độ/noise của4tín hiệu.

Kết quả demo đo được ở seed17, từ session trắng:

| Mốc | A | B |
|---|---:|---:|
| Trước học | 50,0% | 50,0% |
| Sau hai đợtA | 99,2% | 47,7% |
| Sau hai đợtB tiếp theo | 89,8% | 74,2% |

Nguồn: [acceptance run](runs/20261108T175211Z-mvp-v01-acceptance-3d887d/report.md). Đây là regression/demo sản phẩm sau vòng phát triển, không phải xác nhận research trên test chưa từng xem. Demo256update đầu chỉ tăngA14,06điểm và không đạt target demo20điểm; bản hướng dẫn hiện dùng nhiều đợt dạy, không giấu kết quả ban đầu.

Điểm còn phụ thuộc lịch sử đã học. Muốn tái lập baseline, khôi phục checkpoint `init` hoặc chọn một data-dir mới. Không xóa dữ liệu cũ để reset.

## 4. Trí nhớ, checkpoint và restart

- Mặc định tất cả state người dùng nằm tại `local/mvp/scarx.sqlite`; thư mục `local/` được ignore.
- **Trí nhớ & lịch sử:** SQLite giữ input/prediction, các ví dụ có nhãn và evidence, điểm trước/sau, thời điểm học/restore. Search chỉ truy xuất dữ liệu, không tham gia prediction.
- **Checkpoint:** mỗi đợt học thành công tự lưu learner, weights/stableweights, neuron/eligibility state, importance, reward/RNG, SI state, replay/counters và orchestration RNG. Nhấn **Lưu checkpoint** để tạo bản riêng.
- **Khôi phục:** chọn checkpoint. Ứng dụng tạo phiên bản active mới, không xóa lịch sử. Có thể chọn lại phiên bản học mới hơn để undo thao tác restore.
- **Tải bundle:** xuất checkpoint để lưu riêng. UI restore từ database; nhập file bằng `python run_app.py --import-checkpoint duong-dan-checkpoint.zip` sau khi dừng server cũ. Import tạo active version mới và giữ các checkpoint trước đó; chưa có upload/import UI. Sao lưu toàn bộ history bằng cách dừng app rồi sao chép cả data-dir.
- **Restart:** dừng rồi chạy lại cùng lệnh/data-dir, bấm kiểm tra A/B. State đã commit được nạp lại; không tự huấn luyện lại. Lịch sử chấm/đợt học gần nhất được dựng lại trong màn A→B.

SQLite transaction chứa snapshot và active pointer cùng experience/history. Đợt bị ngắt chưa commit không thay generation trước. Corrupt checksum/format bị từ chối, không âm thầm tạo model trắng. V0.1 chưa có wizard sửa database hỏng do can thiệp ngoài; giữ backup nếu dữ liệu quan trọng.

Không dùng flag `verified` như bằng chứng: bài hiện tại dùng verifier `builtin-rule-v1`. Prediction chưa xác minh chỉ lưu dạng generated, không dùng làm nhãn học. Không có vòng tự học từ output của chính model.

## 5. RAM, CPU và giới hạn

Thanh trạng thái hiển thị RSS, peak committedmemory, CPU process,48neuron,864synapse trọng số, tổngupdate, replay occupancy và checkpoint active. CPU100% tương đương một logicalcore; softmax chưa được hiệu chuẩn như độ tin cậy.

Windows launcher thử áp **process committed-memory limit2GB** qua JobObject; UI báo rõ nếu không áp được. RSS/shared pages còn được monitor riêng. Không đổi pagefile/OSpolicy toàn máy. [Ý nghĩa ProcessMemoryLimit theo Microsoft](https://learn.microsoft.com/en-us/windows/win32/api/winnt/ns-winnt-jobobject_extended_limit_information).

Giới hạn request64KB, batch tối đa128ví dụ×8vòng, tổng1024freshupdate+32replay; timeout15giây/đợt. Monitor/boundedallocation chừa headroom trước transaction. Không cộng RAM browser/OS vào số “RAM tiến trình”; nếu Windows Job không khả dụng thì UI chỉ ghi giám sát/boundedbatches, không tuyên bố hardcap.

Hiện chỉ bind127.0.0.1. API ghi cần token phiên và origin localhost; không mở LAN, không có authentication đa người dùng. Dữ liệu nằm trên máy, chưa mã hóa riêng. Không tự chạy consolidation nền hoặc tự xóa checkpoint; giới hạn2000checkpoint sẽ yêu cầu quản lý/sao lưu trước khi học tiếp.

## 6. Kiểm thử và source

```powershell
python -m pip install -e '.[test]'
python -m pytest -q
python scripts/verify_mvp.py
```

`verify_mvp.py` tạo QA session/run mới, không dùng data-dir cá nhân. Test suite kiểm local updates, legacy/`plasticity-v1`, exactresume, rollback, invalidfeedback, HTTPorigin/body, DBfault và process interruption. Native parity được chạy khi DLL hiện có; compiler không bắt buộc cho MVP.

Mã chính:

- [app/state.py](src/scarx/app/state.py): transaction learner/replay/RNG + SQLite, teach/evaluate/restore.
- [app/server.py](src/scarx/app/server.py), [web](src/scarx/app/web/): loopback API và giao diện.
- [PlasticCore](src/scarx/neural/plasticity.py), [LifelongLearner](src/scarx/learning/lifelong.py), [replay](src/scarx/learning/replay.py): thêm bundle persistence; learningrule/topology giữ nguyên.
- [runtime/limits.py](src/scarx/runtime/limits.py): per-process Windows limit; [tests/test_app.py](tests/test_app.py): acceptance và failure tests.

## 7. Hướng phát triển

[RESEARCH_PLAN.md](docs/RESEARCH_PLAN.md) vẫn là master plan duy nhất; [ADR0005](docs/decisions/0005-product-first-mvp.md) ghi thay đổi Product-first. Researchgates vẫn còn, nhưng không chặn giao diện thử nghiệm.

Vòng tiếp theo ưu tiên nhãn/tác vụ do người dùng định nghĩa có verifier phù hợp, import/checkpoint recovery dễ hơn và đo học/quên qua thời gian ngay trong ứng dụng. Cải thiện rule/representation phải so với bản V0.1 đang chạy và giữ phiên bản hoạt động gần nhất. Chưa tăng model hoặc chuyển sang LLM+memory.

[Trạng thái](docs/STATUS.md) · [Bản đồ dự án](docs/PROJECT_MAP.md) · [Phase2.1 lịch sử](docs/research/08_PHASE21_RESULTS.md) · [Run index](runs/INDEX.md)

## 8. Gói thử và vai trò Hermes

`python scripts/package_mvp.py` tạo `artifacts/SCAR-X-MVP-v0.1.zip` và SHA-256 từ allowlist source/docs/tests/config, kèm checkpoint neural của **demo synthetic do dự án tự tạo**. Không kèm `local/`, trải nghiệm cá nhân, cấu hình Hermes, keys hoặc model ngoài. Giải nén vào thư mục mới, chạy theo mục1. Đây là package Python + checkpoint riêng, **không phải GGUF hoặc model ngôn ngữ có thể nạp vào llama.cpp**.

Muốn chạy ngay với trọng số demo đã học, sau khi dừng phiên đang chạy:

```powershell
python run_app.py --import-checkpoint artifacts/scarx-demo-v01.checkpoint.zip
```

Đây là trọng sốALIF/replay/RNG thực của acceptance run, không phải một modelchat mạnh. Bỏ flagimport ở các lần khởi động tiếp theo để tiếp tục state active đã lưu, tránh nhập lại demo. `python scripts/verify_package.py` kiểm giải nén/khởi động/import/API trong data-dir QA riêng.

[capabilities.json](capabilities.json) công bố khả năng thật. Vision, thao tác desktop/browser và learnedreasoning là yêu cầu tiếp theo, chưa có trong core V0.1. Backend tự chọn4hoặc16stochasticpasses theo uncertainty; đây là automaticcompute, không phải suy luận/planning hoặc chain-of-thought. Không khai báo capability chưa có là `true` để Hermes cho phép gọi.

### Hermes: chọn SCAR-X như một model backend

Người dùng đã chọn backend OpenAI-compatible, không MCP. Framework là Python/NumPy hiện tại với HTTPstdlib, không dùng llama.cpp vì ALIF/localplasticity không phải runtime GGUF của Qwen. Hai model cùng kết nối vào Hermes qua API, không cùng định dạng trọng số.

```text
Provider: scarx-local
Base URL: http://127.0.0.1:8765/v1
Transport: chat_completions
Model: scarx-signal-v0.1
API key: để trống (keyless loopback); client bắt buộc key có thể dùng no-key-required
Vision / tool calling / learned reasoning: false
```

[integrations/hermes/provider.yaml](integrations/hermes/provider.yaml) là cấu hình provider độc lập; không thay cấu hình Qwen. Máy hiện tại đã có Hermes, script cài profile giữ nguyên `model.default`/`provider` của Qwen:

```powershell
python scripts/install_hermes_provider.py
```

Script cần PyYAML (đã có trong môi trường máy này), tạo backup private trong Hermes/backups và chỉ thêm block khi không có providers khác. Khi đã có block phức tạp, nó dừng để người dùng merge, không ghi đè. Không đưa bản config/backup cá nhân vào ZIP.

Mở phiên Hermes mới hoặc reload cấu hình rồi chọn named provider `scarx-local` và model `scarx-signal-v0.1`. Route Hermes hỗ trợ: `/model custom:scarx-local:scarx-signal-v0.1`. App Qwen đang chọn trước đó không bị tự chuyển.

Gửi nguyên JSON trong user message, hoặc code blockjson:

```json
{"operation":"predict","task":"A","signal":2}
```

```json
{"operation":"teach","task":"A","count":64,"epochs":4}
```

```json
{"operation":"evaluate"}
```

Response là JSON chứa prediction/probabilities từ neuralweights, before/after hoặc điểm chấm; **không phải văn bản ngôn ngữ được neuralmodel sinh**. Chỉ userJSON mới nhất được xử lý. Hermes system/history được nhận ở transport nhưng không được gọi là neural longcontext. BodyAPI tối đa1MB để chứa hostprompt; đây không là contextwindow của model.

`GET /v1/models`, `GET /v1/capabilities` và `POST /v1/chat/completions` hỗ trợ nonstream/SSE. Streaming đóng khung JSON sau inference, không giả luồng thinking. Inputảnh, tool/action bắt buộc hoặc chat tự do bị trả lỗi capability rõ ràng. Không proxy sang Qwen hay API trả phí để che phần thiếu.

Định dạng tham khảo: [OpenAI Chat Completions](https://developers.openai.com/api/reference/resources/chat/subresources/completions/methods/create), [streaming events](https://developers.openai.com/api/reference/resources/chat/subresources/completions/streaming-events). Đây là subset tương thích cho test tích hợp, chưa phải model thay Qwen về chat/vision/agenttasks. Hermes có khả năng xem ảnh/thao tác không chứng minh SCAR-Xcore có các năng lực đó.
