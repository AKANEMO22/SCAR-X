"""OpenAI Chat Completions wire format for the real, structured SCAR-X core.

This is a model protocol adapter, not an LLM or a language-template chatbot.
Unsupported vision/tool/reasoning requests receive explicit capability errors.
"""
import json
import time
import uuid

MODEL='scarx-signal-v0.1'


class BackendError(ValueError):
    def __init__(self,message,code='unsupported_input',status=422):
        super().__init__(message); self.code=code; self.status=status

    def response(self):
        return {'error':{'message':str(self),'type':'invalid_request_error','param':None,'code':self.code}}


def models():
    return {'object':'list','data':[{'id':MODEL,'object':'model','created':0,'owned_by':'local-scarx',
        'name':'SCAR-X V0.1 · structured neural backend',
        'capabilities':{'vision':False,'tool_calling':False,'reasoning':False,'structured_signal':True},
        'description':'ALIF neural classifier with local learning. JSON tasks only; no natural-language generation.'}]}


def chat(workbench,data):
    if data.get('model')!=MODEL: raise BackendError('Model không tồn tại. Dùng scarx-signal-v0.1.','model_not_found',404)
    if data.get('n',1)!=1: raise BackendError('Chỉ hỗ trợ n=1.','unsupported_parameter',400)
    if type(data.get('stream',False)) is not bool: raise BackendError('stream phải là boolean.','invalid_parameter',400)
    if data.get('tool_choice') not in (None,'none','auto'): raise BackendError('SCAR-X chưa có tool/action policy.','tools_not_supported')
    messages=data.get('messages')
    if not isinstance(messages,list) or not 1<=len(messages)<=256: raise BackendError('messages phải có 1–256 message.','invalid_messages',400)
    users=[]
    for message in messages:
        if not isinstance(message,dict): raise BackendError('Message không hợp lệ.','invalid_messages',400)
        content=message.get('content')
        if isinstance(content,list):
            if any(not isinstance(part,dict) or part.get('type')!='text' for part in content):
                raise BackendError('Vision/audio chưa được huấn luyện trong SCAR-X V0.1. Không gửi ảnh vào backend này.','vision_not_supported')
            content='\n'.join(part.get('text','') for part in content)
        if message.get('role')=='user':
            if not isinstance(content,str): raise BackendError('User content phải là text JSON.','invalid_messages',400)
            users.append(content)
    if not users: raise BackendError('Cần user message chứa JSON tác vụ.','invalid_messages',400)
    text=users[-1].strip()
    if text.startswith('```json') and text.endswith('```'): text=text[7:-3].strip()
    try: command=json.loads(text,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('Nonfinite JSON')))
    except (ValueError,TypeError) as exc:
        raise BackendError('SCAR-X hiện chưa hiểu chat tự do. Nhập JSON như {"operation":"predict","task":"A","signal":2}.') from exc
    if not isinstance(command,dict): raise BackendError('Nội dung phải là một JSON object.')
    operation=command.pop('operation','predict')
    if operation=='predict':
        raw=workbench.predict(command,automatic=True)
        result={k:raw[k] for k in ('prediction','probabilities','expected','sample','checkpoint','retrieval_used','prediction_source','expected_source','compute')}
    elif operation=='evaluate': result=workbench.evaluate()
    elif operation=='teach': result=workbench.teach(command)
    elif operation=='checkpoint': result=workbench.checkpoint()
    else: raise BackendError('Chỉ hỗ trợ predict, teach, evaluate và checkpoint; chưa có computer actions.','action_not_supported')
    content=json.dumps({'source':'SCAR-X structured neural backend','operation':operation,'result':result,
                        'language_generation':False,'vision':False,'tool_actions':False,'learned_reasoning':False},ensure_ascii=False,allow_nan=False)
    identifier='chatcmpl-scarx-'+uuid.uuid4().hex
    completion={'id':identifier,'object':'chat.completion','created':int(time.time()),'model':MODEL,
                'choices':[{'index':0,'message':{'role':'assistant','content':content},'finish_reason':'stop','logprobs':None}],
                'scarx':{'structured_only':True,'history_interpretation':'Only the latest user JSON command is processed; no neural language context claim.'}}
    if not data.get('stream'): return completion,None
    # Framed after neural inference; not a fabricated live thinking trace.
    events=[]
    def event(delta,finish=None):
        return {'id':identifier,'object':'chat.completion.chunk','created':completion['created'],'model':MODEL,
                'choices':[{'index':0,'delta':delta,'finish_reason':finish,'logprobs':None}]}
    events.append(event({'role':'assistant','content':''}))
    events.extend(event({'content':content[i:i+160]}) for i in range(0,len(content),160))
    events.append(event({},'stop'))
    payload=''.join('data: '+json.dumps(e,ensure_ascii=False)+'\n\n' for e in events)+'data: [DONE]\n\n'
    return completion,payload.encode('utf-8')
