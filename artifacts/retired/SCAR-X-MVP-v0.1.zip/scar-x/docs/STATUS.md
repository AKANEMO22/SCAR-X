# Trạng thái SCAR-X

## Product-first — MVP V0.1 chạy được

Người dùng đã thay phê duyệt docs-only bằng scope triển khai MVP. Chạy `python run_app.py` và mở `http://127.0.0.1:8765`; [README](../README.md) là hướng dẫn dùng/cài/teach/restore duy nhất.

Đã có: UI localhost, PlasticCore48ALIF/864synapse thật, dạy nhãn theo verifier A/B, kiểm before/after và A→B, spikes/weightdrift, SQLitememory/history, atomicfullsessioncheckpoint/restore/restart và resource display. Windows processcommit cap2GB áp khi Job attach được. Không cloud/LLMpretrained, không đổi rule/topology hoặc tăng scale.

[Acceptance demo](../runs/20261108T175211Z-mvp-v01-acceptance-3d887d/report.md): A50%→99,2% sau hai đợt; sau hai đợtB, A89,8%/B74,2%; chưa có mẫu exact trong train cho tập chấm. Restart/restore exact được kiểm. Đây là product regression sau build iteration, không phải researchgeneralization claim. Scope còn yếu:2tác vụ có cấu trúc, chưa natural-language, chưa solvedforgetting, chưa customverifier/importUI hoặc consolidationnền.

Xem [ADR0005](decisions/0005-product-first-mvp.md). Các mục nghiên cứu bên dưới giữ kết quả và gate; **không còn là điều kiện chặn việc dùng/phát triển MVP**.

**Hermes backend:** `/v1/models` và `/v1/chat/completions` nonstream/SSE cho structuredJSON đã có, provider `scarx-local` được thêm vào configHermes và giữ nguyên Qwen9B đang chọn. Không MCP, không GGUF. Automaticcompute chọn4/16passes, chưa là learnedreasoning; vision/actions chưa được hỗ trợ. PackageZIP có source và checkpointdemo; xem README mục8 và capabilities.json.

Cập nhật **2026-11-09**. Định hướng: **Lifelong Adaptive Intelligence**. Mục tiêu 1M context và độ dài token đã được loại bỏ.

**Kế hoạch chính duy nhất:** [RESEARCH_PLAN.md](RESEARCH_PLAN.md). SCAR-X giữ mục tiêu neural architecture, không chuyển thành memory/RAG cho LLM. Bản1.0 chỉ cập nhật docs; ADR0005 nay phê duyệt MVP/code/UI. Protocol và kết quả nghiên cứu cũ vẫn giữ nguyên.

**Quyết định sau Phase 2.1: PIVOT_NO_SCALE.** Giữ mạng nhỏ 48 neuron. Chưa có bằng chứng đủ cho lợi thế representation và continual learning của các quy tắc đã thử.

## Kết quả hiện tại — Phase 2.1

- [Báo cáo kết quả và câu trả lời nghiên cứu](research/08_PHASE21_RESULTS.md)
- [Kế hoạch đăng ký trước](../experiments/phase21-v1.md) và [bổ sung stream không task boundary](../experiments/phase21-lifelong-amendment.md)
- [Phản biện khả năng học dài hạn](research/07_LIFELONG_LIMITS.md)
- [Audit hiệu lực phép đo](decisions/0003-phase21-evaluation-audit.md)
- [Danh mục run](../runs/INDEX.md), [kết quả máy đọc](../artifacts/phase21-summary.json)

Đã audit 15 trial/checkpoint Phase 2 và chạy 303 trial mới: eligibility score, STDP, metaplasticity, importance decay, replay/consolidation factorial, readout-only, SI tại readout, modulation nhiễu và BPTT control riêng. Có 3 seed phát triển, 8 seed xác nhận và 8 seed mới cho strict binding audit; không tính các condition ghép cặp như seed độc lập.

Stream có 1.280 trải nghiệm, không task ID/boundary cho learner, 20 cửa sổ đánh giá và 20% nhãn nhiễu. Fast weights, stable anchor và consolidation định kỳ đã triển khai. Neural/RNG/importance/replay continuation được kiểm tra.

Kết quả: hidden chưa đạt gate representation; metaplasticity giảm forgetting nhưng accuracy gần 50%; không condition nào đạt đồng thời mean forgetting ≤3 điểm phần trăm, worst ≤5 điểm và chất lượng tối thiểu. RAM quan sát trong trần 2 GB, chưa phải OS hard cap.

Hướng còn hợp lý: importance gắn với mức hữu ích, ổn định readout, credit assignment và bài representation hợp lệ. Cần protocol/seed mới trước vòng tiếp theo. Không tăng tham số, huấn luyện ngôn ngữ hoặc tối ưu C++/iGPU trong vòng này.

## Roadmap nghiên cứu Phase 2.2 — không chặn MVP

1. **P0 kỹ thuật:** compatibility `plasticity-v1`, whole-state checkpoint/rollback cho learner/replay/RNG, evidence verification và budget RAM toàn phiên. Save/load riêng đã có; transaction cho lõi mới chưa hoàn chỉnh.
2. **P1/P2 ưu tiên khoa học:** representation/credit assignment và readout stability/usefulness-based importance. Không dùng replay tối ưu để che các vấn đề gốc.
3. **P3:** Experience-to-Skill với tình huống giữ kín, reset/restart và retrieval-off; semantic/procedural memory vẫn là mục tiêu chưa chứng minh.
4. **P4:** offline consolidation thủ công có matched compute, verifier/guard và rollback; chưa mở automatic idle scheduler.
5. **P5:** độ bền20→50→100giai đoạn có gate, giữ capacity và plasticity reserve.

Chi tiết giả thuyết, code, dữ liệu, baseline, metrics, pass/fail, rủi ro và phụ thuộc ở [roadmap master](RESEARCH_PLAN.md#7-experiment-roadmap). Tất cả stage trên cần duyệt triển khai/protocol trước. Ngưỡng mean forgetting≤3 điểm phần trăm và worst≤5 trên từng seed vẫn giữ; kết quả cũ không chấm lại.

Chưa có Git trong project; [master mục8.3](RESEARCH_PLAN.md#83-quản-lý-phiên-bản-và-dữ-liệu) chỉ đề xuất phương án version control local, chưa init/commit/push hoặc đổi cấu trúc. [ADR0004](decisions/0004-master-plan-and-phase22-docs.md) ghi phạm vi quyết định mới.

## Hồ sơ Phase 2 lịch sử

- Cấu trúc src theo domain, project map, ADR, protocol và run index.
- ALIF recurrent, block-local reward-modulated STDP, readout local, stable weights.
- Checkpoint có checksum, atomic save, exact resume; guard và rollback.
- SQLite exact episodes, FTS5, provenance; byte generation plumbing gắn nhãn chưa huấn luyện.
- CLI init/generate/observe/search/learn/rollback/benchmark.
- C++ CPU SIMD kernel, build bằng MSVC, kiểm tra parity.
- 15 trial local/analog qua3 seed,20 task/chặng; run xác nhận cùng seed.
- 3 trial surrogate BPTT control riêng; runtime/memory/retrieval smoke.
- Sáu báo cáo nghiên cứu trong research/.

## Kết quả Phase 2 cần nhớ

Học được liên kết nhỏ, nhưng readout-only cũng đạt100%. Hidden plasticity chưa tạo lợi ích đo được ở bài này. Forgetting trung bình full20,8–23,9 điểm %, cao hơn ngưỡng3 điểm. Vì vậy dừng mở rộng.

## Chưa thực hiện — giữ rõ trong backlog

- Huấn luyện ngôn ngữ10M token và model10M/30M/100M tham số.
- Bộ đánh giá đa năng600+ bài và matched commercial comparison.
- Low-bit/pretrained LLM+RAG baseline trên cùng tác vụ ngôn ngữ.
- Runtime C++ độc lập, hard memory cap, quantization, iGPU scheduling.
- Kiểm thử feedback noise thực tế ngoài giả lập Phase 2.1, 8h endurance, điện năng đo thật.

Lý do: gate nghiên cứu bắt buộc đã không đạt; không được diễn giải những mục này là hoàn thành.

Tra cứu: [Phase 2.1](research/08_PHASE21_RESULTS.md), [Phase 2 lịch sử](research/06_FEASIBILITY_VERDICT.md), [run index](../runs/INDEX.md), [bản đồ](PROJECT_MAP.md).
