# Model artifacts

`association-seed17/` chứa một checkpoint bài liên kết nhỏ từ run xác nhận, không phải chatbot hoặc model ngôn ngữ. Có manifest ghi nguồn và SHA-256. Giữ các checkpoint có kết quả đánh giá tại đây; file tạm cá nhân để trong `local/`.

Không dùng tên model artifact để tuyên bố chất lượng vượt những gì run đã đo.
