# Forensic r6d-matrix

{
  "decision": "AUDIT_EXECUTION_COMPLETE_REQUIRES_ANALYSIS",
  "phase": "r6d-matrix",
  "run_class": "HISTORICAL_REPRODUCTION",
  "commands": [
    {
      "command": [
        "C:\\Users\\hachimi\\AppData\\Local\\Programs\\Python\\Python311\\python.exe",
        "C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\scarx-forensic-r6-20261111\\scripts\\forensic_replay_worker.py",
        "--source",
        "C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\forensic-source-r6d-4bacd7b",
        "--output",
        "C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\scarx-forensic-r6-20261111\\runs\\20261111T100207Z-forensic-r6d-matrix-v1-34ca0c\\replay",
        "--phase",
        "r6d-matrix"
      ],
      "cwd": "C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\forensic-source-r6d-4bacd7b",
      "exit_code": 0,
      "error": null,
      "seconds": 157.5199558999957,
      "resources": {
        "peak_rss_bytes": 250339328,
        "peak_commit_or_vms_bytes": 263942144,
        "os_process_peak_working_set_bytes": 41250816,
        "os_process_peak_pagefile_commit_bytes": 28786688,
        "samples": 1572,
        "interval_seconds": 0.1,
        "limit_bytes": 2000000000,
        "observed_over_limit": false,
        "elapsed_seconds": 157.51973210000142,
        "hard_cap_enforced": false,
        "igpu_measured": false,
        "energy_joules": null,
        "note": "Tree sums may double-count shared pages; Windows pagefile is commit, not bytes swapped. No iGPU allocated."
      },
      "log": "r6d-matrix.log"
    }
  ],
  "cap": {
    "enforced": true,
    "limit_bytes": 2000000000,
    "kind": "Windows per-process committed memory; shared pages monitored separately"
  },
  "source_commits": {
    "r6d": "4bacd7b2c8a1df7ab47e55f266f2b6bf0e193893",
    "r6b": "c39e9db7771582d9933af402a209917328b71119"
  },
  "fresh_confirmation": false,
  "candidate_equations_changed": false,
  "production_or_live_state_modified": false,
  "error": null
}
