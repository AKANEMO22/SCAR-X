# Forensic engineering

{
  "decision": "AUDIT_EXECUTION_COMPLETE_REQUIRES_ANALYSIS",
  "phase": "engineering",
  "run_class": "ENGINEERING_CHECK",
  "commands": [
    {
      "command": [
        "C:\\Users\\hachimi\\AppData\\Local\\Programs\\Python\\Python311\\python.exe",
        "-m",
        "pytest",
        "-q",
        "-p",
        "no:cacheprovider",
        "tests/test_r6d_audit.py",
        "--junitxml=C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\scarx-forensic-r6-20261111\\runs\\20261111T100134Z-forensic-engineering-v1-5c192a\\r6d-author-tests.xml"
      ],
      "cwd": "C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\forensic-source-r6d-4bacd7b",
      "exit_code": 0,
      "error": null,
      "seconds": 1.5511274999953457,
      "resources": {
        "peak_rss_bytes": 173428736,
        "peak_commit_or_vms_bytes": 171712512,
        "os_process_peak_working_set_bytes": 41828352,
        "os_process_peak_pagefile_commit_bytes": 29478912,
        "samples": 18,
        "interval_seconds": 0.1,
        "limit_bytes": 2000000000,
        "observed_over_limit": false,
        "elapsed_seconds": 1.550818399999116,
        "hard_cap_enforced": false,
        "igpu_measured": false,
        "energy_joules": null,
        "note": "Tree sums may double-count shared pages; Windows pagefile is commit, not bytes swapped. No iGPU allocated."
      },
      "log": "r6d-author-tests.log"
    },
    {
      "command": [
        "C:\\Users\\hachimi\\AppData\\Local\\Programs\\Python\\Python311\\python.exe",
        "C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\scarx-forensic-r6-20261111\\scripts\\forensic_runtime_checks.py",
        "--source",
        "C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\forensic-source-r6d-4bacd7b",
        "--kind",
        "r6d"
      ],
      "cwd": "C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\forensic-source-r6d-4bacd7b",
      "exit_code": 0,
      "error": null,
      "seconds": 0.5299416999987443,
      "resources": {
        "peak_rss_bytes": 82870272,
        "peak_commit_or_vms_bytes": 85712896,
        "os_process_peak_working_set_bytes": 41844736,
        "os_process_peak_pagefile_commit_bytes": 29478912,
        "samples": 7,
        "interval_seconds": 0.1,
        "limit_bytes": 2000000000,
        "observed_over_limit": false,
        "elapsed_seconds": 0.5297943000041414,
        "hard_cap_enforced": false,
        "igpu_measured": false,
        "energy_joules": null,
        "note": "Tree sums may double-count shared pages; Windows pagefile is commit, not bytes swapped. No iGPU allocated."
      },
      "log": "r6d-independent-checks.log"
    },
    {
      "command": [
        "C:\\Users\\hachimi\\AppData\\Local\\Programs\\Python\\Python311\\python.exe",
        "-m",
        "pytest",
        "-q",
        "-p",
        "no:cacheprovider",
        "tests/test_r6_toys.py",
        "--junitxml=C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\scarx-forensic-r6-20261111\\runs\\20261111T100134Z-forensic-engineering-v1-5c192a\\r6b-author-tests.xml"
      ],
      "cwd": "C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\forensic-source-r6b-c39e9db",
      "exit_code": 0,
      "error": null,
      "seconds": 1.5666129000019282,
      "resources": {
        "peak_rss_bytes": 171872256,
        "peak_commit_or_vms_bytes": 136261632,
        "os_process_peak_working_set_bytes": 41877504,
        "os_process_peak_pagefile_commit_bytes": 29503488,
        "samples": 17,
        "interval_seconds": 0.1,
        "limit_bytes": 2000000000,
        "observed_over_limit": false,
        "elapsed_seconds": 1.5664747999981046,
        "hard_cap_enforced": false,
        "igpu_measured": false,
        "energy_joules": null,
        "note": "Tree sums may double-count shared pages; Windows pagefile is commit, not bytes swapped. No iGPU allocated."
      },
      "log": "r6b-author-tests.log"
    },
    {
      "command": [
        "C:\\Users\\hachimi\\AppData\\Local\\Programs\\Python\\Python311\\python.exe",
        "C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\scarx-forensic-r6-20261111\\scripts\\forensic_runtime_checks.py",
        "--source",
        "C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\forensic-source-r6b-c39e9db",
        "--kind",
        "r6b"
      ],
      "cwd": "C:\\Users\\hachimi\\Downloads\\model agent\\scar-x\\local\\worktrees\\forensic-source-r6b-c39e9db",
      "exit_code": 0,
      "error": null,
      "seconds": 0.552749100002984,
      "resources": {
        "peak_rss_bytes": 75145216,
        "peak_commit_or_vms_bytes": 46682112,
        "os_process_peak_working_set_bytes": 41877504,
        "os_process_peak_pagefile_commit_bytes": 29503488,
        "samples": 7,
        "interval_seconds": 0.1,
        "limit_bytes": 2000000000,
        "observed_over_limit": false,
        "elapsed_seconds": 0.5524715999999898,
        "hard_cap_enforced": false,
        "igpu_measured": false,
        "energy_joules": null,
        "note": "Tree sums may double-count shared pages; Windows pagefile is commit, not bytes swapped. No iGPU allocated."
      },
      "log": "r6b-independent-checks.log"
    }
  ],
  "cap": {
    "enforced": true,
    "limit_bytes": 2000000000,
    "kind": "Windows per-process committed memory; shared pages monitored separately"
  },
  "source_commits": {
    "r6d": "4bacd7b2c8a1df7ab47e55f266f2b6bf0e193893",
    "r6b": "c39e9db7771582d9933af402a209917328b71119"
  },
  "fresh_confirmation": false,
  "candidate_equations_changed": false,
  "production_or_live_state_modified": false,
  "error": null
}
